/* tslint:disable */
/* eslint-disable */

/**
 * マスターパスワード変更
 */
export function api_change_master_password(old_password: string, new_password: string): void;

/**
 * エントリ作成
 */
export function api_create_entry(entry_type: string, name: string, notes: string | null | undefined, typed_value_json: string, label_ids: string[], custom_fields_json?: string | null): string;

/**
 * ラベル作成
 */
export function api_create_label(name: string): string;

/**
 * 新規Vaultを作成し、RecoveryKeyを返す
 */
export function api_create_new_vault(master_password: string): string;

/**
 * エントリをゴミ箱へ移動
 */
export function api_delete_entry(id: string): void;

/**
 * ラベル削除
 */
export function api_delete_label(id: string): void;

/**
 * パスワード生成
 */
export function api_generate_password(length: number, include_uppercase: boolean, include_lowercase: boolean, include_numbers: boolean, include_symbols: boolean): string;

/**
 * TOTP生成
 */
export function api_generate_totp(secret: string, digits: number, period: number): string;

/**
 * TOTP生成（デフォルト）
 */
export function api_generate_totp_default(secret: string): string;

/**
 * エントリ詳細（復号済み）
 * 戻り値は JSON 文字列
 */
export function api_get_entry(id: string): string;

/**
 * 現在のvault_bytesを取得
 */
export function api_get_vault_bytes(): Uint8Array;

/**
 * エントリ一覧（フィルター付き）
 * 戻り値は JSON 文字列（エントリ行の配列）
 */
export function api_list_entries(search_query: string | null | undefined, entry_type: string | null | undefined, label_id: string | null | undefined, include_trash: boolean, only_favorites: boolean): string;

/**
 * ラベル一覧
 * 戻り値は JSON 文字列（ラベル配列）
 */
export function api_list_labels(): string;

/**
 * 既存Vaultをメモリに読み込む
 */
export function api_load_vault(vault_bytes: Uint8Array, etag: string): void;

/**
 * ロック（vault_bytesを返す）
 */
export function api_lock(): Uint8Array;

/**
 * 完全削除
 */
export function api_purge_entry(id: string): void;

/**
 * リカバリーキー再発行
 */
export function api_regenerate_recovery_key(password: string): string;

/**
 * ラベル名変更
 */
export function api_rename_label(id: string, new_name: string): void;

/**
 * ゴミ箱から復元
 */
export function api_restore_entry(id: string): void;

/**
 * DEK ローテーション（新しいリカバリーキーを返す）
 */
export function api_rotate_dek(password: string): string;

/**
 * エントリにラベルを紐付け
 */
export function api_set_entry_labels(entry_id: string, label_ids: string[]): void;

/**
 * お気に入り設定
 */
export function api_set_favorite(id: string, is_favorite: boolean): void;

/**
 * マスターパスワードでアンロック
 */
export function api_unlock(master_password: string): void;

/**
 * リカバリーキーでアンロック（新しいマスターパスワード設定フロー）
 */
export function api_unlock_with_recovery_key(recovery_key: string): void;

/**
 * エントリ更新
 */
export function api_update_entry(id: string, name?: string | null, notes?: string | null, typed_value_json?: string | null, label_ids?: string[] | null, custom_fields_json?: string | null): void;

/**
 * Argon2パラメータアップグレード
 */
export function api_upgrade_argon2_params(password: string, iterations: number, memory: number, parallelism: number): string;
