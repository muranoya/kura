/* @ts-self-types="./vault_core.d.ts" */

import * as wasm from "./vault_core_bg.wasm";
import { __wbg_set_wasm } from "./vault_core_bg.js";
__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    api_change_master_password, api_create_entry, api_create_label, api_create_new_vault, api_delete_entry, api_delete_label, api_generate_password, api_generate_totp, api_generate_totp_default, api_get_entry, api_get_vault_bytes, api_list_entries, api_list_labels, api_load_vault, api_lock, api_purge_entry, api_regenerate_recovery_key, api_rename_label, api_restore_entry, api_rotate_dek, api_set_entry_labels, api_set_favorite, api_unlock, api_unlock_with_recovery_key, api_update_entry, api_upgrade_argon2_params
} from "./vault_core_bg.js";
