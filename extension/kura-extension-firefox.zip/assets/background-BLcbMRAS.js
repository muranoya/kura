import { s as p, S as d, g as m } from "./constants-BFP2TXfE.js";
(async ()=>{
    const me = "/assets/vault_core_bg-BR5Sab9T.wasm", Te = async (e = {}, a)=>{
        let r;
        if (a.startsWith("data:")) {
            const t = a.replace(/^data:.*?base64,/, "");
            let _;
            if (typeof Buffer == "function" && typeof Buffer.from == "function") _ = Buffer.from(t, "base64");
            else if (typeof atob == "function") {
                const c = atob(t);
                _ = new Uint8Array(c.length);
                for(let o = 0; o < c.length; o++)_[o] = c.charCodeAt(o);
            } else throw new Error("Cannot decode base64-encoded data URL");
            r = await WebAssembly.instantiate(_, e);
        } else {
            const t = await fetch(a), _ = t.headers.get("Content-Type") || "";
            if ("instantiateStreaming" in WebAssembly && _.startsWith("application/wasm")) r = await WebAssembly.instantiateStreaming(t, e);
            else {
                const c = await t.arrayBuffer();
                r = await WebAssembly.instantiate(c, e);
            }
        }
        return r.instance.exports;
    };
    function F(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = i, _ = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), c = i, o = n.api_change_master_password(r, t, _, c);
        if (o[1]) throw f(o[0]);
    }
    function ee(e, a, r, t, _, c) {
        let o, l;
        try {
            const A = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), T = i, G = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), D = i;
            var b = w(r) ? 0 : s(r, n.__wbindgen_malloc, n.__wbindgen_realloc), g = i;
            const B = s(t, n.__wbindgen_malloc, n.__wbindgen_realloc), pe = i, he = H(_, n.__wbindgen_malloc), ve = i;
            var h = w(c) ? 0 : s(c, n.__wbindgen_malloc, n.__wbindgen_realloc), N = i;
            const M = n.api_create_entry(A, T, G, D, b, g, B, pe, he, ve, h, N);
            var k = M[0], v = M[1];
            if (M[3]) throw k = 0, v = 0, f(M[2]);
            return o = k, l = v, S(k, v);
        } finally{
            n.__wbindgen_free(o, l, 1);
        }
    }
    function te(e) {
        let a, r;
        try {
            const c = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), o = i, l = n.api_create_label(c, o);
            var t = l[0], _ = l[1];
            if (l[3]) throw t = 0, _ = 0, f(l[2]);
            return a = t, r = _, S(t, _);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function x(e) {
        let a, r;
        try {
            const c = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), o = i, l = n.api_create_new_vault(c, o);
            var t = l[0], _ = l[1];
            if (l[3]) throw t = 0, _ = 0, f(l[2]);
            return a = t, r = _, S(t, _);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function re(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = i, t = n.api_delete_entry(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ae(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = i, t = n.api_delete_label(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ne(e, a, r, t, _) {
        let c, o;
        try {
            const g = n.api_generate_password(e, a, r, t, _);
            var l = g[0], b = g[1];
            if (g[3]) throw l = 0, b = 0, f(g[2]);
            return c = l, o = b, S(l, b);
        } finally{
            n.__wbindgen_free(c, o, 1);
        }
    }
    function ke(e, a, r) {
        let t, _;
        try {
            const l = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), b = i, g = n.api_generate_totp(l, b, a, r);
            var c = g[0], o = g[1];
            if (g[3]) throw c = 0, o = 0, f(g[2]);
            return t = c, _ = o, S(c, o);
        } finally{
            n.__wbindgen_free(t, _, 1);
        }
    }
    function _e(e) {
        let a, r;
        try {
            const c = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), o = i, l = n.api_generate_totp_default(c, o);
            var t = l[0], _ = l[1];
            if (l[3]) throw t = 0, _ = 0, f(l[2]);
            return a = t, r = _, S(t, _);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function ce(e) {
        let a, r;
        try {
            const c = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), o = i, l = n.api_get_entry(c, o);
            var t = l[0], _ = l[1];
            if (l[3]) throw t = 0, _ = 0, f(l[2]);
            return a = t, r = _, S(t, _);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function C() {
        const e = n.api_get_vault_bytes();
        if (e[3]) throw f(e[2]);
        var a = U(e[0], e[1]).slice();
        return n.__wbindgen_free(e[0], e[1] * 1, 1), a;
    }
    function J(e, a, r, t, _) {
        let c, o;
        try {
            var l = w(e) ? 0 : s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), b = i, g = w(a) ? 0 : s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), h = i, N = w(r) ? 0 : s(r, n.__wbindgen_malloc, n.__wbindgen_realloc), k = i;
            const T = n.api_list_entries(l, b, g, h, N, k, t, _);
            var v = T[0], A = T[1];
            if (T[3]) throw v = 0, A = 0, f(T[2]);
            return c = v, o = A, S(v, A);
        } finally{
            n.__wbindgen_free(c, o, 1);
        }
    }
    function oe() {
        let e, a;
        try {
            const _ = n.api_list_labels();
            var r = _[0], t = _[1];
            if (_[3]) throw r = 0, t = 0, f(_[2]);
            return e = r, a = t, S(r, t);
        } finally{
            n.__wbindgen_free(e, a, 1);
        }
    }
    function K(e, a) {
        const r = tt(e, n.__wbindgen_malloc), t = i, _ = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), c = i, o = n.api_load_vault(r, t, _, c);
        if (o[1]) throw f(o[0]);
    }
    function q() {
        const e = n.api_lock();
        if (e[3]) throw f(e[2]);
        var a = U(e[0], e[1]).slice();
        return n.__wbindgen_free(e[0], e[1] * 1, 1), a;
    }
    function le(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = i, t = n.api_purge_entry(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ie(e) {
        let a, r;
        try {
            const c = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), o = i, l = n.api_regenerate_recovery_key(c, o);
            var t = l[0], _ = l[1];
            if (l[3]) throw t = 0, _ = 0, f(l[2]);
            return a = t, r = _, S(t, _);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function se(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = i, _ = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), c = i, o = n.api_rename_label(r, t, _, c);
        if (o[1]) throw f(o[0]);
    }
    function ue(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = i, t = n.api_restore_entry(a, r);
        if (t[1]) throw f(t[0]);
    }
    function fe(e) {
        let a, r;
        try {
            const c = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), o = i, l = n.api_rotate_dek(c, o);
            var t = l[0], _ = l[1];
            if (l[3]) throw t = 0, _ = 0, f(l[2]);
            return a = t, r = _, S(t, _);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function de(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = i, _ = H(a, n.__wbindgen_malloc), c = i, o = n.api_set_entry_labels(r, t, _, c);
        if (o[1]) throw f(o[0]);
    }
    function be(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = i, _ = n.api_set_favorite(r, t, a);
        if (_[1]) throw f(_[0]);
    }
    function z(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = i, t = n.api_unlock(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ge(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = i, t = n.api_unlock_with_recovery_key(a, r);
        if (t[1]) throw f(t[0]);
    }
    function we(e, a, r, t, _, c) {
        const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), l = i;
        var b = w(a) ? 0 : s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), g = i, h = w(r) ? 0 : s(r, n.__wbindgen_malloc, n.__wbindgen_realloc), N = i, k = w(t) ? 0 : s(t, n.__wbindgen_malloc, n.__wbindgen_realloc), v = i, A = w(_) ? 0 : H(_, n.__wbindgen_malloc), T = i, G = w(c) ? 0 : s(c, n.__wbindgen_malloc, n.__wbindgen_realloc), D = i;
        const B = n.api_update_entry(o, l, b, g, h, N, k, v, A, T, G, D);
        if (B[1]) throw f(B[0]);
    }
    function Ae(e, a, r, t) {
        let _, c;
        try {
            const b = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), g = i, h = n.api_upgrade_argon2_params(b, g, a, r, t);
            var o = h[0], l = h[1];
            if (h[3]) throw o = 0, l = 0, f(h[2]);
            return _ = o, c = l, S(o, l);
        } finally{
            n.__wbindgen_free(_, c, 1);
        }
    }
    function Ee(e) {
        return typeof e == "function";
    }
    function Le(e) {
        const a = e;
        return typeof a == "object" && a !== null;
    }
    function Ce(e) {
        return typeof e == "string";
    }
    function We(e) {
        return e === void 0;
    }
    function Ve(e, a) {
        const r = a, t = typeof r == "string" ? r : void 0;
        var _ = w(t) ? 0 : s(t, n.__wbindgen_malloc, n.__wbindgen_realloc), c = i;
        j().setInt32(e + 4 * 1, c, !0), j().setInt32(e + 4 * 0, _, !0);
    }
    function Ne(e, a) {
        throw new Error(S(e, a));
    }
    function Oe() {
        return I(function(e, a, r) {
            return e.call(a, r);
        }, arguments);
    }
    function Ue(e) {
        return e.crypto;
    }
    function Ie() {
        return I(function(e, a) {
            globalThis.crypto.getRandomValues(U(e, a));
        }, arguments);
    }
    function Be() {
        return I(function(e, a) {
            e.getRandomValues(a);
        }, arguments);
    }
    function Me(e) {
        return e.getTime();
    }
    function Pe(e) {
        return e.length;
    }
    function Ye(e) {
        return e.msCrypto;
    }
    function Ge() {
        return new Date;
    }
    function De(e) {
        return new Uint8Array(e >>> 0);
    }
    function $e(e) {
        return e.node;
    }
    function Fe(e) {
        return e.process;
    }
    function xe(e, a, r) {
        Uint8Array.prototype.set.call(U(e, a), r);
    }
    function Je() {
        return I(function(e, a) {
            e.randomFillSync(a);
        }, arguments);
    }
    function Ke() {
        return I(function() {
            return module.require;
        }, arguments);
    }
    function ze() {
        const e = typeof global > "u" ? null : global;
        return w(e) ? 0 : V(e);
    }
    function je() {
        const e = typeof globalThis > "u" ? null : globalThis;
        return w(e) ? 0 : V(e);
    }
    function qe() {
        const e = typeof self > "u" ? null : self;
        return w(e) ? 0 : V(e);
    }
    function He() {
        const e = typeof window > "u" ? null : window;
        return w(e) ? 0 : V(e);
    }
    function Xe(e, a, r) {
        return e.subarray(a >>> 0, r >>> 0);
    }
    function Qe(e) {
        return e.versions;
    }
    function Ze(e, a) {
        return U(e, a);
    }
    function Re(e, a) {
        return S(e, a);
    }
    function et() {
        const e = n.__wbindgen_externrefs, a = e.grow(4);
        e.set(0, void 0), e.set(a + 0, void 0), e.set(a + 1, null), e.set(a + 2, !0), e.set(a + 3, !1);
    }
    function V(e) {
        const a = n.__externref_table_alloc();
        return n.__wbindgen_externrefs.set(a, e), a;
    }
    function U(e, a) {
        return e = e >>> 0, W().subarray(e / 1, e / 1 + a);
    }
    let E = null;
    function j() {
        return (E === null || E.buffer.detached === !0 || E.buffer.detached === void 0 && E.buffer !== n.memory.buffer) && (E = new DataView(n.memory.buffer)), E;
    }
    function S(e, a) {
        return e = e >>> 0, at(e, a);
    }
    let P = null;
    function W() {
        return (P === null || P.byteLength === 0) && (P = new Uint8Array(n.memory.buffer)), P;
    }
    function I(e, a) {
        try {
            return e.apply(this, a);
        } catch (r) {
            const t = V(r);
            n.__wbindgen_exn_store(t);
        }
    }
    function w(e) {
        return e == null;
    }
    function tt(e, a) {
        const r = a(e.length * 1, 1) >>> 0;
        return W().set(e, r / 1), i = e.length, r;
    }
    function H(e, a) {
        const r = a(e.length * 4, 4) >>> 0;
        for(let t = 0; t < e.length; t++){
            const _ = V(e[t]);
            j().setUint32(r + 4 * t, _, !0);
        }
        return i = e.length, r;
    }
    function s(e, a, r) {
        if (r === void 0) {
            const l = O.encode(e), b = a(l.length, 1) >>> 0;
            return W().subarray(b, b + l.length).set(l), i = l.length, b;
        }
        let t = e.length, _ = a(t, 1) >>> 0;
        const c = W();
        let o = 0;
        for(; o < t; o++){
            const l = e.charCodeAt(o);
            if (l > 127) break;
            c[_ + o] = l;
        }
        if (o !== t) {
            o !== 0 && (e = e.slice(o)), _ = r(_, t, t = o + e.length * 3, 1) >>> 0;
            const l = W().subarray(_ + o, _ + t), b = O.encodeInto(e, l);
            o += b.written, _ = r(_, t, o, 1) >>> 0;
        }
        return i = o, _;
    }
    function f(e) {
        const a = n.__wbindgen_externrefs.get(e);
        return n.__externref_table_dealloc(e), a;
    }
    let Y = new TextDecoder("utf-8", {
        ignoreBOM: !0,
        fatal: !0
    });
    Y.decode();
    const rt = 2146435072;
    let $ = 0;
    function at(e, a) {
        return $ += a, $ >= rt && (Y = new TextDecoder("utf-8", {
            ignoreBOM: !0,
            fatal: !0
        }), Y.decode(), $ = a), Y.decode(W().subarray(e, e + a));
    }
    const O = new TextEncoder;
    "encodeInto" in O || (O.encodeInto = function(e, a) {
        const r = O.encode(e);
        return a.set(r), {
            read: e.length,
            written: r.length
        };
    });
    let i = 0, n;
    function nt(e) {
        n = e;
    }
    URL = globalThis.URL;
    const _t = await Te({
        "./vault_core_bg.js": {
            __wbg_getRandomValues_a1cf2e70b003a59d: Ie,
            __wbg_crypto_38df2bab126b63dc: Ue,
            __wbg_process_44c7a14e11e9f69e: Fe,
            __wbg_versions_276b2795b1c6a219: Qe,
            __wbg_node_84ea875411254db1: $e,
            __wbg_require_b4edbdcf3e2a1ef0: Ke,
            __wbg_call_2d781c1f4d5c0ef8: Oe,
            __wbg_msCrypto_bd5a034af96bcba6: Ye,
            __wbg_randomFillSync_6c25eac9869eb53c: Je,
            __wbg_getRandomValues_c44a50d8cfdaebeb: Be,
            __wbg_length_ea16607d7b61445b: Pe,
            __wbg_prototypesetcall_d62e5099504357e6: xe,
            __wbg_new_with_length_825018a1616e9e55: De,
            __wbg_subarray_a068d24e39478a8a: Xe,
            __wbg_new_0_1dcafdf5e786e876: Ge,
            __wbg_getTime_1dad7b5386ddd2d9: Me,
            __wbg_static_accessor_GLOBAL_THIS_ad356e0db91c7913: je,
            __wbg_static_accessor_SELF_f207c857566db248: qe,
            __wbg_static_accessor_GLOBAL_8adb955bd33fac2f: ze,
            __wbg_static_accessor_WINDOW_bb9f1ba69d61b386: He,
            __wbg___wbindgen_throw_6ddd609b62940d55: Ne,
            __wbg___wbindgen_is_object_781bc9f159099513: Le,
            __wbg___wbindgen_is_string_7ef6b97b02428fae: Ce,
            __wbg___wbindgen_string_get_395e606bd0ee4427: Ve,
            __wbg___wbindgen_is_function_3c846841762788c1: Ee,
            __wbg___wbindgen_is_undefined_52709e72fb9f179c: We,
            __wbindgen_init_externref_table: et,
            __wbindgen_cast_0000000000000001: Ze,
            __wbindgen_cast_0000000000000002: Re
        }
    }, me), { memory: ct, api_change_master_password: ot, api_create_entry: lt, api_create_label: it, api_create_new_vault: st, api_delete_entry: ut, api_delete_label: ft, api_generate_password: dt, api_generate_totp: bt, api_generate_totp_default: gt, api_get_entry: wt, api_get_vault_bytes: yt, api_list_entries: St, api_list_labels: pt, api_load_vault: ht, api_lock: vt, api_purge_entry: mt, api_regenerate_recovery_key: Tt, api_rename_label: kt, api_restore_entry: At, api_rotate_dek: Et, api_set_entry_labels: Lt, api_set_favorite: Ct, api_unlock: Wt, api_unlock_with_recovery_key: Vt, api_update_entry: Nt, api_upgrade_argon2_params: Ot, __wbindgen_malloc: Ut, __wbindgen_realloc: It, __wbindgen_exn_store: Bt, __externref_table_alloc: Mt, __wbindgen_externrefs: Pt, __externref_table_dealloc: Yt, __wbindgen_free: Gt, __wbindgen_start: ye } = _t, Dt = Object.freeze(Object.defineProperty({
        __proto__: null,
        __externref_table_alloc: Mt,
        __externref_table_dealloc: Yt,
        __wbindgen_exn_store: Bt,
        __wbindgen_externrefs: Pt,
        __wbindgen_free: Gt,
        __wbindgen_malloc: Ut,
        __wbindgen_realloc: It,
        __wbindgen_start: ye,
        api_change_master_password: ot,
        api_create_entry: lt,
        api_create_label: it,
        api_create_new_vault: st,
        api_delete_entry: ut,
        api_delete_label: ft,
        api_generate_password: dt,
        api_generate_totp: bt,
        api_generate_totp_default: gt,
        api_get_entry: wt,
        api_get_vault_bytes: yt,
        api_list_entries: St,
        api_list_labels: pt,
        api_load_vault: ht,
        api_lock: vt,
        api_purge_entry: mt,
        api_regenerate_recovery_key: Tt,
        api_rename_label: kt,
        api_restore_entry: At,
        api_rotate_dek: Et,
        api_set_entry_labels: Lt,
        api_set_favorite: Ct,
        api_unlock: Wt,
        api_unlock_with_recovery_key: Vt,
        api_update_entry: Nt,
        api_upgrade_argon2_params: Ot,
        memory: ct
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    nt(Dt);
    ye();
    const Q = Object.freeze(Object.defineProperty({
        __proto__: null,
        api_change_master_password: F,
        api_create_entry: ee,
        api_create_label: te,
        api_create_new_vault: x,
        api_delete_entry: re,
        api_delete_label: ae,
        api_generate_password: ne,
        api_generate_totp: ke,
        api_generate_totp_default: _e,
        api_get_entry: ce,
        api_get_vault_bytes: C,
        api_list_entries: J,
        api_list_labels: oe,
        api_load_vault: K,
        api_lock: q,
        api_purge_entry: le,
        api_regenerate_recovery_key: ie,
        api_rename_label: se,
        api_restore_entry: ue,
        api_rotate_dek: fe,
        api_set_entry_labels: de,
        api_set_favorite: be,
        api_unlock: z,
        api_unlock_with_recovery_key: ge,
        api_update_entry: we,
        api_upgrade_argon2_params: Ae
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    let Z = !1, u = !1;
    async function X() {
        if (!Z) try {
            Z = !0, console.log("[SW] WASM initialized");
        } catch (e) {
            throw console.error("[SW] WASM initialization error:", e), e;
        }
    }
    function $t() {
        console.log("[SW] Setting up message handlers"), chrome.runtime.onMessage.addListener((e, a, r)=>(console.log("[SW] Message received:", e.type), Ft(e, a, r).catch((t)=>{
                console.error("[SW] Unhandled error in message handler:", t);
                try {
                    r({
                        success: !1,
                        error: String(t)
                    });
                } catch (_) {
                    console.error("[SW] Failed to send error response:", _);
                }
            }), !0));
    }
    console.log("[SW] Registering message handlers immediately on script load");
    $t();
    self.addEventListener("install", (e)=>{
        console.log("[SW] install event"), e.waitUntil(X());
    });
    self.addEventListener("activate", (e)=>{
        console.log("[SW] activate event"), e.waitUntil(X().then(()=>{
            console.log("[SW] Calling setupAlarms in activate"), xt();
        }));
    });
    function Se(e) {
        return e && {
            id: e.id,
            entryType: e.entry_type,
            name: e.name,
            isFavorite: e.is_favorite ?? !1,
            updatedAt: e.updated_at ?? 0,
            deletedAt: e.deleted_at ?? null,
            notes: e.notes ?? null,
            typedValue: e.typed_value ?? {},
            labels: e.label_ids ?? [],
            customFields: (e.custom_fields ?? []).map((a)=>({
                    id: a.id,
                    name: a.name,
                    fieldType: a.field_type,
                    value: a.value
                }))
        };
    }
    function R(e) {
        return (e ?? []).map(Se);
    }
    async function y() {
        try {
            console.log("[SW] autoSaveAndPush: Starting");
            const e = C();
            console.log("[SW] autoSaveAndPush: Got vault bytes, size:", e?.length), await p(d.VAULT_BYTES, Array.from(e));
            const a = await m(d.S3_CONFIG);
            if (console.log("[SW] autoSaveAndPush: s3Config exists:", !!a), console.log("[SW] autoSaveAndPush: api_push type:", "undefined"), a) try {
                console.warn("[SW] autoSaveAndPush: api_push not available in WASM");
            } catch (r) {
                console.warn("[SW] Auto-push failed:", r);
            }
            else console.log("[SW] autoSaveAndPush: No S3 config, skipping push");
        } catch (e) {
            console.error("[SW] autoSaveAndPush failed:", e);
        }
    }
    async function L() {
        return await m(d.APP_SETTINGS) || {
            autolockMinutes: 5,
            clipboardClearSeconds: 30,
            clipboardAutoClean: !0,
            theme: "light"
        };
    }
    async function Ft(e, a, r) {
        try {
            switch(await X(), e.type){
                case "IS_UNLOCKED":
                    {
                        r({
                            success: !0,
                            unlocked: u
                        });
                        break;
                    }
                case "UNLOCK":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await m(d.VAULT_BYTES), _ = await m(d.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            K(new Uint8Array(t), _ || ""), z(e.password), u = !0;
                            const c = await L();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UNLOCK_EXISTING":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await m(d.VAULT_BYTES), _ = await m(d.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            K(new Uint8Array(t), _ || ""), z(e.password), u = !0;
                            const c = await L();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LOCK":
                    {
                        try {
                            const t = q();
                            await p(d.VAULT_BYTES, Array.from(t)), u = !1, chrome.alarms.clear("autolock"), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_VAULT":
                    {
                        if (!e.masterPassword) {
                            r({
                                success: !1,
                                error: "Master password required"
                            });
                            break;
                        }
                        try {
                            console.log("[SW] CREATE_VAULT: Starting vault creation"), console.log("[SW] CREATE_VAULT: vault object type:", typeof Q), console.log("[SW] CREATE_VAULT: vault.api_create_new_vault:", typeof x);
                            const t = x(e.masterPassword);
                            console.log("[SW] CREATE_VAULT: Vault created, recovery key:", t);
                            const _ = C();
                            console.log("[SW] CREATE_VAULT: Got vault bytes, size:", _?.length), await p(d.VAULT_BYTES, Array.from(_)), await p(d.VAULT_ETAG, null), console.log("[SW] CREATE_VAULT: Saved vault bytes to storage"), e.s3Config && await p(d.S3_CONFIG, e.s3Config), u = !0;
                            const c = await L();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), console.log("[SW] CREATE_VAULT: Success, sending response");
                            const o = {
                                success: !0,
                                recoveryKey: t
                            };
                            console.log("[SW] CREATE_VAULT: Response payload:", o), r(o), console.log("[SW] CREATE_VAULT: sendResponse called");
                        } catch (t) {
                            console.error("[SW] CREATE_VAULT: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RECOVER":
                    {
                        if (!e.recoveryKey || !e.newPassword) {
                            r({
                                success: !1,
                                error: "Recovery key and password required"
                            });
                            break;
                        }
                        try {
                            ge(e.recoveryKey), F(e.recoveryKey, e.newPassword);
                            const t = C();
                            await p(d.VAULT_BYTES, Array.from(t)), await p(d.VAULT_ETAG, null), await y(), u = !0;
                            const _ = await L();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: _.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_ENTRIES":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = e.filter || {}, _ = J(t.searchQuery || null, t.type || null, t.labelId || null, t.includeTrash || !1, t.onlyFavorites || !1), c = JSON.parse(_), o = R(c);
                            r({
                                success: !0,
                                entries: o
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ce(e.id), _ = JSON.parse(t);
                            _ && _.typed_value && typeof _.typed_value == "string" && (_.typed_value = JSON.parse(_.typed_value));
                            const c = Se(_);
                            r({
                                success: !0,
                                entry: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ee(e.entryType, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null);
                            await y(), r({
                                success: !0,
                                entryId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UPDATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            we(e.id, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            re(e.id), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RESTORE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ue(e.id), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PURGE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            le(e.id), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_FAVORITE":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            be(e.id, e.isFavorite), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_TRASH":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = J(null, null, null, !0, !1), _ = JSON.parse(t), c = R(_);
                            r({
                                success: !0,
                                entries: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = oe(), _ = JSON.parse(t);
                            r({
                                success: !0,
                                labels: _
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = te(e.name);
                            await y(), r({
                                success: !0,
                                labelId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ae(e.id), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RENAME_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            se(e.id, e.newName), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_ENTRY_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            de(e.entryId, e.labelIds || []), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_PASSWORD":
                    {
                        try {
                            const t = ne(e.length ?? 16, e.includeUppercase ?? !0, e.includeLowercase ?? !0, e.includeNumbers ?? !0, e.includeSymbols ?? !0);
                            r({
                                success: !0,
                                password: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_TOTP":
                    {
                        try {
                            const t = _e(e.secret);
                            r({
                                success: !0,
                                totp: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CHANGE_MASTER_PASSWORD":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            F(e.oldPassword, e.newPassword), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "ROTATE_DEK":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = fe(e.password);
                            await y(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "REGENERATE_RECOVERY_KEY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ie(e.password);
                            await y(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DOWNLOAD_VAULT":
                    {
                        try {
                            const t = await m(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            const _ = await (void 0)(JSON.stringify(t)), c = C();
                            await p(d.VAULT_BYTES, Array.from(c)), r({
                                success: !0,
                                vaultExists: _
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PUSH_VAULT":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = await m(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            await (void 0)(JSON.stringify(t)), await p(d.LAST_SYNC_TIME, new Date().toISOString()), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SYNC":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            console.log("[SW] SYNC: Starting sync");
                            const t = await m(d.S3_CONFIG);
                            if (console.log("[SW] SYNC: s3Config:", t), !t) {
                                console.log("[SW] SYNC: No S3 config found"), r({
                                    success: !0,
                                    status: "idle",
                                    message: "S3 config not set"
                                });
                                break;
                            }
                            console.log("[SW] SYNC: vault type:", typeof Q), console.log("[SW] SYNC: api_sync type:", "undefined"), console.log("[SW] SYNC: api_push type:", "undefined");
                            const _ = JSON.stringify(t);
                            throw new Error("Neither api_sync nor api_push is available in WASM");
                        } catch (t) {
                            console.error("[SW] SYNC: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_SETTINGS":
                    {
                        const t = await L();
                        r({
                            success: !0,
                            settings: t
                        });
                        break;
                    }
                case "SAVE_SETTINGS":
                    {
                        try {
                            await p(d.APP_SETTINGS, e.settings), u && chrome.alarms.create("autolock", {
                                delayInMinutes: e.settings.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CLIPBOARD_COPIED":
                    {
                        try {
                            const t = await L();
                            if (t.clipboardAutoClean) {
                                const _ = t.clipboardClearSeconds / 60;
                                chrome.alarms.create("clipboard-clear", {
                                    delayInMinutes: _
                                });
                            }
                            r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                default:
                    r({
                        success: !1,
                        error: "Unknown message type"
                    });
            }
        } catch (t) {
            console.error("[SW] Message handling error:", t), r({
                success: !1,
                error: String(t)
            });
        }
    }
    function xt() {
        chrome.alarms.onAlarm.addListener((e)=>{
            e.name === "autolock" ? Jt() : e.name === "clipboard-clear" && Kt();
        });
    }
    async function Jt() {
        if (console.log("[SW] Autolock alarm triggered"), !!u) try {
            const e = q();
            await p(d.VAULT_BYTES, Array.from(e)), u = !1, console.log("[SW] Vault locked");
        } catch (e) {
            console.error("[SW] Autolock failed:", e);
        }
    }
    async function Kt() {
        console.log("[SW] Clipboard clear alarm triggered");
        try {
            typeof chrome.offscreen < "u" ? (await chrome.offscreen.createDocument({
                url: chrome.runtime.getURL("src/background/offscreen.html"),
                reasons: [
                    "CLIPBOARD"
                ],
                justification: "Clear clipboard after copy timeout"
            }), chrome.runtime.sendMessage({
                type: "CLEAR_CLIPBOARD"
            })) : await navigator.clipboard.writeText("");
        } catch (e) {
            console.error("[SW] Clipboard clear failed:", e);
        }
    }
})();
