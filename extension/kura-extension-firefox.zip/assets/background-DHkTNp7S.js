import { s as S, S as d, g as m } from "./constants-BFP2TXfE.js";
(async ()=>{
    const me = "/assets/vault_core_bg-BR5Sab9T.wasm", Te = async (e = {}, a)=>{
        let r;
        if (a.startsWith("data:")) {
            const t = a.replace(/^data:.*?base64,/, "");
            let c;
            if (typeof Buffer == "function" && typeof Buffer.from == "function") c = Buffer.from(t, "base64");
            else if (typeof atob == "function") {
                const o = atob(t);
                c = new Uint8Array(o.length);
                for(let _ = 0; _ < o.length; _++)c[_] = o.charCodeAt(_);
            } else throw new Error("Cannot decode base64-encoded data URL");
            r = await WebAssembly.instantiate(c, e);
        } else {
            const t = await fetch(a), c = t.headers.get("Content-Type") || "";
            if ("instantiateStreaming" in WebAssembly && c.startsWith("application/wasm")) r = await WebAssembly.instantiateStreaming(t, e);
            else {
                const o = await t.arrayBuffer();
                r = await WebAssembly.instantiate(o, e);
            }
        }
        return r.instance.exports;
    };
    function F(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = i, c = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), o = i, _ = n.api_change_master_password(r, t, c, o);
        if (_[1]) throw f(_[0]);
    }
    function ee(e, a, r, t, c, o) {
        let _, l;
        try {
            const A = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), T = i, D = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), G = i;
            var b = w(r) ? 0 : s(r, n.__wbindgen_malloc, n.__wbindgen_realloc), g = i;
            const B = s(t, n.__wbindgen_malloc, n.__wbindgen_realloc), pe = i, he = H(c, n.__wbindgen_malloc), ve = i;
            var h = w(o) ? 0 : s(o, n.__wbindgen_malloc, n.__wbindgen_realloc), N = i;
            const M = n.api_create_entry(A, T, D, G, b, g, B, pe, he, ve, h, N);
            var k = M[0], v = M[1];
            if (M[3]) throw k = 0, v = 0, f(M[2]);
            return _ = k, l = v, p(k, v);
        } finally{
            n.__wbindgen_free(_, l, 1);
        }
    }
    function te(e) {
        let a, r;
        try {
            const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), _ = i, l = n.api_create_label(o, _);
            var t = l[0], c = l[1];
            if (l[3]) throw t = 0, c = 0, f(l[2]);
            return a = t, r = c, p(t, c);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function x(e) {
        let a, r;
        try {
            const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), _ = i, l = n.api_create_new_vault(o, _);
            var t = l[0], c = l[1];
            if (l[3]) throw t = 0, c = 0, f(l[2]);
            return a = t, r = c, p(t, c);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function re(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = i, t = n.api_delete_entry(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ae(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = i, t = n.api_delete_label(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ne(e, a, r, t, c) {
        let o, _;
        try {
            const g = n.api_generate_password(e, a, r, t, c);
            var l = g[0], b = g[1];
            if (g[3]) throw l = 0, b = 0, f(g[2]);
            return o = l, _ = b, p(l, b);
        } finally{
            n.__wbindgen_free(o, _, 1);
        }
    }
    function ke(e, a, r) {
        let t, c;
        try {
            const l = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), b = i, g = n.api_generate_totp(l, b, a, r);
            var o = g[0], _ = g[1];
            if (g[3]) throw o = 0, _ = 0, f(g[2]);
            return t = o, c = _, p(o, _);
        } finally{
            n.__wbindgen_free(t, c, 1);
        }
    }
    function ce(e) {
        let a, r;
        try {
            const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), _ = i, l = n.api_generate_totp_default(o, _);
            var t = l[0], c = l[1];
            if (l[3]) throw t = 0, c = 0, f(l[2]);
            return a = t, r = c, p(t, c);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function _e(e) {
        let a, r;
        try {
            const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), _ = i, l = n.api_get_entry(o, _);
            var t = l[0], c = l[1];
            if (l[3]) throw t = 0, c = 0, f(l[2]);
            return a = t, r = c, p(t, c);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function C() {
        const e = n.api_get_vault_bytes();
        if (e[3]) throw f(e[2]);
        var a = U(e[0], e[1]).slice();
        return n.__wbindgen_free(e[0], e[1] * 1, 1), a;
    }
    function J(e, a, r, t, c) {
        let o, _;
        try {
            var l = w(e) ? 0 : s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), b = i, g = w(a) ? 0 : s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), h = i, N = w(r) ? 0 : s(r, n.__wbindgen_malloc, n.__wbindgen_realloc), k = i;
            const T = n.api_list_entries(l, b, g, h, N, k, t, c);
            var v = T[0], A = T[1];
            if (T[3]) throw v = 0, A = 0, f(T[2]);
            return o = v, _ = A, p(v, A);
        } finally{
            n.__wbindgen_free(o, _, 1);
        }
    }
    function oe() {
        let e, a;
        try {
            const c = n.api_list_labels();
            var r = c[0], t = c[1];
            if (c[3]) throw r = 0, t = 0, f(c[2]);
            return e = r, a = t, p(r, t);
        } finally{
            n.__wbindgen_free(e, a, 1);
        }
    }
    function K(e, a) {
        const r = tt(e, n.__wbindgen_malloc), t = i, c = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), o = i, _ = n.api_load_vault(r, t, c, o);
        if (_[1]) throw f(_[0]);
    }
    function q() {
        const e = n.api_lock();
        if (e[3]) throw f(e[2]);
        var a = U(e[0], e[1]).slice();
        return n.__wbindgen_free(e[0], e[1] * 1, 1), a;
    }
    function le(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = i, t = n.api_purge_entry(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ie(e) {
        let a, r;
        try {
            const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), _ = i, l = n.api_regenerate_recovery_key(o, _);
            var t = l[0], c = l[1];
            if (l[3]) throw t = 0, c = 0, f(l[2]);
            return a = t, r = c, p(t, c);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function se(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = i, c = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), o = i, _ = n.api_rename_label(r, t, c, o);
        if (_[1]) throw f(_[0]);
    }
    function ue(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = i, t = n.api_restore_entry(a, r);
        if (t[1]) throw f(t[0]);
    }
    function fe(e) {
        let a, r;
        try {
            const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), _ = i, l = n.api_rotate_dek(o, _);
            var t = l[0], c = l[1];
            if (l[3]) throw t = 0, c = 0, f(l[2]);
            return a = t, r = c, p(t, c);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function de(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = i, c = H(a, n.__wbindgen_malloc), o = i, _ = n.api_set_entry_labels(r, t, c, o);
        if (_[1]) throw f(_[0]);
    }
    function be(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = i, c = n.api_set_favorite(r, t, a);
        if (c[1]) throw f(c[0]);
    }
    function z(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = i, t = n.api_unlock(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ge(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = i, t = n.api_unlock_with_recovery_key(a, r);
        if (t[1]) throw f(t[0]);
    }
    function we(e, a, r, t, c, o) {
        const _ = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), l = i;
        var b = w(a) ? 0 : s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), g = i, h = w(r) ? 0 : s(r, n.__wbindgen_malloc, n.__wbindgen_realloc), N = i, k = w(t) ? 0 : s(t, n.__wbindgen_malloc, n.__wbindgen_realloc), v = i, A = w(c) ? 0 : H(c, n.__wbindgen_malloc), T = i, D = w(o) ? 0 : s(o, n.__wbindgen_malloc, n.__wbindgen_realloc), G = i;
        const B = n.api_update_entry(_, l, b, g, h, N, k, v, A, T, D, G);
        if (B[1]) throw f(B[0]);
    }
    function Ae(e, a, r, t) {
        let c, o;
        try {
            const b = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), g = i, h = n.api_upgrade_argon2_params(b, g, a, r, t);
            var _ = h[0], l = h[1];
            if (h[3]) throw _ = 0, l = 0, f(h[2]);
            return c = _, o = l, p(_, l);
        } finally{
            n.__wbindgen_free(c, o, 1);
        }
    }
    function Ee(e) {
        return typeof e == "function";
    }
    function Le(e) {
        const a = e;
        return typeof a == "object" && a !== null;
    }
    function Ce(e) {
        return typeof e == "string";
    }
    function We(e) {
        return e === void 0;
    }
    function Ve(e, a) {
        const r = a, t = typeof r == "string" ? r : void 0;
        var c = w(t) ? 0 : s(t, n.__wbindgen_malloc, n.__wbindgen_realloc), o = i;
        j().setInt32(e + 4 * 1, o, !0), j().setInt32(e + 4 * 0, c, !0);
    }
    function Ne(e, a) {
        throw new Error(p(e, a));
    }
    function Oe() {
        return I(function(e, a, r) {
            return e.call(a, r);
        }, arguments);
    }
    function Ue(e) {
        return e.crypto;
    }
    function Ie() {
        return I(function(e, a) {
            globalThis.crypto.getRandomValues(U(e, a));
        }, arguments);
    }
    function Be() {
        return I(function(e, a) {
            e.getRandomValues(a);
        }, arguments);
    }
    function Me(e) {
        return e.getTime();
    }
    function Ye(e) {
        return e.length;
    }
    function Pe(e) {
        return e.msCrypto;
    }
    function De() {
        return new Date;
    }
    function Ge(e) {
        return new Uint8Array(e >>> 0);
    }
    function $e(e) {
        return e.node;
    }
    function Fe(e) {
        return e.process;
    }
    function xe(e, a, r) {
        Uint8Array.prototype.set.call(U(e, a), r);
    }
    function Je() {
        return I(function(e, a) {
            e.randomFillSync(a);
        }, arguments);
    }
    function Ke() {
        return I(function() {
            return module.require;
        }, arguments);
    }
    function ze() {
        const e = typeof global > "u" ? null : global;
        return w(e) ? 0 : V(e);
    }
    function je() {
        const e = typeof globalThis > "u" ? null : globalThis;
        return w(e) ? 0 : V(e);
    }
    function qe() {
        const e = typeof self > "u" ? null : self;
        return w(e) ? 0 : V(e);
    }
    function He() {
        const e = typeof window > "u" ? null : window;
        return w(e) ? 0 : V(e);
    }
    function Xe(e, a, r) {
        return e.subarray(a >>> 0, r >>> 0);
    }
    function Qe(e) {
        return e.versions;
    }
    function Ze(e, a) {
        return U(e, a);
    }
    function Re(e, a) {
        return p(e, a);
    }
    function et() {
        const e = n.__wbindgen_externrefs, a = e.grow(4);
        e.set(0, void 0), e.set(a + 0, void 0), e.set(a + 1, null), e.set(a + 2, !0), e.set(a + 3, !1);
    }
    function V(e) {
        const a = n.__externref_table_alloc();
        return n.__wbindgen_externrefs.set(a, e), a;
    }
    function U(e, a) {
        return e = e >>> 0, W().subarray(e / 1, e / 1 + a);
    }
    let E = null;
    function j() {
        return (E === null || E.buffer.detached === !0 || E.buffer.detached === void 0 && E.buffer !== n.memory.buffer) && (E = new DataView(n.memory.buffer)), E;
    }
    function p(e, a) {
        return e = e >>> 0, at(e, a);
    }
    let Y = null;
    function W() {
        return (Y === null || Y.byteLength === 0) && (Y = new Uint8Array(n.memory.buffer)), Y;
    }
    function I(e, a) {
        try {
            return e.apply(this, a);
        } catch (r) {
            const t = V(r);
            n.__wbindgen_exn_store(t);
        }
    }
    function w(e) {
        return e == null;
    }
    function tt(e, a) {
        const r = a(e.length * 1, 1) >>> 0;
        return W().set(e, r / 1), i = e.length, r;
    }
    function H(e, a) {
        const r = a(e.length * 4, 4) >>> 0;
        for(let t = 0; t < e.length; t++){
            const c = V(e[t]);
            j().setUint32(r + 4 * t, c, !0);
        }
        return i = e.length, r;
    }
    function s(e, a, r) {
        if (r === void 0) {
            const l = O.encode(e), b = a(l.length, 1) >>> 0;
            return W().subarray(b, b + l.length).set(l), i = l.length, b;
        }
        let t = e.length, c = a(t, 1) >>> 0;
        const o = W();
        let _ = 0;
        for(; _ < t; _++){
            const l = e.charCodeAt(_);
            if (l > 127) break;
            o[c + _] = l;
        }
        if (_ !== t) {
            _ !== 0 && (e = e.slice(_)), c = r(c, t, t = _ + e.length * 3, 1) >>> 0;
            const l = W().subarray(c + _, c + t), b = O.encodeInto(e, l);
            _ += b.written, c = r(c, t, _, 1) >>> 0;
        }
        return i = _, c;
    }
    function f(e) {
        const a = n.__wbindgen_externrefs.get(e);
        return n.__externref_table_dealloc(e), a;
    }
    let P = new TextDecoder("utf-8", {
        ignoreBOM: !0,
        fatal: !0
    });
    P.decode();
    const rt = 2146435072;
    let $ = 0;
    function at(e, a) {
        return $ += a, $ >= rt && (P = new TextDecoder("utf-8", {
            ignoreBOM: !0,
            fatal: !0
        }), P.decode(), $ = a), P.decode(W().subarray(e, e + a));
    }
    const O = new TextEncoder;
    "encodeInto" in O || (O.encodeInto = function(e, a) {
        const r = O.encode(e);
        return a.set(r), {
            read: e.length,
            written: r.length
        };
    });
    let i = 0, n;
    function nt(e) {
        n = e;
    }
    URL = globalThis.URL;
    const ct = await Te({
        "./vault_core_bg.js": {
            __wbg_getRandomValues_a1cf2e70b003a59d: Ie,
            __wbg_crypto_38df2bab126b63dc: Ue,
            __wbg_process_44c7a14e11e9f69e: Fe,
            __wbg_versions_276b2795b1c6a219: Qe,
            __wbg_node_84ea875411254db1: $e,
            __wbg_require_b4edbdcf3e2a1ef0: Ke,
            __wbg_call_2d781c1f4d5c0ef8: Oe,
            __wbg_msCrypto_bd5a034af96bcba6: Pe,
            __wbg_randomFillSync_6c25eac9869eb53c: Je,
            __wbg_getRandomValues_c44a50d8cfdaebeb: Be,
            __wbg_length_ea16607d7b61445b: Ye,
            __wbg_prototypesetcall_d62e5099504357e6: xe,
            __wbg_new_with_length_825018a1616e9e55: Ge,
            __wbg_subarray_a068d24e39478a8a: Xe,
            __wbg_new_0_1dcafdf5e786e876: De,
            __wbg_getTime_1dad7b5386ddd2d9: Me,
            __wbg_static_accessor_GLOBAL_THIS_ad356e0db91c7913: je,
            __wbg_static_accessor_SELF_f207c857566db248: qe,
            __wbg_static_accessor_GLOBAL_8adb955bd33fac2f: ze,
            __wbg_static_accessor_WINDOW_bb9f1ba69d61b386: He,
            __wbg___wbindgen_throw_6ddd609b62940d55: Ne,
            __wbg___wbindgen_is_object_781bc9f159099513: Le,
            __wbg___wbindgen_is_string_7ef6b97b02428fae: Ce,
            __wbg___wbindgen_string_get_395e606bd0ee4427: Ve,
            __wbg___wbindgen_is_function_3c846841762788c1: Ee,
            __wbg___wbindgen_is_undefined_52709e72fb9f179c: We,
            __wbindgen_init_externref_table: et,
            __wbindgen_cast_0000000000000001: Ze,
            __wbindgen_cast_0000000000000002: Re
        }
    }, me), { memory: _t, api_change_master_password: ot, api_create_entry: lt, api_create_label: it, api_create_new_vault: st, api_delete_entry: ut, api_delete_label: ft, api_generate_password: dt, api_generate_totp: bt, api_generate_totp_default: gt, api_get_entry: wt, api_get_vault_bytes: yt, api_list_entries: St, api_list_labels: pt, api_load_vault: ht, api_lock: vt, api_purge_entry: mt, api_regenerate_recovery_key: Tt, api_rename_label: kt, api_restore_entry: At, api_rotate_dek: Et, api_set_entry_labels: Lt, api_set_favorite: Ct, api_unlock: Wt, api_unlock_with_recovery_key: Vt, api_update_entry: Nt, api_upgrade_argon2_params: Ot, __wbindgen_malloc: Ut, __wbindgen_realloc: It, __wbindgen_exn_store: Bt, __externref_table_alloc: Mt, __wbindgen_externrefs: Yt, __externref_table_dealloc: Pt, __wbindgen_free: Dt, __wbindgen_start: ye } = ct, Gt = Object.freeze(Object.defineProperty({
        __proto__: null,
        __externref_table_alloc: Mt,
        __externref_table_dealloc: Pt,
        __wbindgen_exn_store: Bt,
        __wbindgen_externrefs: Yt,
        __wbindgen_free: Dt,
        __wbindgen_malloc: Ut,
        __wbindgen_realloc: It,
        __wbindgen_start: ye,
        api_change_master_password: ot,
        api_create_entry: lt,
        api_create_label: it,
        api_create_new_vault: st,
        api_delete_entry: ut,
        api_delete_label: ft,
        api_generate_password: dt,
        api_generate_totp: bt,
        api_generate_totp_default: gt,
        api_get_entry: wt,
        api_get_vault_bytes: yt,
        api_list_entries: St,
        api_list_labels: pt,
        api_load_vault: ht,
        api_lock: vt,
        api_purge_entry: mt,
        api_regenerate_recovery_key: Tt,
        api_rename_label: kt,
        api_restore_entry: At,
        api_rotate_dek: Et,
        api_set_entry_labels: Lt,
        api_set_favorite: Ct,
        api_unlock: Wt,
        api_unlock_with_recovery_key: Vt,
        api_update_entry: Nt,
        api_upgrade_argon2_params: Ot,
        memory: _t
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    nt(Gt);
    ye();
    const Q = Object.freeze(Object.defineProperty({
        __proto__: null,
        api_change_master_password: F,
        api_create_entry: ee,
        api_create_label: te,
        api_create_new_vault: x,
        api_delete_entry: re,
        api_delete_label: ae,
        api_generate_password: ne,
        api_generate_totp: ke,
        api_generate_totp_default: ce,
        api_get_entry: _e,
        api_get_vault_bytes: C,
        api_list_entries: J,
        api_list_labels: oe,
        api_load_vault: K,
        api_lock: q,
        api_purge_entry: le,
        api_regenerate_recovery_key: ie,
        api_rename_label: se,
        api_restore_entry: ue,
        api_rotate_dek: fe,
        api_set_entry_labels: de,
        api_set_favorite: be,
        api_unlock: z,
        api_unlock_with_recovery_key: ge,
        api_update_entry: we,
        api_upgrade_argon2_params: Ae
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    let Z = !1, u = !1;
    async function X() {
        if (!Z) try {
            Z = !0, console.log("[SW] WASM initialized");
        } catch (e) {
            throw console.error("[SW] WASM initialization error:", e), e;
        }
    }
    function $t() {
        console.log("[SW] Setting up message handlers"), chrome.runtime.onMessage.addListener((e, a, r)=>(console.log("[SW] Message received:", e.type), Ft(e, a, r).catch((t)=>{
                console.error("[SW] Unhandled error in message handler:", t);
                try {
                    r({
                        success: !1,
                        error: String(t)
                    });
                } catch (c) {
                    console.error("[SW] Failed to send error response:", c);
                }
            }), !0));
    }
    console.log("[SW] Registering message handlers immediately on script load");
    $t();
    self.addEventListener("install", (e)=>{
        console.log("[SW] install event"), e.waitUntil(X());
    });
    self.addEventListener("activate", (e)=>{
        console.log("[SW] activate event"), e.waitUntil(X().then(()=>{
            console.log("[SW] Calling setupAlarms in activate"), xt();
        }));
    });
    function Se(e) {
        return e && {
            id: e.id,
            entryType: e.entry_type,
            name: e.name,
            isFavorite: e.is_favorite ?? !1,
            updatedAt: e.updated_at ?? 0,
            deletedAt: e.deleted_at ?? null,
            notes: e.notes ?? null,
            typedValue: e.typed_value ?? {},
            labels: e.label_ids ?? [],
            customFields: (e.custom_fields ?? []).map((a)=>({
                    id: a.id,
                    name: a.name,
                    fieldType: a.field_type,
                    value: a.value
                }))
        };
    }
    function R(e) {
        return (e ?? []).map(Se);
    }
    async function y() {
        try {
            console.log("[SW] autoSaveAndPush: Starting");
            const e = C();
            console.log("[SW] autoSaveAndPush: Got vault bytes, size:", e?.length), await S(d.VAULT_BYTES, Array.from(e));
            const a = await m(d.S3_CONFIG);
            if (console.log("[SW] autoSaveAndPush: s3Config exists:", !!a), a) try {
                console.log("[SW] autoSaveAndPush: Calling api_push");
                const r = await (void 0)(JSON.stringify(a));
                console.log("[SW] autoSaveAndPush: api_push returned:", r), await S(d.LAST_SYNC_TIME, new Date().toISOString()), console.log("[SW] Auto-push successful");
            } catch (r) {
                console.warn("[SW] Auto-push failed:", r);
            }
            else console.log("[SW] autoSaveAndPush: No S3 config, skipping push");
        } catch (e) {
            console.error("[SW] autoSaveAndPush failed:", e);
        }
    }
    async function L() {
        return await m(d.APP_SETTINGS) || {
            autolockMinutes: 5,
            clipboardClearSeconds: 30,
            clipboardAutoClean: !0,
            theme: "light"
        };
    }
    async function Ft(e, a, r) {
        try {
            switch(await X(), e.type){
                case "IS_UNLOCKED":
                    {
                        r({
                            success: !0,
                            unlocked: u
                        });
                        break;
                    }
                case "UNLOCK":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await m(d.VAULT_BYTES), c = await m(d.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            K(new Uint8Array(t), c || ""), z(e.password), u = !0;
                            const o = await L();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: o.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UNLOCK_EXISTING":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await m(d.VAULT_BYTES), c = await m(d.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            K(new Uint8Array(t), c || ""), z(e.password), u = !0;
                            const o = await L();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: o.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LOCK":
                    {
                        try {
                            const t = q();
                            await S(d.VAULT_BYTES, Array.from(t)), u = !1, chrome.alarms.clear("autolock"), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_VAULT":
                    {
                        if (!e.masterPassword) {
                            r({
                                success: !1,
                                error: "Master password required"
                            });
                            break;
                        }
                        try {
                            console.log("[SW] CREATE_VAULT: Starting vault creation"), console.log("[SW] CREATE_VAULT: vault object type:", typeof Q), console.log("[SW] CREATE_VAULT: vault.api_create_new_vault:", typeof x);
                            const t = x(e.masterPassword);
                            console.log("[SW] CREATE_VAULT: Vault created, recovery key:", t);
                            const c = C();
                            console.log("[SW] CREATE_VAULT: Got vault bytes, size:", c?.length), await S(d.VAULT_BYTES, Array.from(c)), await S(d.VAULT_ETAG, null), console.log("[SW] CREATE_VAULT: Saved vault bytes to storage"), e.s3Config && await S(d.S3_CONFIG, e.s3Config), u = !0;
                            const o = await L();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: o.autolockMinutes
                            }), console.log("[SW] CREATE_VAULT: Success, sending response");
                            const _ = {
                                success: !0,
                                recoveryKey: t
                            };
                            console.log("[SW] CREATE_VAULT: Response payload:", _), r(_), console.log("[SW] CREATE_VAULT: sendResponse called");
                        } catch (t) {
                            console.error("[SW] CREATE_VAULT: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RECOVER":
                    {
                        if (!e.recoveryKey || !e.newPassword) {
                            r({
                                success: !1,
                                error: "Recovery key and password required"
                            });
                            break;
                        }
                        try {
                            ge(e.recoveryKey), F(e.recoveryKey, e.newPassword);
                            const t = C();
                            await S(d.VAULT_BYTES, Array.from(t)), await S(d.VAULT_ETAG, null), await y(), u = !0;
                            const c = await L();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_ENTRIES":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = e.filter || {}, c = J(t.searchQuery || null, t.type || null, t.labelId || null, t.includeTrash || !1, t.onlyFavorites || !1), o = JSON.parse(c), _ = R(o);
                            r({
                                success: !0,
                                entries: _
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = _e(e.id), c = JSON.parse(t);
                            c && c.typed_value && typeof c.typed_value == "string" && (c.typed_value = JSON.parse(c.typed_value));
                            const o = Se(c);
                            r({
                                success: !0,
                                entry: o
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ee(e.entryType, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null);
                            await y(), r({
                                success: !0,
                                entryId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UPDATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            we(e.id, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            re(e.id), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RESTORE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ue(e.id), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PURGE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            le(e.id), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_FAVORITE":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            be(e.id, e.isFavorite), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_TRASH":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = J(null, null, null, !0, !1), c = JSON.parse(t), o = R(c);
                            r({
                                success: !0,
                                entries: o
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = oe(), c = JSON.parse(t);
                            r({
                                success: !0,
                                labels: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = te(e.name);
                            await y(), r({
                                success: !0,
                                labelId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ae(e.id), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RENAME_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            se(e.id, e.newName), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_ENTRY_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            de(e.entryId, e.labelIds || []), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_PASSWORD":
                    {
                        try {
                            const t = ne(e.length ?? 16, e.includeUppercase ?? !0, e.includeLowercase ?? !0, e.includeNumbers ?? !0, e.includeSymbols ?? !0);
                            r({
                                success: !0,
                                password: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_TOTP":
                    {
                        try {
                            const t = ce(e.secret);
                            r({
                                success: !0,
                                totp: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CHANGE_MASTER_PASSWORD":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            F(e.oldPassword, e.newPassword), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "ROTATE_DEK":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = fe(e.password);
                            await y(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "REGENERATE_RECOVERY_KEY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ie(e.password);
                            await y(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DOWNLOAD_VAULT":
                    {
                        try {
                            const t = await m(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            const c = await (void 0)(JSON.stringify(t)), o = C();
                            await S(d.VAULT_BYTES, Array.from(o)), r({
                                success: !0,
                                vaultExists: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PUSH_VAULT":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = await m(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            await (void 0)(JSON.stringify(t)), await S(d.LAST_SYNC_TIME, new Date().toISOString()), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SYNC":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            console.log("[SW] SYNC: Starting sync");
                            const t = await m(d.S3_CONFIG);
                            if (console.log("[SW] SYNC: s3Config:", t), !t) {
                                console.log("[SW] SYNC: No S3 config found"), r({
                                    success: !0,
                                    status: "idle",
                                    message: "S3 config not set"
                                });
                                break;
                            }
                            console.log("[SW] SYNC: vault type:", typeof Q), console.log("[SW] SYNC: api_sync type:", "undefined");
                            const c = JSON.stringify(t);
                            console.log("[SW] SYNC: Calling api_sync with config");
                            const o = await (void 0)(c);
                            console.log("[SW] SYNC: api_sync returned:", o);
                            const _ = C();
                            console.log("[SW] SYNC: Got vault bytes, size:", _?.length), await S(d.VAULT_BYTES, Array.from(_)), await S(d.LAST_SYNC_TIME, new Date().toISOString()), console.log("[SW] SYNC: Sync completed successfully"), r({
                                success: !0,
                                status: "synced"
                            });
                        } catch (t) {
                            console.error("[SW] SYNC: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_SETTINGS":
                    {
                        const t = await L();
                        r({
                            success: !0,
                            settings: t
                        });
                        break;
                    }
                case "SAVE_SETTINGS":
                    {
                        try {
                            await S(d.APP_SETTINGS, e.settings), u && chrome.alarms.create("autolock", {
                                delayInMinutes: e.settings.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CLIPBOARD_COPIED":
                    {
                        try {
                            const t = await L();
                            if (t.clipboardAutoClean) {
                                const c = t.clipboardClearSeconds / 60;
                                chrome.alarms.create("clipboard-clear", {
                                    delayInMinutes: c
                                });
                            }
                            r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                default:
                    r({
                        success: !1,
                        error: "Unknown message type"
                    });
            }
        } catch (t) {
            console.error("[SW] Message handling error:", t), r({
                success: !1,
                error: String(t)
            });
        }
    }
    function xt() {
        chrome.alarms.onAlarm.addListener((e)=>{
            e.name === "autolock" ? Jt() : e.name === "clipboard-clear" && Kt();
        });
    }
    async function Jt() {
        if (console.log("[SW] Autolock alarm triggered"), !!u) try {
            const e = q();
            await S(d.VAULT_BYTES, Array.from(e)), u = !1, console.log("[SW] Vault locked");
        } catch (e) {
            console.error("[SW] Autolock failed:", e);
        }
    }
    async function Kt() {
        console.log("[SW] Clipboard clear alarm triggered");
        try {
            typeof chrome.offscreen < "u" ? (await chrome.offscreen.createDocument({
                url: chrome.runtime.getURL("src/background/offscreen.html"),
                reasons: [
                    "CLIPBOARD"
                ],
                justification: "Clear clipboard after copy timeout"
            }), chrome.runtime.sendMessage({
                type: "CLEAR_CLIPBOARD"
            })) : await navigator.clipboard.writeText("");
        } catch (e) {
            console.error("[SW] Clipboard clear failed:", e);
        }
    }
})();
