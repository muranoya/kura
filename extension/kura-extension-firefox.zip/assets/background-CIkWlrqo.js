import { s as p, S as b, g as A } from "./constants-BFP2TXfE.js";
(async ()=>{
    const Ee = "/assets/vault_core_bg-VLzsfBdv.wasm", Le = async (e = {}, n)=>{
        let r;
        if (n.startsWith("data:")) {
            const t = n.replace(/^data:.*?base64,/, "");
            let a;
            if (typeof Buffer == "function" && typeof Buffer.from == "function") a = Buffer.from(t, "base64");
            else if (typeof atob == "function") {
                const c = atob(t);
                a = new Uint8Array(c.length);
                for(let o = 0; o < c.length; o++)a[o] = c.charCodeAt(o);
            } else throw new Error("Cannot decode base64-encoded data URL");
            r = await WebAssembly.instantiate(a, e);
        } else {
            const t = await fetch(n), a = t.headers.get("Content-Type") || "";
            if ("instantiateStreaming" in WebAssembly && a.startsWith("application/wasm")) r = await WebAssembly.instantiateStreaming(t, e);
            else {
                const c = await t.arrayBuffer();
                r = await WebAssembly.instantiate(c, e);
            }
        }
        return r.instance.exports;
    };
    function q(e, n) {
        const r = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), t = l, a = s(n, _.__wbindgen_malloc, _.__wbindgen_realloc), c = l, o = _.api_change_master_password(r, t, a, c);
        if (o[1]) throw f(o[0]);
    }
    function ne(e, n, r, t, a, c) {
        let o, i;
        try {
            const E = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), k = l, F = s(n, _.__wbindgen_malloc, _.__wbindgen_realloc), G = l;
            var d = y(r) ? 0 : s(r, _.__wbindgen_malloc, _.__wbindgen_realloc), w = l;
            const B = s(t, _.__wbindgen_malloc, _.__wbindgen_realloc), Ae = l, ke = Z(a, _.__wbindgen_malloc), Te = l;
            var h = y(c) ? 0 : s(c, _.__wbindgen_malloc, _.__wbindgen_realloc), M = l;
            const D = _.api_create_entry(E, k, F, G, d, w, B, Ae, ke, Te, h, M);
            var T = D[0], v = D[1];
            if (D[3]) throw T = 0, v = 0, f(D[2]);
            return o = T, i = v, g(T, v);
        } finally{
            _.__wbindgen_free(o, i, 1);
        }
    }
    function _e(e) {
        let n, r;
        try {
            const c = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), o = l, i = _.api_create_label(c, o);
            var t = i[0], a = i[1];
            if (i[3]) throw t = 0, a = 0, f(i[2]);
            return n = t, r = a, g(t, a);
        } finally{
            _.__wbindgen_free(n, r, 1);
        }
    }
    function J(e) {
        let n, r;
        try {
            const c = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), o = l, i = _.api_create_new_vault(c, o);
            var t = i[0], a = i[1];
            if (i[3]) throw t = 0, a = 0, f(i[2]);
            return n = t, r = a, g(t, a);
        } finally{
            _.__wbindgen_free(n, r, 1);
        }
    }
    function ae(e) {
        const n = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), r = l, t = _.api_delete_entry(n, r);
        if (t[1]) throw f(t[0]);
    }
    function ce(e) {
        const n = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), r = l, t = _.api_delete_label(n, r);
        if (t[1]) throw f(t[0]);
    }
    function j(e) {
        const n = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), r = l;
        return _.api_download(n, r);
    }
    function oe(e, n, r, t, a) {
        let c, o;
        try {
            const w = _.api_generate_password(e, n, r, t, a);
            var i = w[0], d = w[1];
            if (w[3]) throw i = 0, d = 0, f(w[2]);
            return c = i, o = d, g(i, d);
        } finally{
            _.__wbindgen_free(c, o, 1);
        }
    }
    function We(e, n, r) {
        let t, a;
        try {
            const i = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), d = l, w = _.api_generate_totp(i, d, n, r);
            var c = w[0], o = w[1];
            if (w[3]) throw c = 0, o = 0, f(w[2]);
            return t = c, a = o, g(c, o);
        } finally{
            _.__wbindgen_free(t, a, 1);
        }
    }
    function ie(e) {
        let n, r;
        try {
            const c = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), o = l, i = _.api_generate_totp_default(c, o);
            var t = i[0], a = i[1];
            if (i[3]) throw t = 0, a = 0, f(i[2]);
            return n = t, r = a, g(t, a);
        } finally{
            _.__wbindgen_free(n, r, 1);
        }
    }
    function le(e) {
        let n, r;
        try {
            const c = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), o = l, i = _.api_get_entry(c, o);
            var t = i[0], a = i[1];
            if (i[3]) throw t = 0, a = 0, f(i[2]);
            return n = t, r = a, g(t, a);
        } finally{
            _.__wbindgen_free(n, r, 1);
        }
    }
    function O() {
        const e = _.api_get_vault_bytes();
        if (e[3]) throw f(e[2]);
        var n = I(e[0], e[1]).slice();
        return _.__wbindgen_free(e[0], e[1] * 1, 1), n;
    }
    function z(e, n, r, t, a) {
        let c, o;
        try {
            var i = y(e) ? 0 : s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), d = l, w = y(n) ? 0 : s(n, _.__wbindgen_malloc, _.__wbindgen_realloc), h = l, M = y(r) ? 0 : s(r, _.__wbindgen_malloc, _.__wbindgen_realloc), T = l;
            const k = _.api_list_entries(i, d, w, h, M, T, t, a);
            var v = k[0], E = k[1];
            if (k[3]) throw v = 0, E = 0, f(k[2]);
            return c = v, o = E, g(v, E);
        } finally{
            _.__wbindgen_free(c, o, 1);
        }
    }
    function se() {
        let e, n;
        try {
            const a = _.api_list_labels();
            var r = a[0], t = a[1];
            if (a[3]) throw r = 0, t = 0, f(a[2]);
            return e = r, n = t, g(r, t);
        } finally{
            _.__wbindgen_free(e, n, 1);
        }
    }
    function K(e, n) {
        const r = Mt(e, _.__wbindgen_malloc), t = l, a = s(n, _.__wbindgen_malloc, _.__wbindgen_realloc), c = l, o = _.api_load_vault(r, t, a, c);
        if (o[1]) throw f(o[0]);
    }
    function Q() {
        const e = _.api_lock();
        if (e[3]) throw f(e[2]);
        var n = I(e[0], e[1]).slice();
        return _.__wbindgen_free(e[0], e[1] * 1, 1), n;
    }
    function ue(e) {
        const n = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), r = l, t = _.api_purge_entry(n, r);
        if (t[1]) throw f(t[0]);
    }
    function L(e) {
        const n = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), r = l;
        return _.api_push(n, r);
    }
    function fe(e) {
        let n, r;
        try {
            const c = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), o = l, i = _.api_regenerate_recovery_key(c, o);
            var t = i[0], a = i[1];
            if (i[3]) throw t = 0, a = 0, f(i[2]);
            return n = t, r = a, g(t, a);
        } finally{
            _.__wbindgen_free(n, r, 1);
        }
    }
    function be(e, n) {
        const r = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), t = l, a = s(n, _.__wbindgen_malloc, _.__wbindgen_realloc), c = l, o = _.api_rename_label(r, t, a, c);
        if (o[1]) throw f(o[0]);
    }
    function de(e) {
        const n = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), r = l, t = _.api_restore_entry(n, r);
        if (t[1]) throw f(t[0]);
    }
    function ge(e) {
        let n, r;
        try {
            const c = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), o = l, i = _.api_rotate_dek(c, o);
            var t = i[0], a = i[1];
            if (i[3]) throw t = 0, a = 0, f(i[2]);
            return n = t, r = a, g(t, a);
        } finally{
            _.__wbindgen_free(n, r, 1);
        }
    }
    function we(e, n) {
        const r = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), t = l, a = Z(n, _.__wbindgen_malloc), c = l, o = _.api_set_entry_labels(r, t, a, c);
        if (o[1]) throw f(o[0]);
    }
    function ye(e, n) {
        const r = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), t = l, a = _.api_set_favorite(r, t, n);
        if (a[1]) throw f(a[0]);
    }
    function Se(e) {
        const n = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), r = l;
        return _.api_sync(n, r);
    }
    function H(e) {
        const n = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), r = l, t = _.api_unlock(n, r);
        if (t[1]) throw f(t[0]);
    }
    function pe(e) {
        const n = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), r = l, t = _.api_unlock_with_recovery_key(n, r);
        if (t[1]) throw f(t[0]);
    }
    function he(e, n, r, t, a, c) {
        const o = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), i = l;
        var d = y(n) ? 0 : s(n, _.__wbindgen_malloc, _.__wbindgen_realloc), w = l, h = y(r) ? 0 : s(r, _.__wbindgen_malloc, _.__wbindgen_realloc), M = l, T = y(t) ? 0 : s(t, _.__wbindgen_malloc, _.__wbindgen_realloc), v = l, E = y(a) ? 0 : Z(a, _.__wbindgen_malloc), k = l, F = y(c) ? 0 : s(c, _.__wbindgen_malloc, _.__wbindgen_realloc), G = l;
        const B = _.api_update_entry(o, i, d, w, h, M, T, v, E, k, F, G);
        if (B[1]) throw f(B[0]);
    }
    function Ve(e, n, r, t) {
        let a, c;
        try {
            const d = s(e, _.__wbindgen_malloc, _.__wbindgen_realloc), w = l, h = _.api_upgrade_argon2_params(d, w, n, r, t);
            var o = h[0], i = h[1];
            if (h[3]) throw o = 0, i = 0, f(h[2]);
            return a = o, c = i, g(o, i);
        } finally{
            _.__wbindgen_free(a, c, 1);
        }
    }
    function Ce(e, n) {
        const r = X(n), t = s(r, _.__wbindgen_malloc, _.__wbindgen_realloc), a = l;
        W().setInt32(e + 4 * 1, a, !0), W().setInt32(e + 4 * 0, t, !0);
    }
    function Oe(e) {
        return typeof e == "function";
    }
    function Ue(e) {
        const n = e;
        return typeof n == "object" && n !== null;
    }
    function Ne(e) {
        return typeof e == "string";
    }
    function Ie(e) {
        return e === void 0;
    }
    function Me(e, n) {
        const r = n, t = typeof r == "string" ? r : void 0;
        var a = y(t) ? 0 : s(t, _.__wbindgen_malloc, _.__wbindgen_realloc), c = l;
        W().setInt32(e + 4 * 1, c, !0), W().setInt32(e + 4 * 0, a, !0);
    }
    function Pe(e, n) {
        throw new Error(g(e, n));
    }
    function Be(e) {
        e._wbg_cb_unref();
    }
    function De() {
        return m(function(e) {
            return e.arrayBuffer();
        }, arguments);
    }
    function $e() {
        return m(function(e, n, r) {
            return e.call(n, r);
        }, arguments);
    }
    function Ye(e) {
        return e.crypto;
    }
    function Fe(e, n) {
        return e.fetch(n);
    }
    function Ge() {
        return m(function(e, n) {
            globalThis.crypto.getRandomValues(I(e, n));
        }, arguments);
    }
    function xe() {
        return m(function(e, n) {
            e.getRandomValues(n);
        }, arguments);
    }
    function qe(e) {
        return e.getTime();
    }
    function Je() {
        return m(function(e, n, r, t) {
            const a = n.get(g(r, t));
            var c = y(a) ? 0 : s(a, _.__wbindgen_malloc, _.__wbindgen_realloc), o = l;
            W().setInt32(e + 4 * 1, o, !0), W().setInt32(e + 4 * 0, c, !0);
        }, arguments);
    }
    function je(e) {
        return e.headers;
    }
    function ze(e) {
        let n;
        try {
            n = e instanceof Response;
        } catch  {
            n = !1;
        }
        return n;
    }
    function Ke(e) {
        let n;
        try {
            n = e instanceof Window;
        } catch  {
            n = !1;
        }
        return n;
    }
    function He(e) {
        return e.length;
    }
    function Xe(e) {
        return e.msCrypto;
    }
    function Qe() {
        return m(function() {
            return new Headers;
        }, arguments);
    }
    function Ze() {
        return new Date;
    }
    function Re(e) {
        return new Uint8Array(e);
    }
    function et() {
        return new Object;
    }
    function tt(e, n) {
        return new Uint8Array(I(e, n));
    }
    function rt(e, n) {
        try {
            var r = {
                a: e,
                b: n
            }, t = (c, o)=>{
                const i = r.a;
                r.a = 0;
                try {
                    return Ut(i, r.b, c, o);
                } finally{
                    r.a = i;
                }
            };
            return new Promise(t);
        } finally{
            r.a = r.b = 0;
        }
    }
    function nt(e) {
        return new Uint8Array(e >>> 0);
    }
    function _t() {
        return m(function(e, n, r) {
            return new Request(g(e, n), r);
        }, arguments);
    }
    function at(e) {
        return e.node;
    }
    function ct(e) {
        return e.process;
    }
    function ot(e, n, r) {
        Uint8Array.prototype.set.call(I(e, n), r);
    }
    function it(e) {
        return e.queueMicrotask;
    }
    function lt(e) {
        queueMicrotask(e);
    }
    function st() {
        return m(function(e, n) {
            e.randomFillSync(n);
        }, arguments);
    }
    function ut() {
        return m(function() {
            return module.require;
        }, arguments);
    }
    function ft(e) {
        return Promise.resolve(e);
    }
    function bt(e, n) {
        e.body = n;
    }
    function dt() {
        return m(function(e, n, r, t, a) {
            e.set(g(n, r), g(t, a));
        }, arguments);
    }
    function gt(e, n) {
        e.headers = n;
    }
    function wt(e, n, r) {
        e.method = g(n, r);
    }
    function yt(e, n) {
        e.mode = Nt[n];
    }
    function St() {
        const e = typeof global > "u" ? null : global;
        return y(e) ? 0 : N(e);
    }
    function pt() {
        const e = typeof globalThis > "u" ? null : globalThis;
        return y(e) ? 0 : N(e);
    }
    function ht() {
        const e = typeof self > "u" ? null : self;
        return y(e) ? 0 : N(e);
    }
    function mt() {
        const e = typeof window > "u" ? null : window;
        return y(e) ? 0 : N(e);
    }
    function vt(e) {
        return e.status;
    }
    function At(e, n, r) {
        return e.subarray(n >>> 0, r >>> 0);
    }
    function kt(e, n) {
        return e.then(n);
    }
    function Tt(e, n, r) {
        return e.then(n, r);
    }
    function Et(e) {
        return e.versions;
    }
    function Lt(e, n) {
        return It(e, n, _.wasm_bindgen__closure__destroy__h3f8964959a1d4cde, Ot);
    }
    function Wt(e, n) {
        return I(e, n);
    }
    function Vt(e, n) {
        return g(e, n);
    }
    function Ct() {
        const e = _.__wbindgen_externrefs, n = e.grow(4);
        e.set(0, void 0), e.set(n + 0, void 0), e.set(n + 1, null), e.set(n + 2, !0), e.set(n + 3, !1);
    }
    function Ot(e, n, r) {
        const t = _.wasm_bindgen__convert__closures_____invoke__hb920389fa6ed5e03(e, n, r);
        if (t[1]) throw f(t[0]);
    }
    function Ut(e, n, r, t) {
        _.wasm_bindgen__convert__closures_____invoke__h40d0a0a79b0a349e(e, n, r, t);
    }
    const Nt = [
        "same-origin",
        "no-cors",
        "cors",
        "navigate"
    ];
    function N(e) {
        const n = _.__externref_table_alloc();
        return _.__wbindgen_externrefs.set(n, e), n;
    }
    const ee = typeof FinalizationRegistry > "u" ? {
        register: ()=>{},
        unregister: ()=>{}
    } : new FinalizationRegistry((e)=>e.dtor(e.a, e.b));
    function X(e) {
        const n = typeof e;
        if (n == "number" || n == "boolean" || e == null) return `${e}`;
        if (n == "string") return `"${e}"`;
        if (n == "symbol") {
            const a = e.description;
            return a == null ? "Symbol" : `Symbol(${a})`;
        }
        if (n == "function") {
            const a = e.name;
            return typeof a == "string" && a.length > 0 ? `Function(${a})` : "Function";
        }
        if (Array.isArray(e)) {
            const a = e.length;
            let c = "[";
            a > 0 && (c += X(e[0]));
            for(let o = 1; o < a; o++)c += ", " + X(e[o]);
            return c += "]", c;
        }
        const r = /\[object ([^\]]+)\]/.exec(toString.call(e));
        let t;
        if (r && r.length > 1) t = r[1];
        else return toString.call(e);
        if (t == "Object") try {
            return "Object(" + JSON.stringify(e) + ")";
        } catch  {
            return "Object";
        }
        return e instanceof Error ? `${e.name}: ${e.message}
${e.stack}` : t;
    }
    function I(e, n) {
        return e = e >>> 0, U().subarray(e / 1, e / 1 + n);
    }
    let V = null;
    function W() {
        return (V === null || V.buffer.detached === !0 || V.buffer.detached === void 0 && V.buffer !== _.memory.buffer) && (V = new DataView(_.memory.buffer)), V;
    }
    function g(e, n) {
        return e = e >>> 0, Bt(e, n);
    }
    let $ = null;
    function U() {
        return ($ === null || $.byteLength === 0) && ($ = new Uint8Array(_.memory.buffer)), $;
    }
    function m(e, n) {
        try {
            return e.apply(this, n);
        } catch (r) {
            const t = N(r);
            _.__wbindgen_exn_store(t);
        }
    }
    function y(e) {
        return e == null;
    }
    function It(e, n, r, t) {
        const a = {
            a: e,
            b: n,
            cnt: 1,
            dtor: r
        }, c = (...o)=>{
            a.cnt++;
            const i = a.a;
            a.a = 0;
            try {
                return t(i, a.b, ...o);
            } finally{
                a.a = i, c._wbg_cb_unref();
            }
        };
        return c._wbg_cb_unref = ()=>{
            --a.cnt === 0 && (a.dtor(a.a, a.b), a.a = 0, ee.unregister(a));
        }, ee.register(c, a, a), c;
    }
    function Mt(e, n) {
        const r = n(e.length * 1, 1) >>> 0;
        return U().set(e, r / 1), l = e.length, r;
    }
    function Z(e, n) {
        const r = n(e.length * 4, 4) >>> 0;
        for(let t = 0; t < e.length; t++){
            const a = N(e[t]);
            W().setUint32(r + 4 * t, a, !0);
        }
        return l = e.length, r;
    }
    function s(e, n, r) {
        if (r === void 0) {
            const i = P.encode(e), d = n(i.length, 1) >>> 0;
            return U().subarray(d, d + i.length).set(i), l = i.length, d;
        }
        let t = e.length, a = n(t, 1) >>> 0;
        const c = U();
        let o = 0;
        for(; o < t; o++){
            const i = e.charCodeAt(o);
            if (i > 127) break;
            c[a + o] = i;
        }
        if (o !== t) {
            o !== 0 && (e = e.slice(o)), a = r(a, t, t = o + e.length * 3, 1) >>> 0;
            const i = U().subarray(a + o, a + t), d = P.encodeInto(e, i);
            o += d.written, a = r(a, t, o, 1) >>> 0;
        }
        return l = o, a;
    }
    function f(e) {
        const n = _.__wbindgen_externrefs.get(e);
        return _.__externref_table_dealloc(e), n;
    }
    let Y = new TextDecoder("utf-8", {
        ignoreBOM: !0,
        fatal: !0
    });
    Y.decode();
    const Pt = 2146435072;
    let x = 0;
    function Bt(e, n) {
        return x += n, x >= Pt && (Y = new TextDecoder("utf-8", {
            ignoreBOM: !0,
            fatal: !0
        }), Y.decode(), x = n), Y.decode(U().subarray(e, e + n));
    }
    const P = new TextEncoder;
    "encodeInto" in P || (P.encodeInto = function(e, n) {
        const r = P.encode(e);
        return n.set(r), {
            read: e.length,
            written: r.length
        };
    });
    let l = 0, _;
    function Dt(e) {
        _ = e;
    }
    URL = globalThis.URL;
    const $t = await Le({
        "./vault_core_bg.js": {
            __wbg_new_typed_aaaeaf29cf802876: rt,
            __wbg_then_9e335f6dd892bc11: Tt,
            __wbg_call_2d781c1f4d5c0ef8: $e,
            __wbg_then_098abe61755d12f6: kt,
            __wbg_queueMicrotask_a082d78ce798393e: lt,
            __wbg_queueMicrotask_0c399741342fb10f: it,
            __wbg_resolve_ae8d83246e5bcc12: ft,
            __wbg_instanceof_Window_23e677d2c6843922: Ke,
            __wbg_fetch_f8a611684c3b5fe5: Fe,
            __wbg_get_a867a94064ecd263: Je,
            __wbg_new_0837727332ac86ba: Qe,
            __wbg_set_e09648bea3f1af1e: dt,
            __wbg_instanceof_Response_9b4d9fd451e051b1: ze,
            __wbg_arrayBuffer_eb8e9ca620af2a19: De,
            __wbg_status_318629ab93a22955: vt,
            __wbg_headers_eb2234545f9ff993: je,
            __wbg_set_method_8c015e8bcafd7be1: wt,
            __wbg_set_headers_3c8fecc693b75327: gt,
            __wbg_set_body_a3d856b097dfda04: bt,
            __wbg_set_mode_5a87f2c809cf37c2: yt,
            __wbg_new_with_str_and_init_b4b54d1a819bc724: _t,
            __wbg_getRandomValues_a1cf2e70b003a59d: Ge,
            __wbg_crypto_38df2bab126b63dc: Ye,
            __wbg_process_44c7a14e11e9f69e: ct,
            __wbg_versions_276b2795b1c6a219: Et,
            __wbg_node_84ea875411254db1: at,
            __wbg_require_b4edbdcf3e2a1ef0: ut,
            __wbg_msCrypto_bd5a034af96bcba6: Xe,
            __wbg_randomFillSync_6c25eac9869eb53c: st,
            __wbg_getRandomValues_c44a50d8cfdaebeb: xe,
            __wbg_new_ab79df5bd7c26067: et,
            __wbg_new_5f486cdf45a04d78: Re,
            __wbg_length_ea16607d7b61445b: He,
            __wbg_prototypesetcall_d62e5099504357e6: ot,
            __wbg_new_from_slice_22da9388ac046e50: tt,
            __wbg_new_with_length_825018a1616e9e55: nt,
            __wbg_subarray_a068d24e39478a8a: At,
            __wbg_new_0_1dcafdf5e786e876: Ze,
            __wbg_getTime_1dad7b5386ddd2d9: qe,
            __wbg_static_accessor_GLOBAL_THIS_ad356e0db91c7913: pt,
            __wbg_static_accessor_SELF_f207c857566db248: ht,
            __wbg_static_accessor_GLOBAL_8adb955bd33fac2f: St,
            __wbg_static_accessor_WINDOW_bb9f1ba69d61b386: mt,
            __wbg___wbindgen_throw_6ddd609b62940d55: Pe,
            __wbg___wbindgen_is_object_781bc9f159099513: Ue,
            __wbg___wbindgen_is_string_7ef6b97b02428fae: Ne,
            __wbg___wbindgen_string_get_395e606bd0ee4427: Me,
            __wbg___wbindgen_is_function_3c846841762788c1: Oe,
            __wbg___wbindgen_is_undefined_52709e72fb9f179c: Ie,
            __wbg___wbindgen_debug_string_5398f5bb970e0daa: Ce,
            __wbg__wbg_cb_unref_6b5b6b8576d35cb1: Be,
            __wbindgen_init_externref_table: Ct,
            __wbindgen_cast_0000000000000001: Lt,
            __wbindgen_cast_0000000000000002: Wt,
            __wbindgen_cast_0000000000000003: Vt
        }
    }, Ee), { memory: Yt, api_change_master_password: Ft, api_create_entry: Gt, api_create_label: xt, api_create_new_vault: qt, api_delete_entry: Jt, api_delete_label: jt, api_download: zt, api_generate_password: Kt, api_generate_totp: Ht, api_generate_totp_default: Xt, api_get_entry: Qt, api_get_vault_bytes: Zt, api_list_entries: Rt, api_list_labels: er, api_load_vault: tr, api_lock: rr, api_purge_entry: nr, api_push: _r, api_regenerate_recovery_key: ar, api_rename_label: cr, api_restore_entry: or, api_rotate_dek: ir, api_set_entry_labels: lr, api_set_favorite: sr, api_sync: ur, api_unlock: fr, api_unlock_with_recovery_key: br, api_update_entry: dr, api_upgrade_argon2_params: gr, wasm_bindgen__closure__destroy__h3f8964959a1d4cde: wr, wasm_bindgen__convert__closures_____invoke__hb920389fa6ed5e03: yr, wasm_bindgen__convert__closures_____invoke__h40d0a0a79b0a349e: Sr, __wbindgen_malloc: pr, __wbindgen_realloc: hr, __wbindgen_exn_store: mr, __externref_table_alloc: vr, __wbindgen_externrefs: Ar, __externref_table_dealloc: kr, __wbindgen_free: Tr, __wbindgen_start: me } = $t, Er = Object.freeze(Object.defineProperty({
        __proto__: null,
        __externref_table_alloc: vr,
        __externref_table_dealloc: kr,
        __wbindgen_exn_store: mr,
        __wbindgen_externrefs: Ar,
        __wbindgen_free: Tr,
        __wbindgen_malloc: pr,
        __wbindgen_realloc: hr,
        __wbindgen_start: me,
        api_change_master_password: Ft,
        api_create_entry: Gt,
        api_create_label: xt,
        api_create_new_vault: qt,
        api_delete_entry: Jt,
        api_delete_label: jt,
        api_download: zt,
        api_generate_password: Kt,
        api_generate_totp: Ht,
        api_generate_totp_default: Xt,
        api_get_entry: Qt,
        api_get_vault_bytes: Zt,
        api_list_entries: Rt,
        api_list_labels: er,
        api_load_vault: tr,
        api_lock: rr,
        api_purge_entry: nr,
        api_push: _r,
        api_regenerate_recovery_key: ar,
        api_rename_label: cr,
        api_restore_entry: or,
        api_rotate_dek: ir,
        api_set_entry_labels: lr,
        api_set_favorite: sr,
        api_sync: ur,
        api_unlock: fr,
        api_unlock_with_recovery_key: br,
        api_update_entry: dr,
        api_upgrade_argon2_params: gr,
        memory: Yt,
        wasm_bindgen__closure__destroy__h3f8964959a1d4cde: wr,
        wasm_bindgen__convert__closures_____invoke__h40d0a0a79b0a349e: Sr,
        wasm_bindgen__convert__closures_____invoke__hb920389fa6ed5e03: yr
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    Dt(Er);
    me();
    const Lr = Object.freeze(Object.defineProperty({
        __proto__: null,
        api_change_master_password: q,
        api_create_entry: ne,
        api_create_label: _e,
        api_create_new_vault: J,
        api_delete_entry: ae,
        api_delete_label: ce,
        api_download: j,
        api_generate_password: oe,
        api_generate_totp: We,
        api_generate_totp_default: ie,
        api_get_entry: le,
        api_get_vault_bytes: O,
        api_list_entries: z,
        api_list_labels: se,
        api_load_vault: K,
        api_lock: Q,
        api_purge_entry: ue,
        api_push: L,
        api_regenerate_recovery_key: fe,
        api_rename_label: be,
        api_restore_entry: de,
        api_rotate_dek: ge,
        api_set_entry_labels: we,
        api_set_favorite: ye,
        api_sync: Se,
        api_unlock: H,
        api_unlock_with_recovery_key: pe,
        api_update_entry: he,
        api_upgrade_argon2_params: Ve
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    let te = !1, u = !1;
    async function R() {
        if (!te) try {
            te = !0, console.log("[SW] WASM initialized");
        } catch (e) {
            throw console.error("[SW] WASM initialization error:", e), e;
        }
    }
    function Wr() {
        console.log("[SW] Setting up message handlers"), chrome.runtime.onMessage.addListener((e, n, r)=>(console.log("[SW] Message received:", e.type), Vr(e, n, r).catch((t)=>{
                console.error("[SW] Unhandled error in message handler:", t);
                try {
                    r({
                        success: !1,
                        error: String(t)
                    });
                } catch (a) {
                    console.error("[SW] Failed to send error response:", a);
                }
            }), !0));
    }
    console.log("[SW] Registering message handlers immediately on script load");
    Wr();
    self.addEventListener("install", (e)=>{
        console.log("[SW] install event"), e.waitUntil(R());
    });
    self.addEventListener("activate", (e)=>{
        console.log("[SW] activate event"), e.waitUntil(R().then(()=>{
            console.log("[SW] Calling setupAlarms in activate"), Cr();
        }));
    });
    function ve(e) {
        return e && {
            id: e.id,
            entryType: e.entry_type,
            name: e.name,
            isFavorite: e.is_favorite ?? !1,
            updatedAt: e.updated_at ?? 0,
            deletedAt: e.deleted_at ?? null,
            notes: e.notes ?? null,
            typedValue: e.typed_value ?? {},
            labels: e.label_ids ?? [],
            customFields: (e.custom_fields ?? []).map((n)=>({
                    id: n.id,
                    name: n.name,
                    fieldType: n.field_type,
                    value: n.value
                }))
        };
    }
    function re(e) {
        return (e ?? []).map(ve);
    }
    async function S() {
        try {
            console.log("[SW] autoSaveAndPush: Starting");
            const e = O();
            console.log("[SW] autoSaveAndPush: Got vault bytes, size:", e?.length), await p(b.VAULT_BYTES, Array.from(e));
            const n = await A(b.S3_CONFIG);
            if (console.log("[SW] autoSaveAndPush: s3Config exists:", !!n), console.log("[SW] autoSaveAndPush: api_push type:", typeof L), n) try {
                if (typeof L == "function") {
                    console.log("[SW] autoSaveAndPush: Calling api_push");
                    const r = await L(JSON.stringify(n));
                    console.log("[SW] autoSaveAndPush: api_push returned:", r), await p(b.LAST_SYNC_TIME, new Date().toISOString()), console.log("[SW] Auto-push successful");
                } else console.warn("[SW] autoSaveAndPush: api_push not available in WASM");
            } catch (r) {
                console.warn("[SW] Auto-push failed:", r);
            }
            else console.log("[SW] autoSaveAndPush: No S3 config, skipping push");
        } catch (e) {
            console.error("[SW] autoSaveAndPush failed:", e);
        }
    }
    async function C() {
        return await A(b.APP_SETTINGS) || {
            autolockMinutes: 5,
            clipboardClearSeconds: 30,
            clipboardAutoClean: !0,
            theme: "light"
        };
    }
    async function Vr(e, n, r) {
        try {
            switch(await R(), e.type){
                case "IS_UNLOCKED":
                    {
                        r({
                            success: !0,
                            unlocked: u
                        });
                        break;
                    }
                case "UNLOCK":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await A(b.VAULT_BYTES), a = await A(b.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            K(new Uint8Array(t), a || ""), H(e.password), u = !0;
                            const c = await C();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UNLOCK_EXISTING":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await A(b.VAULT_BYTES), a = await A(b.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            K(new Uint8Array(t), a || ""), H(e.password), u = !0;
                            const c = await C();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LOCK":
                    {
                        try {
                            const t = Q();
                            await p(b.VAULT_BYTES, Array.from(t)), u = !1, chrome.alarms.clear("autolock"), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_VAULT":
                    {
                        if (!e.masterPassword) {
                            r({
                                success: !1,
                                error: "Master password required"
                            });
                            break;
                        }
                        try {
                            console.log("[SW] CREATE_VAULT: Starting vault creation"), console.log("[SW] CREATE_VAULT: vault object type:", typeof Lr), console.log("[SW] CREATE_VAULT: vault.api_create_new_vault:", typeof J);
                            const t = J(e.masterPassword);
                            console.log("[SW] CREATE_VAULT: Vault created, recovery key:", t);
                            const a = O();
                            console.log("[SW] CREATE_VAULT: Got vault bytes, size:", a?.length), await p(b.VAULT_BYTES, Array.from(a)), await p(b.VAULT_ETAG, null), console.log("[SW] CREATE_VAULT: Saved vault bytes to storage"), e.s3Config && await p(b.S3_CONFIG, e.s3Config), u = !0;
                            const c = await C();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), console.log("[SW] CREATE_VAULT: Success, sending response");
                            const o = {
                                success: !0,
                                recoveryKey: t
                            };
                            console.log("[SW] CREATE_VAULT: Response payload:", o), r(o), console.log("[SW] CREATE_VAULT: sendResponse called");
                        } catch (t) {
                            console.error("[SW] CREATE_VAULT: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RECOVER":
                    {
                        if (!e.recoveryKey || !e.newPassword) {
                            r({
                                success: !1,
                                error: "Recovery key and password required"
                            });
                            break;
                        }
                        try {
                            pe(e.recoveryKey), q(e.recoveryKey, e.newPassword);
                            const t = O();
                            await p(b.VAULT_BYTES, Array.from(t)), await p(b.VAULT_ETAG, null), await S(), u = !0;
                            const a = await C();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: a.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_ENTRIES":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = e.filter || {}, a = z(t.searchQuery || null, t.type || null, t.labelId || null, t.includeTrash || !1, t.onlyFavorites || !1), c = JSON.parse(a), o = re(c);
                            r({
                                success: !0,
                                entries: o
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = le(e.id), a = JSON.parse(t);
                            a && a.typed_value && typeof a.typed_value == "string" && (a.typed_value = JSON.parse(a.typed_value));
                            const c = ve(a);
                            r({
                                success: !0,
                                entry: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ne(e.entryType, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null);
                            await S(), r({
                                success: !0,
                                entryId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UPDATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            he(e.id, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ae(e.id), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RESTORE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            de(e.id), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PURGE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ue(e.id), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_FAVORITE":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ye(e.id, e.isFavorite), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_TRASH":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = z(null, null, null, !0, !1), a = JSON.parse(t), c = re(a);
                            r({
                                success: !0,
                                entries: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = se(), a = JSON.parse(t);
                            r({
                                success: !0,
                                labels: a
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = _e(e.name);
                            await S(), r({
                                success: !0,
                                labelId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ce(e.id), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RENAME_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            be(e.id, e.newName), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_ENTRY_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            we(e.entryId, e.labelIds || []), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_PASSWORD":
                    {
                        try {
                            const t = oe(e.length ?? 16, e.includeUppercase ?? !0, e.includeLowercase ?? !0, e.includeNumbers ?? !0, e.includeSymbols ?? !0);
                            r({
                                success: !0,
                                password: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_TOTP":
                    {
                        try {
                            const t = ie(e.secret);
                            r({
                                success: !0,
                                totp: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CHANGE_MASTER_PASSWORD":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            q(e.oldPassword, e.newPassword), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "ROTATE_DEK":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ge(e.password);
                            await S(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "REGENERATE_RECOVERY_KEY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = fe(e.password);
                            await S(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DOWNLOAD_VAULT":
                    {
                        try {
                            const t = await A(b.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            if (typeof j != "function") {
                                console.warn("[SW] DOWNLOAD_VAULT: api_download is not available in vault_core"), r({
                                    success: !1,
                                    error: "S3 download feature is not yet implemented in vault_core"
                                });
                                break;
                            }
                            console.log("[SW] DOWNLOAD_VAULT: Downloading vault from S3");
                            const a = await j(JSON.stringify(t)), c = O();
                            await p(b.VAULT_BYTES, Array.from(c)), console.log("[SW] DOWNLOAD_VAULT: Download successful"), r({
                                success: !0,
                                vaultExists: a
                            });
                        } catch (t) {
                            console.error("[SW] DOWNLOAD_VAULT: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PUSH_VAULT":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = await A(b.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            if (typeof L != "function") {
                                console.warn("[SW] PUSH_VAULT: api_push is not available in vault_core"), r({
                                    success: !1,
                                    error: "S3 push feature is not yet implemented in vault_core"
                                });
                                break;
                            }
                            console.log("[SW] PUSH_VAULT: Pushing vault to S3"), await L(JSON.stringify(t)), await p(b.LAST_SYNC_TIME, new Date().toISOString()), console.log("[SW] PUSH_VAULT: Push successful"), r({
                                success: !0
                            });
                        } catch (t) {
                            console.error("[SW] PUSH_VAULT: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SYNC":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            console.log("[SW] SYNC: Starting sync");
                            const t = await A(b.S3_CONFIG);
                            if (console.log("[SW] SYNC: s3Config:", t), !t) {
                                console.log("[SW] SYNC: No S3 config found"), r({
                                    success: !0,
                                    status: "idle",
                                    message: "S3 config not set"
                                });
                                break;
                            }
                            console.log("[SW] SYNC: S3 sync feature is not yet implemented in vault_core"), console.log("[SW] SYNC: api_sync available:", typeof Se == "function"), console.log("[SW] SYNC: api_push available:", typeof L == "function");
                            const a = O();
                            console.log("[SW] SYNC: Got vault bytes, size:", a?.length), await p(b.VAULT_BYTES, Array.from(a)), await p(b.LAST_SYNC_TIME, new Date().toISOString()), r({
                                success: !0,
                                status: "ready",
                                message: "Vault is ready. S3 sync feature is not yet implemented in vault_core."
                            });
                        } catch (t) {
                            console.error("[SW] SYNC: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_SETTINGS":
                    {
                        const t = await C();
                        r({
                            success: !0,
                            settings: t
                        });
                        break;
                    }
                case "SAVE_SETTINGS":
                    {
                        try {
                            await p(b.APP_SETTINGS, e.settings), u && chrome.alarms.create("autolock", {
                                delayInMinutes: e.settings.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CLIPBOARD_COPIED":
                    {
                        try {
                            const t = await C();
                            if (t.clipboardAutoClean) {
                                const a = t.clipboardClearSeconds / 60;
                                chrome.alarms.create("clipboard-clear", {
                                    delayInMinutes: a
                                });
                            }
                            r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                default:
                    r({
                        success: !1,
                        error: "Unknown message type"
                    });
            }
        } catch (t) {
            console.error("[SW] Message handling error:", t), r({
                success: !1,
                error: String(t)
            });
        }
    }
    function Cr() {
        chrome.alarms.onAlarm.addListener((e)=>{
            e.name === "autolock" ? Or() : e.name === "clipboard-clear" && Ur();
        });
    }
    async function Or() {
        if (console.log("[SW] Autolock alarm triggered"), !!u) try {
            const e = Q();
            await p(b.VAULT_BYTES, Array.from(e)), u = !1, console.log("[SW] Vault locked");
        } catch (e) {
            console.error("[SW] Autolock failed:", e);
        }
    }
    async function Ur() {
        console.log("[SW] Clipboard clear alarm triggered");
        try {
            typeof chrome.offscreen < "u" ? (await chrome.offscreen.createDocument({
                url: chrome.runtime.getURL("src/background/offscreen.html"),
                reasons: [
                    "CLIPBOARD"
                ],
                justification: "Clear clipboard after copy timeout"
            }), chrome.runtime.sendMessage({
                type: "CLEAR_CLIPBOARD"
            })) : await navigator.clipboard.writeText("");
        } catch (e) {
            console.error("[SW] Clipboard clear failed:", e);
        }
    }
})();
