import { s as y, S as d, g as k } from "./constants-DecA7v_U.js";
(async ()=>{
    const ae = "/assets/vault_core_bg-BR5Sab9T.wasm", ne = async (e = {}, a)=>{
        let r;
        if (a.startsWith("data:")) {
            const t = a.replace(/^data:.*?base64,/, "");
            let c;
            if (typeof Buffer == "function" && typeof Buffer.from == "function") c = Buffer.from(t, "base64");
            else if (typeof atob == "function") {
                const _ = atob(t);
                c = new Uint8Array(_.length);
                for(let o = 0; o < _.length; o++)c[o] = _.charCodeAt(o);
            } else throw new Error("Cannot decode base64-encoded data URL");
            r = await WebAssembly.instantiate(c, e);
        } else {
            const t = await fetch(a), c = t.headers.get("Content-Type") || "";
            if ("instantiateStreaming" in WebAssembly && c.startsWith("application/wasm")) r = await WebAssembly.instantiateStreaming(t, e);
            else {
                const _ = await t.arrayBuffer();
                r = await WebAssembly.instantiate(_, e);
            }
        }
        return r.instance.exports;
    };
    function K(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = l, c = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), _ = l, o = n.api_change_master_password(r, t, c, _);
        if (o[1]) throw f(o[0]);
    }
    function ce(e, a, r, t, c, _) {
        let o, i;
        try {
            const p = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), v = l, F = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), P = l;
            var b = w(r) ? 0 : s(r, n.__wbindgen_malloc, n.__wbindgen_realloc), h = l;
            const M = s(t, n.__wbindgen_malloc, n.__wbindgen_realloc), ee = l, te = Y(c, n.__wbindgen_malloc), re = l;
            var O = w(_) ? 0 : s(_, n.__wbindgen_malloc, n.__wbindgen_realloc), I = l;
            const W = n.api_create_entry(p, v, F, P, b, h, M, ee, te, re, O, I);
            var T = W[0], m = W[1];
            if (W[3]) throw T = 0, m = 0, f(W[2]);
            return o = T, i = m, S(T, m);
        } finally{
            n.__wbindgen_free(o, i, 1);
        }
    }
    function _e(e) {
        let a, r;
        try {
            const _ = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), o = l, i = n.api_create_label(_, o);
            var t = i[0], c = i[1];
            if (i[3]) throw t = 0, c = 0, f(i[2]);
            return a = t, r = c, S(t, c);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function oe(e) {
        let a, r;
        try {
            const _ = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), o = l, i = n.api_create_new_vault(_, o);
            var t = i[0], c = i[1];
            if (i[3]) throw t = 0, c = 0, f(i[2]);
            return a = t, r = c, S(t, c);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function ie(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = l, t = n.api_delete_entry(a, r);
        if (t[1]) throw f(t[0]);
    }
    function le(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = l, t = n.api_delete_label(a, r);
        if (t[1]) throw f(t[0]);
    }
    function se(e, a, r, t, c) {
        let _, o;
        try {
            const h = n.api_generate_password(e, a, r, t, c);
            var i = h[0], b = h[1];
            if (h[3]) throw i = 0, b = 0, f(h[2]);
            return _ = i, o = b, S(i, b);
        } finally{
            n.__wbindgen_free(_, o, 1);
        }
    }
    function ue(e) {
        let a, r;
        try {
            const _ = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), o = l, i = n.api_generate_totp_default(_, o);
            var t = i[0], c = i[1];
            if (i[3]) throw t = 0, c = 0, f(i[2]);
            return a = t, r = c, S(t, c);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function fe(e) {
        let a, r;
        try {
            const _ = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), o = l, i = n.api_get_entry(_, o);
            var t = i[0], c = i[1];
            if (i[3]) throw t = 0, c = 0, f(i[2]);
            return a = t, r = c, S(t, c);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function N() {
        const e = n.api_get_vault_bytes();
        if (e[3]) throw f(e[2]);
        var a = U(e[0], e[1]).slice();
        return n.__wbindgen_free(e[0], e[1] * 1, 1), a;
    }
    function q(e, a, r, t, c) {
        let _, o;
        try {
            var i = w(e) ? 0 : s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), b = l, h = w(a) ? 0 : s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), O = l, I = w(r) ? 0 : s(r, n.__wbindgen_malloc, n.__wbindgen_realloc), T = l;
            const v = n.api_list_entries(i, b, h, O, I, T, t, c);
            var m = v[0], p = v[1];
            if (v[3]) throw m = 0, p = 0, f(v[2]);
            return _ = m, o = p, S(m, p);
        } finally{
            n.__wbindgen_free(_, o, 1);
        }
    }
    function de() {
        let e, a;
        try {
            const c = n.api_list_labels();
            var r = c[0], t = c[1];
            if (c[3]) throw r = 0, t = 0, f(c[2]);
            return e = r, a = t, S(r, t);
        } finally{
            n.__wbindgen_free(e, a, 1);
        }
    }
    function z(e, a) {
        const r = Ze(e, n.__wbindgen_malloc), t = l, c = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), _ = l, o = n.api_load_vault(r, t, c, _);
        if (o[1]) throw f(o[0]);
    }
    function Q() {
        const e = n.api_lock();
        if (e[3]) throw f(e[2]);
        var a = U(e[0], e[1]).slice();
        return n.__wbindgen_free(e[0], e[1] * 1, 1), a;
    }
    function be(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = l, t = n.api_purge_entry(a, r);
        if (t[1]) throw f(t[0]);
    }
    function we(e) {
        let a, r;
        try {
            const _ = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), o = l, i = n.api_regenerate_recovery_key(_, o);
            var t = i[0], c = i[1];
            if (i[3]) throw t = 0, c = 0, f(i[2]);
            return a = t, r = c, S(t, c);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function ge(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = l, c = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), _ = l, o = n.api_rename_label(r, t, c, _);
        if (o[1]) throw f(o[0]);
    }
    function ye(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = l, t = n.api_restore_entry(a, r);
        if (t[1]) throw f(t[0]);
    }
    function Se(e) {
        let a, r;
        try {
            const _ = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), o = l, i = n.api_rotate_dek(_, o);
            var t = i[0], c = i[1];
            if (i[3]) throw t = 0, c = 0, f(i[2]);
            return a = t, r = c, S(t, c);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function he(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = l, c = Y(a, n.__wbindgen_malloc), _ = l, o = n.api_set_entry_labels(r, t, c, _);
        if (o[1]) throw f(o[0]);
    }
    function me(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = l, c = n.api_set_favorite(r, t, a);
        if (c[1]) throw f(c[0]);
    }
    function H(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = l, t = n.api_unlock(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ke(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = l, t = n.api_unlock_with_recovery_key(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ve(e, a, r, t, c, _) {
        const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), i = l;
        var b = w(a) ? 0 : s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), h = l, O = w(r) ? 0 : s(r, n.__wbindgen_malloc, n.__wbindgen_realloc), I = l, T = w(t) ? 0 : s(t, n.__wbindgen_malloc, n.__wbindgen_realloc), m = l, p = w(c) ? 0 : Y(c, n.__wbindgen_malloc), v = l, F = w(_) ? 0 : s(_, n.__wbindgen_malloc, n.__wbindgen_realloc), P = l;
        const M = n.api_update_entry(o, i, b, h, O, I, T, m, p, v, F, P);
        if (M[1]) throw f(M[0]);
    }
    function Te(e) {
        return typeof e == "function";
    }
    function pe(e) {
        const a = e;
        return typeof a == "object" && a !== null;
    }
    function Ee(e) {
        return typeof e == "string";
    }
    function Ae(e) {
        return e === void 0;
    }
    function Le(e, a) {
        const r = a, t = typeof r == "string" ? r : void 0;
        var c = w(t) ? 0 : s(t, n.__wbindgen_malloc, n.__wbindgen_realloc), _ = l;
        x().setInt32(e + 4 * 1, _, !0), x().setInt32(e + 4 * 0, c, !0);
    }
    function Ve(e, a) {
        throw new Error(S(e, a));
    }
    function Oe() {
        return B(function(e, a, r) {
            return e.call(a, r);
        }, arguments);
    }
    function Ie(e) {
        return e.crypto;
    }
    function Ne() {
        return B(function(e, a) {
            globalThis.crypto.getRandomValues(U(e, a));
        }, arguments);
    }
    function Ce() {
        return B(function(e, a) {
            e.getRandomValues(a);
        }, arguments);
    }
    function Ue(e) {
        return e.getTime();
    }
    function Be(e) {
        return e.length;
    }
    function Me(e) {
        return e.msCrypto;
    }
    function We() {
        return new Date;
    }
    function De(e) {
        return new Uint8Array(e >>> 0);
    }
    function Ge(e) {
        return e.node;
    }
    function Fe(e) {
        return e.process;
    }
    function Pe(e, a, r) {
        Uint8Array.prototype.set.call(U(e, a), r);
    }
    function $e() {
        return B(function(e, a) {
            e.randomFillSync(a);
        }, arguments);
    }
    function xe() {
        return B(function() {
            return module.require;
        }, arguments);
    }
    function Ye() {
        const e = typeof global > "u" ? null : global;
        return w(e) ? 0 : V(e);
    }
    function Je() {
        const e = typeof globalThis > "u" ? null : globalThis;
        return w(e) ? 0 : V(e);
    }
    function Ke() {
        const e = typeof self > "u" ? null : self;
        return w(e) ? 0 : V(e);
    }
    function qe() {
        const e = typeof window > "u" ? null : window;
        return w(e) ? 0 : V(e);
    }
    function ze(e, a, r) {
        return e.subarray(a >>> 0, r >>> 0);
    }
    function He(e) {
        return e.versions;
    }
    function je(e, a) {
        return U(e, a);
    }
    function Xe(e, a) {
        return S(e, a);
    }
    function Qe() {
        const e = n.__wbindgen_externrefs, a = e.grow(4);
        e.set(0, void 0), e.set(a + 0, void 0), e.set(a + 1, null), e.set(a + 2, !0), e.set(a + 3, !1);
    }
    function V(e) {
        const a = n.__externref_table_alloc();
        return n.__wbindgen_externrefs.set(a, e), a;
    }
    function U(e, a) {
        return e = e >>> 0, L().subarray(e / 1, e / 1 + a);
    }
    let E = null;
    function x() {
        return (E === null || E.buffer.detached === !0 || E.buffer.detached === void 0 && E.buffer !== n.memory.buffer) && (E = new DataView(n.memory.buffer)), E;
    }
    function S(e, a) {
        return e = e >>> 0, et(e, a);
    }
    let D = null;
    function L() {
        return (D === null || D.byteLength === 0) && (D = new Uint8Array(n.memory.buffer)), D;
    }
    function B(e, a) {
        try {
            return e.apply(this, a);
        } catch (r) {
            const t = V(r);
            n.__wbindgen_exn_store(t);
        }
    }
    function w(e) {
        return e == null;
    }
    function Ze(e, a) {
        const r = a(e.length * 1, 1) >>> 0;
        return L().set(e, r / 1), l = e.length, r;
    }
    function Y(e, a) {
        const r = a(e.length * 4, 4) >>> 0;
        for(let t = 0; t < e.length; t++){
            const c = V(e[t]);
            x().setUint32(r + 4 * t, c, !0);
        }
        return l = e.length, r;
    }
    function s(e, a, r) {
        if (r === void 0) {
            const i = C.encode(e), b = a(i.length, 1) >>> 0;
            return L().subarray(b, b + i.length).set(i), l = i.length, b;
        }
        let t = e.length, c = a(t, 1) >>> 0;
        const _ = L();
        let o = 0;
        for(; o < t; o++){
            const i = e.charCodeAt(o);
            if (i > 127) break;
            _[c + o] = i;
        }
        if (o !== t) {
            o !== 0 && (e = e.slice(o)), c = r(c, t, t = o + e.length * 3, 1) >>> 0;
            const i = L().subarray(c + o, c + t), b = C.encodeInto(e, i);
            o += b.written, c = r(c, t, o, 1) >>> 0;
        }
        return l = o, c;
    }
    function f(e) {
        const a = n.__wbindgen_externrefs.get(e);
        return n.__externref_table_dealloc(e), a;
    }
    let G = new TextDecoder("utf-8", {
        ignoreBOM: !0,
        fatal: !0
    });
    G.decode();
    const Re = 2146435072;
    let $ = 0;
    function et(e, a) {
        return $ += a, $ >= Re && (G = new TextDecoder("utf-8", {
            ignoreBOM: !0,
            fatal: !0
        }), G.decode(), $ = a), G.decode(L().subarray(e, e + a));
    }
    const C = new TextEncoder;
    "encodeInto" in C || (C.encodeInto = function(e, a) {
        const r = C.encode(e);
        return a.set(r), {
            read: e.length,
            written: r.length
        };
    });
    let l = 0, n;
    function tt(e) {
        n = e;
    }
    URL = globalThis.URL;
    const rt = await ne({
        "./vault_core_bg.js": {
            __wbg_getRandomValues_a1cf2e70b003a59d: Ne,
            __wbg_crypto_38df2bab126b63dc: Ie,
            __wbg_process_44c7a14e11e9f69e: Fe,
            __wbg_versions_276b2795b1c6a219: He,
            __wbg_node_84ea875411254db1: Ge,
            __wbg_require_b4edbdcf3e2a1ef0: xe,
            __wbg_call_2d781c1f4d5c0ef8: Oe,
            __wbg_msCrypto_bd5a034af96bcba6: Me,
            __wbg_randomFillSync_6c25eac9869eb53c: $e,
            __wbg_getRandomValues_c44a50d8cfdaebeb: Ce,
            __wbg_length_ea16607d7b61445b: Be,
            __wbg_prototypesetcall_d62e5099504357e6: Pe,
            __wbg_new_with_length_825018a1616e9e55: De,
            __wbg_subarray_a068d24e39478a8a: ze,
            __wbg_new_0_1dcafdf5e786e876: We,
            __wbg_getTime_1dad7b5386ddd2d9: Ue,
            __wbg_static_accessor_GLOBAL_THIS_ad356e0db91c7913: Je,
            __wbg_static_accessor_SELF_f207c857566db248: Ke,
            __wbg_static_accessor_GLOBAL_8adb955bd33fac2f: Ye,
            __wbg_static_accessor_WINDOW_bb9f1ba69d61b386: qe,
            __wbg___wbindgen_throw_6ddd609b62940d55: Ve,
            __wbg___wbindgen_is_object_781bc9f159099513: pe,
            __wbg___wbindgen_is_string_7ef6b97b02428fae: Ee,
            __wbg___wbindgen_string_get_395e606bd0ee4427: Le,
            __wbg___wbindgen_is_function_3c846841762788c1: Te,
            __wbg___wbindgen_is_undefined_52709e72fb9f179c: Ae,
            __wbindgen_init_externref_table: Qe,
            __wbindgen_cast_0000000000000001: je,
            __wbindgen_cast_0000000000000002: Xe
        }
    }, ae), { memory: at, api_change_master_password: nt, api_create_entry: ct, api_create_label: _t, api_create_new_vault: ot, api_delete_entry: it, api_delete_label: lt, api_generate_password: st, api_generate_totp: ut, api_generate_totp_default: ft, api_get_entry: dt, api_get_vault_bytes: bt, api_list_entries: wt, api_list_labels: gt, api_load_vault: yt, api_lock: St, api_purge_entry: ht, api_regenerate_recovery_key: mt, api_rename_label: kt, api_restore_entry: vt, api_rotate_dek: Tt, api_set_entry_labels: pt, api_set_favorite: Et, api_unlock: At, api_unlock_with_recovery_key: Lt, api_update_entry: Vt, api_upgrade_argon2_params: Ot, __wbindgen_malloc: It, __wbindgen_realloc: Nt, __wbindgen_exn_store: Ct, __externref_table_alloc: Ut, __wbindgen_externrefs: Bt, __externref_table_dealloc: Mt, __wbindgen_free: Wt, __wbindgen_start: Z } = rt, Dt = Object.freeze(Object.defineProperty({
        __proto__: null,
        __externref_table_alloc: Ut,
        __externref_table_dealloc: Mt,
        __wbindgen_exn_store: Ct,
        __wbindgen_externrefs: Bt,
        __wbindgen_free: Wt,
        __wbindgen_malloc: It,
        __wbindgen_realloc: Nt,
        __wbindgen_start: Z,
        api_change_master_password: nt,
        api_create_entry: ct,
        api_create_label: _t,
        api_create_new_vault: ot,
        api_delete_entry: it,
        api_delete_label: lt,
        api_generate_password: st,
        api_generate_totp: ut,
        api_generate_totp_default: ft,
        api_get_entry: dt,
        api_get_vault_bytes: bt,
        api_list_entries: wt,
        api_list_labels: gt,
        api_load_vault: yt,
        api_lock: St,
        api_purge_entry: ht,
        api_regenerate_recovery_key: mt,
        api_rename_label: kt,
        api_restore_entry: vt,
        api_rotate_dek: Tt,
        api_set_entry_labels: pt,
        api_set_favorite: Et,
        api_unlock: At,
        api_unlock_with_recovery_key: Lt,
        api_update_entry: Vt,
        api_upgrade_argon2_params: Ot,
        memory: at
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    tt(Dt);
    Z();
    let j = !1, u = !1;
    async function J() {
        if (!j) try {
            j = !0, console.log("[SW] WASM initialized");
        } catch (e) {
            throw console.error("[SW] WASM initialization error:", e), e;
        }
    }
    self.addEventListener("install", (e)=>{
        e.waitUntil(J());
    });
    self.addEventListener("activate", (e)=>{
        e.waitUntil(J().then(()=>{
            Gt(), Pt();
        }));
    });
    function R(e) {
        return e && {
            id: e.id,
            entryType: e.entry_type,
            name: e.name,
            isFavorite: e.is_favorite ?? !1,
            updatedAt: e.updated_at ?? 0,
            deletedAt: e.deleted_at ?? null,
            notes: e.notes ?? null,
            typedValue: e.typed_value ?? {},
            labels: e.label_ids ?? [],
            customFields: (e.custom_fields ?? []).map((a)=>({
                    id: a.id,
                    name: a.name,
                    fieldType: a.field_type,
                    value: a.value
                }))
        };
    }
    function X(e) {
        return (e ?? []).map(R);
    }
    async function g() {
        try {
            const e = N();
            await y(d.VAULT_BYTES, Array.from(e));
            const a = await k(d.S3_CONFIG);
            if (a) try {
                await (void 0)(JSON.stringify(a)), await y(d.LAST_SYNC_TIME, new Date().toISOString()), console.log("[SW] Auto-push successful");
            } catch (r) {
                console.warn("[SW] Auto-push failed:", r);
            }
        } catch (e) {
            console.error("[SW] autoSaveAndPush failed:", e);
        }
    }
    async function A() {
        return await k(d.APP_SETTINGS) || {
            autolockMinutes: 5,
            clipboardClearSeconds: 30,
            clipboardAutoClean: !0,
            theme: "light"
        };
    }
    function Gt() {
        chrome.runtime.onMessage.addListener((e, a, r)=>(Ft(e, a, r), !0));
    }
    async function Ft(e, a, r) {
        try {
            switch(await J(), e.type){
                case "IS_UNLOCKED":
                    {
                        r({
                            success: !0,
                            unlocked: u
                        });
                        break;
                    }
                case "UNLOCK":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await k(d.VAULT_BYTES), c = await k(d.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            z(new Uint8Array(t), c || ""), H(e.password), u = !0;
                            const _ = await A();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: _.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UNLOCK_EXISTING":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await k(d.VAULT_BYTES), c = await k(d.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            z(new Uint8Array(t), c || ""), H(e.password), u = !0;
                            const _ = await A();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: _.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LOCK":
                    {
                        try {
                            const t = Q();
                            await y(d.VAULT_BYTES, Array.from(t)), u = !1, chrome.alarms.clear("autolock"), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_VAULT":
                    {
                        if (!e.masterPassword) {
                            r({
                                success: !1,
                                error: "Master password required"
                            });
                            break;
                        }
                        try {
                            const t = oe(e.masterPassword), c = N();
                            await y(d.VAULT_BYTES, Array.from(c)), await y(d.VAULT_ETAG, null), e.s3Config && await y(d.S3_CONFIG, e.s3Config), u = !0;
                            const _ = await A();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: _.autolockMinutes
                            }), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RECOVER":
                    {
                        if (!e.recoveryKey || !e.newPassword) {
                            r({
                                success: !1,
                                error: "Recovery key and password required"
                            });
                            break;
                        }
                        try {
                            ke(e.recoveryKey), K(e.recoveryKey, e.newPassword);
                            const t = N();
                            await y(d.VAULT_BYTES, Array.from(t)), await y(d.VAULT_ETAG, null), await g(), u = !0;
                            const c = await A();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_ENTRIES":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = e.filter || {}, c = q(t.searchQuery || null, t.type || null, t.labelId || null, t.includeTrash || !1, t.onlyFavorites || !1), _ = JSON.parse(c), o = X(_);
                            r({
                                success: !0,
                                entries: o
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = fe(e.id), c = JSON.parse(t);
                            c && c.typed_value && typeof c.typed_value == "string" && (c.typed_value = JSON.parse(c.typed_value));
                            const _ = R(c);
                            r({
                                success: !0,
                                entry: _
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ce(e.entryType, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null);
                            await g(), r({
                                success: !0,
                                entryId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UPDATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ve(e.id, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null), await g(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ie(e.id), await g(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RESTORE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ye(e.id), await g(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PURGE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            be(e.id), await g(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_FAVORITE":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            me(e.id, e.isFavorite), await g(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_TRASH":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = q(null, null, null, !0, !1), c = JSON.parse(t), _ = X(c);
                            r({
                                success: !0,
                                entries: _
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = de(), c = JSON.parse(t);
                            r({
                                success: !0,
                                labels: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = _e(e.name);
                            await g(), r({
                                success: !0,
                                labelId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            le(e.id), await g(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RENAME_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ge(e.id, e.newName), await g(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_ENTRY_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            he(e.entryId, e.labelIds || []), await g(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_PASSWORD":
                    {
                        try {
                            const t = se(e.length ?? 16, e.includeUppercase ?? !0, e.includeLowercase ?? !0, e.includeNumbers ?? !0, e.includeSymbols ?? !0);
                            r({
                                success: !0,
                                password: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_TOTP":
                    {
                        try {
                            const t = ue(e.secret);
                            r({
                                success: !0,
                                totp: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CHANGE_MASTER_PASSWORD":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            K(e.oldPassword, e.newPassword), await g(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "ROTATE_DEK":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = Se(e.password);
                            await g(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "REGENERATE_RECOVERY_KEY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = we(e.password);
                            await g(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DOWNLOAD_VAULT":
                    {
                        try {
                            const t = await k(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            const c = await (void 0)(JSON.stringify(t)), _ = N();
                            await y(d.VAULT_BYTES, Array.from(_)), r({
                                success: !0,
                                vaultExists: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PUSH_VAULT":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = await k(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            await (void 0)(JSON.stringify(t)), await y(d.LAST_SYNC_TIME, new Date().toISOString()), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SYNC":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = await k(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !0,
                                    status: "idle",
                                    message: "S3 config not set"
                                });
                                break;
                            }
                            await (void 0)(JSON.stringify(t));
                            const c = N();
                            await y(d.VAULT_BYTES, Array.from(c)), await y(d.LAST_SYNC_TIME, new Date().toISOString()), r({
                                success: !0,
                                status: "synced"
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_SETTINGS":
                    {
                        const t = await A();
                        r({
                            success: !0,
                            settings: t
                        });
                        break;
                    }
                case "SAVE_SETTINGS":
                    {
                        try {
                            await y(d.APP_SETTINGS, e.settings), u && chrome.alarms.create("autolock", {
                                delayInMinutes: e.settings.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CLIPBOARD_COPIED":
                    {
                        try {
                            const t = await A();
                            if (t.clipboardAutoClean) {
                                const c = t.clipboardClearSeconds / 60;
                                chrome.alarms.create("clipboard-clear", {
                                    delayInMinutes: c
                                });
                            }
                            r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                default:
                    r({
                        success: !1,
                        error: "Unknown message type"
                    });
            }
        } catch (t) {
            console.error("[SW] Message handling error:", t), r({
                success: !1,
                error: String(t)
            });
        }
    }
    function Pt() {
        chrome.alarms.onAlarm.addListener((e)=>{
            e.name === "autolock" ? $t() : e.name === "clipboard-clear" && xt();
        });
    }
    async function $t() {
        if (console.log("[SW] Autolock alarm triggered"), !!u) try {
            const e = Q();
            await y(d.VAULT_BYTES, Array.from(e)), u = !1, console.log("[SW] Vault locked");
        } catch (e) {
            console.error("[SW] Autolock failed:", e);
        }
    }
    async function xt() {
        console.log("[SW] Clipboard clear alarm triggered");
        try {
            typeof chrome.offscreen < "u" ? (await chrome.offscreen.createDocument({
                url: chrome.runtime.getURL("src/background/offscreen.html"),
                reasons: [
                    "CLIPBOARD"
                ],
                justification: "Clear clipboard after copy timeout"
            }), chrome.runtime.sendMessage({
                type: "CLEAR_CLIPBOARD"
            })) : await navigator.clipboard.writeText("");
        } catch (e) {
            console.error("[SW] Clipboard clear failed:", e);
        }
    }
})();
