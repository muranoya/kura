import { g as h, S as d, s as p } from "./constants-BZlR814j.js";
(async ()=>{
    const Ee = "/assets/vault_core_bg-B3eq4Sdc.wasm", We = async (e = {}, n)=>{
        let r;
        if (n.startsWith("data:")) {
            const t = n.replace(/^data:.*?base64,/, "");
            let _;
            if (typeof Buffer == "function" && typeof Buffer.from == "function") _ = Buffer.from(t, "base64");
            else if (typeof atob == "function") {
                const c = atob(t);
                _ = new Uint8Array(c.length);
                for(let o = 0; o < c.length; o++)_[o] = c.charCodeAt(o);
            } else throw new Error("Cannot decode base64-encoded data URL");
            r = await WebAssembly.instantiate(_, e);
        } else {
            const t = await fetch(n), _ = t.headers.get("Content-Type") || "";
            if ("instantiateStreaming" in WebAssembly && _.startsWith("application/wasm")) r = await WebAssembly.instantiateStreaming(t, e);
            else {
                const c = await t.arrayBuffer();
                r = await WebAssembly.instantiate(c, e);
            }
        }
        return r.instance.exports;
    };
    function K(e, n) {
        const r = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), t = l, _ = s(n, a.__wbindgen_malloc, a.__wbindgen_realloc), c = l, o = a.api_change_master_password(r, t, _, c);
        if (o[1]) throw f(o[0]);
    }
    function _e(e, n, r, t, _, c) {
        let o, i;
        try {
            const W = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), T = l, J = s(n, a.__wbindgen_malloc, a.__wbindgen_realloc), q = l;
            var b = y(r) ? 0 : s(r, a.__wbindgen_malloc, a.__wbindgen_realloc), w = l;
            const B = s(t, a.__wbindgen_malloc, a.__wbindgen_realloc), Ae = l, ke = R(_, a.__wbindgen_malloc), Te = l;
            var m = y(c) ? 0 : s(c, a.__wbindgen_malloc, a.__wbindgen_realloc), D = l;
            const P = a.api_create_entry(W, T, J, q, b, w, B, Ae, ke, Te, m, D);
            var E = P[0], A = P[1];
            if (P[3]) throw E = 0, A = 0, f(P[2]);
            return o = E, i = A, g(E, A);
        } finally{
            a.__wbindgen_free(o, i, 1);
        }
    }
    function ae(e) {
        let n, r;
        try {
            const c = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l, i = a.api_create_label(c, o);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, f(i[2]);
            return n = t, r = _, g(t, _);
        } finally{
            a.__wbindgen_free(n, r, 1);
        }
    }
    function z(e) {
        let n, r;
        try {
            const c = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l, i = a.api_create_new_vault(c, o);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, f(i[2]);
            return n = t, r = _, g(t, _);
        } finally{
            a.__wbindgen_free(n, r, 1);
        }
    }
    function ce(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l, t = a.api_delete_entry(n, r);
        if (t[1]) throw f(t[0]);
    }
    function oe(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l, t = a.api_delete_label(n, r);
        if (t[1]) throw f(t[0]);
    }
    function Y(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l;
        return a.api_download(n, r);
    }
    function ie(e, n, r, t, _) {
        let c, o;
        try {
            const w = a.api_generate_password(e, n, r, t, _);
            var i = w[0], b = w[1];
            if (w[3]) throw i = 0, b = 0, f(w[2]);
            return c = i, o = b, g(i, b);
        } finally{
            a.__wbindgen_free(c, o, 1);
        }
    }
    function Le(e, n, r) {
        let t, _;
        try {
            const i = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), b = l, w = a.api_generate_totp(i, b, n, r);
            var c = w[0], o = w[1];
            if (w[3]) throw c = 0, o = 0, f(w[2]);
            return t = c, _ = o, g(c, o);
        } finally{
            a.__wbindgen_free(t, _, 1);
        }
    }
    function le(e) {
        let n, r;
        try {
            const c = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l, i = a.api_generate_totp_default(c, o);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, f(i[2]);
            return n = t, r = _, g(t, _);
        } finally{
            a.__wbindgen_free(n, r, 1);
        }
    }
    function se(e) {
        let n, r;
        try {
            const c = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l, i = a.api_get_entry(c, o);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, f(i[2]);
            return n = t, r = _, g(t, _);
        } finally{
            a.__wbindgen_free(n, r, 1);
        }
    }
    function N() {
        const e = a.api_get_vault_bytes();
        if (e[3]) throw f(e[2]);
        var n = I(e[0], e[1]).slice();
        return a.__wbindgen_free(e[0], e[1] * 1, 1), n;
    }
    function H(e, n, r, t, _) {
        let c, o;
        try {
            var i = y(e) ? 0 : s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), b = l, w = y(n) ? 0 : s(n, a.__wbindgen_malloc, a.__wbindgen_realloc), m = l, D = y(r) ? 0 : s(r, a.__wbindgen_malloc, a.__wbindgen_realloc), E = l;
            const T = a.api_list_entries(i, b, w, m, D, E, t, _);
            var A = T[0], W = T[1];
            if (T[3]) throw A = 0, W = 0, f(T[2]);
            return c = A, o = W, g(A, W);
        } finally{
            a.__wbindgen_free(c, o, 1);
        }
    }
    function ue() {
        let e, n;
        try {
            const _ = a.api_list_labels();
            var r = _[0], t = _[1];
            if (_[3]) throw r = 0, t = 0, f(_[2]);
            return e = r, n = t, g(r, t);
        } finally{
            a.__wbindgen_free(e, n, 1);
        }
    }
    function F(e, n) {
        const r = Dt(e, a.__wbindgen_malloc), t = l, _ = s(n, a.__wbindgen_malloc, a.__wbindgen_realloc), c = l, o = a.api_load_vault(r, t, _, c);
        if (o[1]) throw f(o[0]);
    }
    function Z() {
        const e = a.api_lock();
        if (e[3]) throw f(e[2]);
        var n = I(e[0], e[1]).slice();
        return a.__wbindgen_free(e[0], e[1] * 1, 1), n;
    }
    function fe(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l, t = a.api_purge_entry(n, r);
        if (t[1]) throw f(t[0]);
    }
    function k(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l;
        return a.api_push(n, r);
    }
    function de(e) {
        let n, r;
        try {
            const c = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l, i = a.api_regenerate_recovery_key(c, o);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, f(i[2]);
            return n = t, r = _, g(t, _);
        } finally{
            a.__wbindgen_free(n, r, 1);
        }
    }
    function be(e, n) {
        const r = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), t = l, _ = s(n, a.__wbindgen_malloc, a.__wbindgen_realloc), c = l, o = a.api_rename_label(r, t, _, c);
        if (o[1]) throw f(o[0]);
    }
    function ge(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l, t = a.api_restore_entry(n, r);
        if (t[1]) throw f(t[0]);
    }
    function we(e) {
        let n, r;
        try {
            const c = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l, i = a.api_rotate_dek(c, o);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, f(i[2]);
            return n = t, r = _, g(t, _);
        } finally{
            a.__wbindgen_free(n, r, 1);
        }
    }
    function ye(e, n) {
        const r = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), t = l, _ = R(n, a.__wbindgen_malloc), c = l, o = a.api_set_entry_labels(r, t, _, c);
        if (o[1]) throw f(o[0]);
    }
    function Se(e, n) {
        const r = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), t = l, _ = a.api_set_favorite(r, t, n);
        if (_[1]) throw f(_[0]);
    }
    function G(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l;
        return a.api_sync(n, r);
    }
    function X(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l, t = a.api_unlock(n, r);
        if (t[1]) throw f(t[0]);
    }
    function pe(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l, t = a.api_unlock_with_recovery_key(n, r);
        if (t[1]) throw f(t[0]);
    }
    function he(e, n, r, t, _, c) {
        const o = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), i = l;
        var b = y(n) ? 0 : s(n, a.__wbindgen_malloc, a.__wbindgen_realloc), w = l, m = y(r) ? 0 : s(r, a.__wbindgen_malloc, a.__wbindgen_realloc), D = l, E = y(t) ? 0 : s(t, a.__wbindgen_malloc, a.__wbindgen_realloc), A = l, W = y(_) ? 0 : R(_, a.__wbindgen_malloc), T = l, J = y(c) ? 0 : s(c, a.__wbindgen_malloc, a.__wbindgen_realloc), q = l;
        const B = a.api_update_entry(o, i, b, w, m, D, E, A, W, T, J, q);
        if (B[1]) throw f(B[0]);
    }
    function Oe(e, n, r, t) {
        let _, c;
        try {
            const b = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), w = l, m = a.api_upgrade_argon2_params(b, w, n, r, t);
            var o = m[0], i = m[1];
            if (m[3]) throw o = 0, i = 0, f(m[2]);
            return _ = o, c = i, g(o, i);
        } finally{
            a.__wbindgen_free(_, c, 1);
        }
    }
    function Ce(e, n) {
        const r = Q(n), t = s(r, a.__wbindgen_malloc, a.__wbindgen_realloc), _ = l;
        L().setInt32(e + 4 * 1, _, !0), L().setInt32(e + 4 * 0, t, !0);
    }
    function Ne(e) {
        return typeof e == "function";
    }
    function Ve(e) {
        const n = e;
        return typeof n == "object" && n !== null;
    }
    function Ue(e) {
        return typeof e == "string";
    }
    function Ie(e) {
        return e === void 0;
    }
    function De(e, n) {
        const r = n, t = typeof r == "string" ? r : void 0;
        var _ = y(t) ? 0 : s(t, a.__wbindgen_malloc, a.__wbindgen_realloc), c = l;
        L().setInt32(e + 4 * 1, c, !0), L().setInt32(e + 4 * 0, _, !0);
    }
    function Me(e, n) {
        throw new Error(g(e, n));
    }
    function Be(e) {
        e._wbg_cb_unref();
    }
    function Pe() {
        return v(function(e) {
            return e.arrayBuffer();
        }, arguments);
    }
    function $e() {
        return v(function(e, n, r) {
            return e.call(n, r);
        }, arguments);
    }
    function Ye(e) {
        return e.crypto;
    }
    function Fe(e, n) {
        return e.fetch(n);
    }
    function Ge() {
        return v(function(e, n) {
            globalThis.crypto.getRandomValues(I(e, n));
        }, arguments);
    }
    function xe() {
        return v(function(e, n) {
            e.getRandomValues(n);
        }, arguments);
    }
    function Je(e) {
        return e.getTime();
    }
    function qe() {
        return v(function(e, n, r, t) {
            const _ = n.get(g(r, t));
            var c = y(_) ? 0 : s(_, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l;
            L().setInt32(e + 4 * 1, o, !0), L().setInt32(e + 4 * 0, c, !0);
        }, arguments);
    }
    function je(e) {
        return e.headers;
    }
    function Ke(e) {
        let n;
        try {
            n = e instanceof Response;
        } catch  {
            n = !1;
        }
        return n;
    }
    function ze(e) {
        let n;
        try {
            n = e instanceof Window;
        } catch  {
            n = !1;
        }
        return n;
    }
    function He(e) {
        return e.length;
    }
    function Xe(e) {
        return e.msCrypto;
    }
    function Qe() {
        return v(function() {
            return new Headers;
        }, arguments);
    }
    function Ze() {
        return new Date;
    }
    function Re(e) {
        return new Uint8Array(e);
    }
    function et() {
        return new Object;
    }
    function tt(e, n) {
        return new Uint8Array(I(e, n));
    }
    function rt(e, n) {
        try {
            var r = {
                a: e,
                b: n
            }, t = (c, o)=>{
                const i = r.a;
                r.a = 0;
                try {
                    return Vt(i, r.b, c, o);
                } finally{
                    r.a = i;
                }
            };
            return new Promise(t);
        } finally{
            r.a = r.b = 0;
        }
    }
    function nt(e) {
        return new Uint8Array(e >>> 0);
    }
    function _t() {
        return v(function(e, n, r) {
            return new Request(g(e, n), r);
        }, arguments);
    }
    function at(e) {
        return e.node;
    }
    function ct(e) {
        return e.process;
    }
    function ot(e, n, r) {
        Uint8Array.prototype.set.call(I(e, n), r);
    }
    function it(e) {
        return e.queueMicrotask;
    }
    function lt(e) {
        queueMicrotask(e);
    }
    function st() {
        return v(function(e, n) {
            e.randomFillSync(n);
        }, arguments);
    }
    function ut() {
        return v(function() {
            return module.require;
        }, arguments);
    }
    function ft(e) {
        return Promise.resolve(e);
    }
    function dt(e, n) {
        e.body = n;
    }
    function bt() {
        return v(function(e, n, r, t, _) {
            e.set(g(n, r), g(t, _));
        }, arguments);
    }
    function gt(e, n) {
        e.headers = n;
    }
    function wt(e, n, r) {
        e.method = g(n, r);
    }
    function yt(e, n) {
        e.mode = Ut[n];
    }
    function St() {
        const e = typeof global > "u" ? null : global;
        return y(e) ? 0 : U(e);
    }
    function pt() {
        const e = typeof globalThis > "u" ? null : globalThis;
        return y(e) ? 0 : U(e);
    }
    function ht() {
        const e = typeof self > "u" ? null : self;
        return y(e) ? 0 : U(e);
    }
    function mt() {
        const e = typeof window > "u" ? null : window;
        return y(e) ? 0 : U(e);
    }
    function vt(e) {
        return e.status;
    }
    function At(e, n, r) {
        return e.subarray(n >>> 0, r >>> 0);
    }
    function kt(e, n) {
        return e.then(n);
    }
    function Tt(e, n, r) {
        return e.then(n, r);
    }
    function Et(e) {
        return e.versions;
    }
    function Wt(e, n) {
        return It(e, n, a.wasm_bindgen__closure__destroy__h3f8964959a1d4cde, Nt);
    }
    function Lt(e, n) {
        return I(e, n);
    }
    function Ot(e, n) {
        return g(e, n);
    }
    function Ct() {
        const e = a.__wbindgen_externrefs, n = e.grow(4);
        e.set(0, void 0), e.set(n + 0, void 0), e.set(n + 1, null), e.set(n + 2, !0), e.set(n + 3, !1);
    }
    function Nt(e, n, r) {
        const t = a.wasm_bindgen__convert__closures_____invoke__hb920389fa6ed5e03(e, n, r);
        if (t[1]) throw f(t[0]);
    }
    function Vt(e, n, r, t) {
        a.wasm_bindgen__convert__closures_____invoke__h40d0a0a79b0a349e(e, n, r, t);
    }
    const Ut = [
        "same-origin",
        "no-cors",
        "cors",
        "navigate"
    ];
    function U(e) {
        const n = a.__externref_table_alloc();
        return a.__wbindgen_externrefs.set(n, e), n;
    }
    const te = typeof FinalizationRegistry > "u" ? {
        register: ()=>{},
        unregister: ()=>{}
    } : new FinalizationRegistry((e)=>e.dtor(e.a, e.b));
    function Q(e) {
        const n = typeof e;
        if (n == "number" || n == "boolean" || e == null) return `${e}`;
        if (n == "string") return `"${e}"`;
        if (n == "symbol") {
            const _ = e.description;
            return _ == null ? "Symbol" : `Symbol(${_})`;
        }
        if (n == "function") {
            const _ = e.name;
            return typeof _ == "string" && _.length > 0 ? `Function(${_})` : "Function";
        }
        if (Array.isArray(e)) {
            const _ = e.length;
            let c = "[";
            _ > 0 && (c += Q(e[0]));
            for(let o = 1; o < _; o++)c += ", " + Q(e[o]);
            return c += "]", c;
        }
        const r = /\[object ([^\]]+)\]/.exec(toString.call(e));
        let t;
        if (r && r.length > 1) t = r[1];
        else return toString.call(e);
        if (t == "Object") try {
            return "Object(" + JSON.stringify(e) + ")";
        } catch  {
            return "Object";
        }
        return e instanceof Error ? `${e.name}: ${e.message}
${e.stack}` : t;
    }
    function I(e, n) {
        return e = e >>> 0, V().subarray(e / 1, e / 1 + n);
    }
    let O = null;
    function L() {
        return (O === null || O.buffer.detached === !0 || O.buffer.detached === void 0 && O.buffer !== a.memory.buffer) && (O = new DataView(a.memory.buffer)), O;
    }
    function g(e, n) {
        return e = e >>> 0, Bt(e, n);
    }
    let $ = null;
    function V() {
        return ($ === null || $.byteLength === 0) && ($ = new Uint8Array(a.memory.buffer)), $;
    }
    function v(e, n) {
        try {
            return e.apply(this, n);
        } catch (r) {
            const t = U(r);
            a.__wbindgen_exn_store(t);
        }
    }
    function y(e) {
        return e == null;
    }
    function It(e, n, r, t) {
        const _ = {
            a: e,
            b: n,
            cnt: 1,
            dtor: r
        }, c = (...o)=>{
            _.cnt++;
            const i = _.a;
            _.a = 0;
            try {
                return t(i, _.b, ...o);
            } finally{
                _.a = i, c._wbg_cb_unref();
            }
        };
        return c._wbg_cb_unref = ()=>{
            --_.cnt === 0 && (_.dtor(_.a, _.b), _.a = 0, te.unregister(_));
        }, te.register(c, _, _), c;
    }
    function Dt(e, n) {
        const r = n(e.length * 1, 1) >>> 0;
        return V().set(e, r / 1), l = e.length, r;
    }
    function R(e, n) {
        const r = n(e.length * 4, 4) >>> 0;
        for(let t = 0; t < e.length; t++){
            const _ = U(e[t]);
            L().setUint32(r + 4 * t, _, !0);
        }
        return l = e.length, r;
    }
    function s(e, n, r) {
        if (r === void 0) {
            const i = M.encode(e), b = n(i.length, 1) >>> 0;
            return V().subarray(b, b + i.length).set(i), l = i.length, b;
        }
        let t = e.length, _ = n(t, 1) >>> 0;
        const c = V();
        let o = 0;
        for(; o < t; o++){
            const i = e.charCodeAt(o);
            if (i > 127) break;
            c[_ + o] = i;
        }
        if (o !== t) {
            o !== 0 && (e = e.slice(o)), _ = r(_, t, t = o + e.length * 3, 1) >>> 0;
            const i = V().subarray(_ + o, _ + t), b = M.encodeInto(e, i);
            o += b.written, _ = r(_, t, o, 1) >>> 0;
        }
        return l = o, _;
    }
    function f(e) {
        const n = a.__wbindgen_externrefs.get(e);
        return a.__externref_table_dealloc(e), n;
    }
    let x = new TextDecoder("utf-8", {
        ignoreBOM: !0,
        fatal: !0
    });
    x.decode();
    const Mt = 2146435072;
    let j = 0;
    function Bt(e, n) {
        return j += n, j >= Mt && (x = new TextDecoder("utf-8", {
            ignoreBOM: !0,
            fatal: !0
        }), x.decode(), j = n), x.decode(V().subarray(e, e + n));
    }
    const M = new TextEncoder;
    "encodeInto" in M || (M.encodeInto = function(e, n) {
        const r = M.encode(e);
        return n.set(r), {
            read: e.length,
            written: r.length
        };
    });
    let l = 0, a;
    function Pt(e) {
        a = e;
    }
    URL = globalThis.URL;
    const $t = await We({
        "./vault_core_bg.js": {
            __wbg_new_typed_aaaeaf29cf802876: rt,
            __wbg_then_9e335f6dd892bc11: Tt,
            __wbg_call_2d781c1f4d5c0ef8: $e,
            __wbg_then_098abe61755d12f6: kt,
            __wbg_queueMicrotask_a082d78ce798393e: lt,
            __wbg_queueMicrotask_0c399741342fb10f: it,
            __wbg_resolve_ae8d83246e5bcc12: ft,
            __wbg_instanceof_Window_23e677d2c6843922: ze,
            __wbg_fetch_f8a611684c3b5fe5: Fe,
            __wbg_get_a867a94064ecd263: qe,
            __wbg_new_0837727332ac86ba: Qe,
            __wbg_set_e09648bea3f1af1e: bt,
            __wbg_instanceof_Response_9b4d9fd451e051b1: Ke,
            __wbg_arrayBuffer_eb8e9ca620af2a19: Pe,
            __wbg_status_318629ab93a22955: vt,
            __wbg_headers_eb2234545f9ff993: je,
            __wbg_set_method_8c015e8bcafd7be1: wt,
            __wbg_set_headers_3c8fecc693b75327: gt,
            __wbg_set_body_a3d856b097dfda04: dt,
            __wbg_set_mode_5a87f2c809cf37c2: yt,
            __wbg_new_with_str_and_init_b4b54d1a819bc724: _t,
            __wbg_getRandomValues_a1cf2e70b003a59d: Ge,
            __wbg_crypto_38df2bab126b63dc: Ye,
            __wbg_process_44c7a14e11e9f69e: ct,
            __wbg_versions_276b2795b1c6a219: Et,
            __wbg_node_84ea875411254db1: at,
            __wbg_require_b4edbdcf3e2a1ef0: ut,
            __wbg_msCrypto_bd5a034af96bcba6: Xe,
            __wbg_randomFillSync_6c25eac9869eb53c: st,
            __wbg_getRandomValues_c44a50d8cfdaebeb: xe,
            __wbg_new_ab79df5bd7c26067: et,
            __wbg_new_5f486cdf45a04d78: Re,
            __wbg_length_ea16607d7b61445b: He,
            __wbg_prototypesetcall_d62e5099504357e6: ot,
            __wbg_new_from_slice_22da9388ac046e50: tt,
            __wbg_new_with_length_825018a1616e9e55: nt,
            __wbg_subarray_a068d24e39478a8a: At,
            __wbg_new_0_1dcafdf5e786e876: Ze,
            __wbg_getTime_1dad7b5386ddd2d9: Je,
            __wbg_static_accessor_GLOBAL_THIS_ad356e0db91c7913: pt,
            __wbg_static_accessor_SELF_f207c857566db248: ht,
            __wbg_static_accessor_GLOBAL_8adb955bd33fac2f: St,
            __wbg_static_accessor_WINDOW_bb9f1ba69d61b386: mt,
            __wbg___wbindgen_throw_6ddd609b62940d55: Me,
            __wbg___wbindgen_is_object_781bc9f159099513: Ve,
            __wbg___wbindgen_is_string_7ef6b97b02428fae: Ue,
            __wbg___wbindgen_string_get_395e606bd0ee4427: De,
            __wbg___wbindgen_is_function_3c846841762788c1: Ne,
            __wbg___wbindgen_is_undefined_52709e72fb9f179c: Ie,
            __wbg___wbindgen_debug_string_5398f5bb970e0daa: Ce,
            __wbg__wbg_cb_unref_6b5b6b8576d35cb1: Be,
            __wbindgen_init_externref_table: Ct,
            __wbindgen_cast_0000000000000001: Wt,
            __wbindgen_cast_0000000000000002: Lt,
            __wbindgen_cast_0000000000000003: Ot
        }
    }, Ee), { memory: Yt, api_change_master_password: Ft, api_create_entry: Gt, api_create_label: xt, api_create_new_vault: Jt, api_delete_entry: qt, api_delete_label: jt, api_download: Kt, api_generate_password: zt, api_generate_totp: Ht, api_generate_totp_default: Xt, api_get_entry: Qt, api_get_vault_bytes: Zt, api_list_entries: Rt, api_list_labels: er, api_load_vault: tr, api_lock: rr, api_purge_entry: nr, api_push: _r, api_regenerate_recovery_key: ar, api_rename_label: cr, api_restore_entry: or, api_rotate_dek: ir, api_set_entry_labels: lr, api_set_favorite: sr, api_sync: ur, api_unlock: fr, api_unlock_with_recovery_key: dr, api_update_entry: br, api_upgrade_argon2_params: gr, wasm_bindgen__closure__destroy__h3f8964959a1d4cde: wr, wasm_bindgen__convert__closures_____invoke__hb920389fa6ed5e03: yr, wasm_bindgen__convert__closures_____invoke__h40d0a0a79b0a349e: Sr, __wbindgen_malloc: pr, __wbindgen_realloc: hr, __wbindgen_exn_store: mr, __externref_table_alloc: vr, __wbindgen_externrefs: Ar, __externref_table_dealloc: kr, __wbindgen_free: Tr, __wbindgen_start: me } = $t, Er = Object.freeze(Object.defineProperty({
        __proto__: null,
        __externref_table_alloc: vr,
        __externref_table_dealloc: kr,
        __wbindgen_exn_store: mr,
        __wbindgen_externrefs: Ar,
        __wbindgen_free: Tr,
        __wbindgen_malloc: pr,
        __wbindgen_realloc: hr,
        __wbindgen_start: me,
        api_change_master_password: Ft,
        api_create_entry: Gt,
        api_create_label: xt,
        api_create_new_vault: Jt,
        api_delete_entry: qt,
        api_delete_label: jt,
        api_download: Kt,
        api_generate_password: zt,
        api_generate_totp: Ht,
        api_generate_totp_default: Xt,
        api_get_entry: Qt,
        api_get_vault_bytes: Zt,
        api_list_entries: Rt,
        api_list_labels: er,
        api_load_vault: tr,
        api_lock: rr,
        api_purge_entry: nr,
        api_push: _r,
        api_regenerate_recovery_key: ar,
        api_rename_label: cr,
        api_restore_entry: or,
        api_rotate_dek: ir,
        api_set_entry_labels: lr,
        api_set_favorite: sr,
        api_sync: ur,
        api_unlock: fr,
        api_unlock_with_recovery_key: dr,
        api_update_entry: br,
        api_upgrade_argon2_params: gr,
        memory: Yt,
        wasm_bindgen__closure__destroy__h3f8964959a1d4cde: wr,
        wasm_bindgen__convert__closures_____invoke__h40d0a0a79b0a349e: Sr,
        wasm_bindgen__convert__closures_____invoke__hb920389fa6ed5e03: yr
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    Pt(Er);
    me();
    const Wr = Object.freeze(Object.defineProperty({
        __proto__: null,
        api_change_master_password: K,
        api_create_entry: _e,
        api_create_label: ae,
        api_create_new_vault: z,
        api_delete_entry: ce,
        api_delete_label: oe,
        api_download: Y,
        api_generate_password: ie,
        api_generate_totp: Le,
        api_generate_totp_default: le,
        api_get_entry: se,
        api_get_vault_bytes: N,
        api_list_entries: H,
        api_list_labels: ue,
        api_load_vault: F,
        api_lock: Z,
        api_purge_entry: fe,
        api_push: k,
        api_regenerate_recovery_key: de,
        api_rename_label: be,
        api_restore_entry: ge,
        api_rotate_dek: we,
        api_set_entry_labels: ye,
        api_set_favorite: Se,
        api_sync: G,
        api_unlock: X,
        api_unlock_with_recovery_key: pe,
        api_update_entry: he,
        api_upgrade_argon2_params: Oe
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    let re = !1, u = !1;
    async function ee() {
        if (!re) try {
            re = !0, console.log("[SW] WASM initialized");
        } catch (e) {
            throw console.error("[SW] WASM initialization error:", e), e;
        }
    }
    function Lr() {
        console.log("[SW] Setting up message handlers"), chrome.runtime.onMessage.addListener((e, n, r)=>(console.log("[SW] Message received:", e.type), Or(e, n, r).catch((t)=>{
                console.error("[SW] Unhandled error in message handler:", t);
                try {
                    r({
                        success: !1,
                        error: String(t)
                    });
                } catch (_) {
                    console.error("[SW] Failed to send error response:", _);
                }
            }), !0));
    }
    console.log("[SW] Registering message handlers immediately on script load");
    Lr();
    self.addEventListener("install", (e)=>{
        console.log("[SW] install event"), e.waitUntil(ee());
    });
    self.addEventListener("activate", (e)=>{
        console.log("[SW] activate event"), e.waitUntil(ee().then(()=>{
            console.log("[SW] Calling setupAlarms in activate"), Cr();
        }));
    });
    function ve(e) {
        return e && {
            id: e.id,
            entryType: e.entry_type,
            name: e.name,
            isFavorite: e.is_favorite ?? !1,
            updatedAt: e.updated_at ?? 0,
            deletedAt: e.deleted_at ?? null,
            notes: e.notes ?? null,
            typedValue: e.typed_value ?? {},
            labels: e.label_ids ?? [],
            customFields: (e.custom_fields ?? []).map((n)=>({
                    id: n.id,
                    name: n.name,
                    fieldType: n.field_type,
                    value: n.value
                }))
        };
    }
    function ne(e) {
        return (e ?? []).map(ve);
    }
    async function S() {
        try {
            console.log("[SW] autoSaveAndPush: Starting");
            const e = N();
            console.log("[SW] autoSaveAndPush: Got vault bytes, size:", e?.length), await p(d.VAULT_BYTES, Array.from(e));
            const n = await h(d.S3_CONFIG);
            if (console.log("[SW] autoSaveAndPush: s3Config exists:", !!n), console.log("[SW] autoSaveAndPush: api_push type:", typeof k), n) try {
                if (typeof k == "function") {
                    console.log("[SW] autoSaveAndPush: Calling api_push");
                    const r = await k(JSON.stringify(n));
                    console.log("[SW] autoSaveAndPush: api_push returned:", r), await p(d.LAST_SYNC_TIME, new Date().toISOString()), console.log("[SW] Auto-push successful");
                } else console.warn("[SW] autoSaveAndPush: api_push not available in WASM");
            } catch (r) {
                console.warn("[SW] Auto-push failed:", r);
            }
            else console.log("[SW] autoSaveAndPush: No S3 config, skipping push");
        } catch (e) {
            console.error("[SW] autoSaveAndPush failed:", e);
        }
    }
    async function C() {
        return await h(d.APP_SETTINGS) || {
            autolockMinutes: 5,
            clipboardClearSeconds: 30,
            clipboardAutoClean: !0,
            theme: "light"
        };
    }
    async function Or(e, n, r) {
        try {
            if (await ee(), !u) {
                const t = await h(d.VAULT_BYTES);
                if (t) try {
                    const _ = await h(d.VAULT_ETAG);
                    console.log("[SW] Auto-loading vault from storage (Service Worker recovered)"), F(new Uint8Array(t), _ || "");
                } catch (_) {
                    console.warn("[SW] Failed to auto-load vault:", _);
                }
            }
            switch(e.type){
                case "IS_UNLOCKED":
                    {
                        r({
                            success: !0,
                            unlocked: u
                        });
                        break;
                    }
                case "UNLOCK":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await h(d.VAULT_BYTES), _ = await h(d.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            F(new Uint8Array(t), _ || ""), X(e.password), u = !0;
                            const c = await C();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UNLOCK_EXISTING":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await h(d.VAULT_BYTES), _ = await h(d.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            F(new Uint8Array(t), _ || ""), X(e.password), u = !0;
                            const c = await C();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LOCK":
                    {
                        try {
                            const t = Z();
                            await p(d.VAULT_BYTES, Array.from(t)), u = !1, chrome.alarms.clear("autolock"), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_VAULT":
                    {
                        if (!e.masterPassword) {
                            r({
                                success: !1,
                                error: "Master password required"
                            });
                            break;
                        }
                        try {
                            console.log("[SW] CREATE_VAULT: Starting vault creation"), console.log("[SW] CREATE_VAULT: vault object type:", typeof Wr), console.log("[SW] CREATE_VAULT: vault.api_create_new_vault:", typeof z);
                            const t = z(e.masterPassword);
                            console.log("[SW] CREATE_VAULT: Vault created, recovery key:", t);
                            const _ = N();
                            console.log("[SW] CREATE_VAULT: Got vault bytes, size:", _?.length), await p(d.VAULT_BYTES, Array.from(_)), await p(d.VAULT_ETAG, null), console.log("[SW] CREATE_VAULT: Saved vault bytes to storage"), e.s3Config && await p(d.S3_CONFIG, e.s3Config), u = !0;
                            const c = await C();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), console.log("[SW] CREATE_VAULT: Success, sending response");
                            const o = {
                                success: !0,
                                recoveryKey: t
                            };
                            console.log("[SW] CREATE_VAULT: Response payload:", o), r(o), console.log("[SW] CREATE_VAULT: sendResponse called");
                        } catch (t) {
                            console.error("[SW] CREATE_VAULT: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RECOVER":
                    {
                        if (!e.recoveryKey || !e.newPassword) {
                            r({
                                success: !1,
                                error: "Recovery key and password required"
                            });
                            break;
                        }
                        try {
                            pe(e.recoveryKey), K(e.recoveryKey, e.newPassword);
                            const t = N();
                            await p(d.VAULT_BYTES, Array.from(t)), await p(d.VAULT_ETAG, null), await S(), u = !0;
                            const _ = await C();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: _.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_ENTRIES":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = e.filter || {}, _ = H(t.searchQuery || null, t.type || null, t.labelId || null, t.includeTrash || !1, t.onlyFavorites || !1), c = JSON.parse(_), o = ne(c);
                            r({
                                success: !0,
                                entries: o
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = se(e.id), _ = JSON.parse(t);
                            _ && _.typed_value && typeof _.typed_value == "string" && (_.typed_value = JSON.parse(_.typed_value));
                            const c = ve(_);
                            r({
                                success: !0,
                                entry: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = _e(e.entryType, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null);
                            await S(), r({
                                success: !0,
                                entryId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UPDATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            he(e.id, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ce(e.id), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RESTORE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ge(e.id), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PURGE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            fe(e.id), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_FAVORITE":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            Se(e.id, e.isFavorite), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_TRASH":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = H(null, null, null, !0, !1), _ = JSON.parse(t), c = ne(_);
                            r({
                                success: !0,
                                entries: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ue(), _ = JSON.parse(t);
                            r({
                                success: !0,
                                labels: _
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ae(e.name);
                            await S(), r({
                                success: !0,
                                labelId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            oe(e.id), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RENAME_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            be(e.id, e.newName), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_ENTRY_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ye(e.entryId, e.labelIds || []), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_PASSWORD":
                    {
                        try {
                            const t = ie(e.length ?? 16, e.includeUppercase ?? !0, e.includeLowercase ?? !0, e.includeNumbers ?? !0, e.includeSymbols ?? !0);
                            r({
                                success: !0,
                                password: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_TOTP":
                    {
                        try {
                            const t = le(e.secret);
                            r({
                                success: !0,
                                totp: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CHANGE_MASTER_PASSWORD":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            K(e.oldPassword, e.newPassword), await S(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "ROTATE_DEK":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = we(e.password);
                            await S(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "REGENERATE_RECOVERY_KEY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = de(e.password);
                            await S(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DOWNLOAD_VAULT":
                    {
                        try {
                            const t = await h(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            if (typeof Y != "function") {
                                console.warn("[SW] DOWNLOAD_VAULT: api_download is not available in vault_core"), r({
                                    success: !1,
                                    error: "S3 download feature is not yet implemented in vault_core"
                                });
                                break;
                            }
                            console.log("[SW] DOWNLOAD_VAULT: Downloading vault from S3");
                            const _ = await Y(JSON.stringify(t));
                            if (_) {
                                const c = N();
                                await p(d.VAULT_BYTES, Array.from(c)), console.log("[SW] DOWNLOAD_VAULT: Vault downloaded and saved to storage");
                            } else console.log("[SW] DOWNLOAD_VAULT: Vault not found in S3, vaultExists=false");
                            r({
                                success: !0,
                                vaultExists: _
                            });
                        } catch (t) {
                            console.error("[SW] DOWNLOAD_VAULT: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PUSH_VAULT":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = await h(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            if (typeof k != "function") {
                                console.warn("[SW] PUSH_VAULT: api_push is not available in vault_core"), r({
                                    success: !1,
                                    error: "S3 push feature is not yet implemented in vault_core"
                                });
                                break;
                            }
                            console.log("[SW] PUSH_VAULT: Pushing vault to S3"), await k(JSON.stringify(t)), await p(d.LAST_SYNC_TIME, new Date().toISOString()), console.log("[SW] PUSH_VAULT: Push successful"), r({
                                success: !0
                            });
                        } catch (t) {
                            console.error("[SW] PUSH_VAULT: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DOWNLOAD":
                    {
                        try {
                            console.log("[SW] DOWNLOAD: Starting download");
                            const t = e.storageConfig ? JSON.parse(e.storageConfig) : await h(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            const _ = JSON.stringify(t);
                            console.log("[SW] DOWNLOAD: Calling api_download");
                            const c = await Y(_);
                            console.log("[SW] DOWNLOAD: api_download completed, result:", c), r({
                                success: !0,
                                result: c
                            });
                        } catch (t) {
                            console.error("[SW] DOWNLOAD: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SYNC":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            console.log("[SW] SYNC: Starting sync");
                            const t = await h(d.S3_CONFIG);
                            if (console.log("[SW] SYNC: s3Config:", t), !t) {
                                console.log("[SW] SYNC: No S3 config found"), r({
                                    success: !0,
                                    status: "idle",
                                    message: "S3 config not set"
                                });
                                break;
                            }
                            console.log("[SW] SYNC: api_sync available:", typeof G == "function"), console.log("[SW] SYNC: api_push available:", typeof k == "function");
                            const _ = JSON.stringify(t);
                            if (typeof G == "function") {
                                console.log("[SW] SYNC: Calling api_sync");
                                const o = await G(_);
                                console.log("[SW] SYNC: api_sync completed successfully");
                            } else if (typeof k == "function") {
                                console.log("[SW] SYNC: api_sync not available, using api_push instead");
                                const o = await k(_);
                                console.log("[SW] SYNC: api_push completed successfully");
                            } else throw new Error("Neither api_sync nor api_push is available");
                            const c = N();
                            console.log("[SW] SYNC: Got vault bytes after sync, size:", c?.length), await p(d.VAULT_BYTES, Array.from(c)), await p(d.LAST_SYNC_TIME, new Date().toISOString()), console.log("[SW] SYNC: Sync completed successfully"), r({
                                success: !0,
                                status: "synced"
                            });
                        } catch (t) {
                            console.error("[SW] SYNC: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_SETTINGS":
                    {
                        const t = await C();
                        r({
                            success: !0,
                            settings: t
                        });
                        break;
                    }
                case "SAVE_SETTINGS":
                    {
                        try {
                            await p(d.APP_SETTINGS, e.settings), u && chrome.alarms.create("autolock", {
                                delayInMinutes: e.settings.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CLIPBOARD_COPIED":
                    {
                        try {
                            const t = await C();
                            if (t.clipboardAutoClean) {
                                const _ = t.clipboardClearSeconds / 60;
                                chrome.alarms.create("clipboard-clear", {
                                    delayInMinutes: _
                                });
                            }
                            r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                default:
                    r({
                        success: !1,
                        error: "Unknown message type"
                    });
            }
        } catch (t) {
            console.error("[SW] Message handling error:", t), r({
                success: !1,
                error: String(t)
            });
        }
    }
    function Cr() {
        chrome.alarms.onAlarm.addListener((e)=>{
            e.name === "autolock" ? Nr() : e.name === "clipboard-clear" && Vr();
        });
    }
    async function Nr() {
        if (console.log("[SW] Autolock alarm triggered"), !!u) try {
            const e = Z();
            await p(d.VAULT_BYTES, Array.from(e)), u = !1, console.log("[SW] Vault locked");
        } catch (e) {
            console.error("[SW] Autolock failed:", e);
        }
    }
    async function Vr() {
        console.log("[SW] Clipboard clear alarm triggered");
        try {
            typeof chrome.offscreen < "u" ? (await chrome.offscreen.createDocument({
                url: chrome.runtime.getURL("src/background/offscreen.html"),
                reasons: [
                    "CLIPBOARD"
                ],
                justification: "Clear clipboard after copy timeout"
            }), chrome.runtime.sendMessage({
                type: "CLEAR_CLIPBOARD"
            })) : await navigator.clipboard.writeText("");
        } catch (e) {
            console.error("[SW] Clipboard clear failed:", e);
        }
    }
})();
