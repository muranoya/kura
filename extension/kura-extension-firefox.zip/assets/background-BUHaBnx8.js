import { s as S, S as d, g as v } from "./constants-BFP2TXfE.js";
(async ()=>{
    const me = "/assets/vault_core_bg-BR5Sab9T.wasm", ve = async (e = {}, a)=>{
        let r;
        if (a.startsWith("data:")) {
            const t = a.replace(/^data:.*?base64,/, "");
            let _;
            if (typeof Buffer == "function" && typeof Buffer.from == "function") _ = Buffer.from(t, "base64");
            else if (typeof atob == "function") {
                const o = atob(t);
                _ = new Uint8Array(o.length);
                for(let c = 0; c < o.length; c++)_[c] = o.charCodeAt(c);
            } else throw new Error("Cannot decode base64-encoded data URL");
            r = await WebAssembly.instantiate(_, e);
        } else {
            const t = await fetch(a), _ = t.headers.get("Content-Type") || "";
            if ("instantiateStreaming" in WebAssembly && _.startsWith("application/wasm")) r = await WebAssembly.instantiateStreaming(t, e);
            else {
                const o = await t.arrayBuffer();
                r = await WebAssembly.instantiate(o, e);
            }
        }
        return r.instance.exports;
    };
    function x(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = l, _ = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), o = l, c = n.api_change_master_password(r, t, _, o);
        if (c[1]) throw f(c[0]);
    }
    function R(e, a, r, t, _, o) {
        let c, i;
        try {
            const E = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), T = l, P = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), $ = l;
            var b = g(r) ? 0 : s(r, n.__wbindgen_malloc, n.__wbindgen_realloc), w = l;
            const B = s(t, n.__wbindgen_malloc, n.__wbindgen_realloc), Se = l, pe = H(_, n.__wbindgen_malloc), he = l;
            var h = g(o) ? 0 : s(o, n.__wbindgen_malloc, n.__wbindgen_realloc), U = l;
            const M = n.api_create_entry(E, T, P, $, b, w, B, Se, pe, he, h, U);
            var k = M[0], m = M[1];
            if (M[3]) throw k = 0, m = 0, f(M[2]);
            return c = k, i = m, p(k, m);
        } finally{
            n.__wbindgen_free(c, i, 1);
        }
    }
    function ee(e) {
        let a, r;
        try {
            const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), c = l, i = n.api_create_label(o, c);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, f(i[2]);
            return a = t, r = _, p(t, _);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function Y(e) {
        let a, r;
        try {
            const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), c = l, i = n.api_create_new_vault(o, c);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, f(i[2]);
            return a = t, r = _, p(t, _);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function te(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = l, t = n.api_delete_entry(a, r);
        if (t[1]) throw f(t[0]);
    }
    function re(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = l, t = n.api_delete_label(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ae(e, a, r, t, _) {
        let o, c;
        try {
            const w = n.api_generate_password(e, a, r, t, _);
            var i = w[0], b = w[1];
            if (w[3]) throw i = 0, b = 0, f(w[2]);
            return o = i, c = b, p(i, b);
        } finally{
            n.__wbindgen_free(o, c, 1);
        }
    }
    function Te(e, a, r) {
        let t, _;
        try {
            const i = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), b = l, w = n.api_generate_totp(i, b, a, r);
            var o = w[0], c = w[1];
            if (w[3]) throw o = 0, c = 0, f(w[2]);
            return t = o, _ = c, p(o, c);
        } finally{
            n.__wbindgen_free(t, _, 1);
        }
    }
    function ne(e) {
        let a, r;
        try {
            const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), c = l, i = n.api_generate_totp_default(o, c);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, f(i[2]);
            return a = t, r = _, p(t, _);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function _e(e) {
        let a, r;
        try {
            const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), c = l, i = n.api_get_entry(o, c);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, f(i[2]);
            return a = t, r = _, p(t, _);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function V() {
        const e = n.api_get_vault_bytes();
        if (e[3]) throw f(e[2]);
        var a = I(e[0], e[1]).slice();
        return n.__wbindgen_free(e[0], e[1] * 1, 1), a;
    }
    function J(e, a, r, t, _) {
        let o, c;
        try {
            var i = g(e) ? 0 : s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), b = l, w = g(a) ? 0 : s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), h = l, U = g(r) ? 0 : s(r, n.__wbindgen_malloc, n.__wbindgen_realloc), k = l;
            const T = n.api_list_entries(i, b, w, h, U, k, t, _);
            var m = T[0], E = T[1];
            if (T[3]) throw m = 0, E = 0, f(T[2]);
            return o = m, c = E, p(m, E);
        } finally{
            n.__wbindgen_free(o, c, 1);
        }
    }
    function ce() {
        let e, a;
        try {
            const _ = n.api_list_labels();
            var r = _[0], t = _[1];
            if (_[3]) throw r = 0, t = 0, f(_[2]);
            return e = r, a = t, p(r, t);
        } finally{
            n.__wbindgen_free(e, a, 1);
        }
    }
    function K(e, a) {
        const r = et(e, n.__wbindgen_malloc), t = l, _ = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), o = l, c = n.api_load_vault(r, t, _, o);
        if (c[1]) throw f(c[0]);
    }
    function q() {
        const e = n.api_lock();
        if (e[3]) throw f(e[2]);
        var a = I(e[0], e[1]).slice();
        return n.__wbindgen_free(e[0], e[1] * 1, 1), a;
    }
    function oe(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = l, t = n.api_purge_entry(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ie(e) {
        let a, r;
        try {
            const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), c = l, i = n.api_regenerate_recovery_key(o, c);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, f(i[2]);
            return a = t, r = _, p(t, _);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function le(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = l, _ = s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), o = l, c = n.api_rename_label(r, t, _, o);
        if (c[1]) throw f(c[0]);
    }
    function se(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = l, t = n.api_restore_entry(a, r);
        if (t[1]) throw f(t[0]);
    }
    function ue(e) {
        let a, r;
        try {
            const o = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), c = l, i = n.api_rotate_dek(o, c);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, f(i[2]);
            return a = t, r = _, p(t, _);
        } finally{
            n.__wbindgen_free(a, r, 1);
        }
    }
    function fe(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = l, _ = H(a, n.__wbindgen_malloc), o = l, c = n.api_set_entry_labels(r, t, _, o);
        if (c[1]) throw f(c[0]);
    }
    function de(e, a) {
        const r = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), t = l, _ = n.api_set_favorite(r, t, a);
        if (_[1]) throw f(_[0]);
    }
    function j(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = l, t = n.api_unlock(a, r);
        if (t[1]) throw f(t[0]);
    }
    function be(e) {
        const a = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), r = l, t = n.api_unlock_with_recovery_key(a, r);
        if (t[1]) throw f(t[0]);
    }
    function we(e, a, r, t, _, o) {
        const c = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), i = l;
        var b = g(a) ? 0 : s(a, n.__wbindgen_malloc, n.__wbindgen_realloc), w = l, h = g(r) ? 0 : s(r, n.__wbindgen_malloc, n.__wbindgen_realloc), U = l, k = g(t) ? 0 : s(t, n.__wbindgen_malloc, n.__wbindgen_realloc), m = l, E = g(_) ? 0 : H(_, n.__wbindgen_malloc), T = l, P = g(o) ? 0 : s(o, n.__wbindgen_malloc, n.__wbindgen_realloc), $ = l;
        const B = n.api_update_entry(c, i, b, w, h, U, k, m, E, T, P, $);
        if (B[1]) throw f(B[0]);
    }
    function ke(e, a, r, t) {
        let _, o;
        try {
            const b = s(e, n.__wbindgen_malloc, n.__wbindgen_realloc), w = l, h = n.api_upgrade_argon2_params(b, w, a, r, t);
            var c = h[0], i = h[1];
            if (h[3]) throw c = 0, i = 0, f(h[2]);
            return _ = c, o = i, p(c, i);
        } finally{
            n.__wbindgen_free(_, o, 1);
        }
    }
    function Ee(e) {
        return typeof e == "function";
    }
    function Ae(e) {
        const a = e;
        return typeof a == "object" && a !== null;
    }
    function Le(e) {
        return typeof e == "string";
    }
    function Ve(e) {
        return e === void 0;
    }
    function Ce(e, a) {
        const r = a, t = typeof r == "string" ? r : void 0;
        var _ = g(t) ? 0 : s(t, n.__wbindgen_malloc, n.__wbindgen_realloc), o = l;
        z().setInt32(e + 4 * 1, o, !0), z().setInt32(e + 4 * 0, _, !0);
    }
    function Oe(e, a) {
        throw new Error(p(e, a));
    }
    function Ue() {
        return N(function(e, a, r) {
            return e.call(a, r);
        }, arguments);
    }
    function We(e) {
        return e.crypto;
    }
    function Ie() {
        return N(function(e, a) {
            globalThis.crypto.getRandomValues(I(e, a));
        }, arguments);
    }
    function Ne() {
        return N(function(e, a) {
            e.getRandomValues(a);
        }, arguments);
    }
    function Be(e) {
        return e.getTime();
    }
    function Me(e) {
        return e.length;
    }
    function De(e) {
        return e.msCrypto;
    }
    function Ge() {
        return new Date;
    }
    function Pe(e) {
        return new Uint8Array(e >>> 0);
    }
    function $e(e) {
        return e.node;
    }
    function Fe(e) {
        return e.process;
    }
    function xe(e, a, r) {
        Uint8Array.prototype.set.call(I(e, a), r);
    }
    function Ye() {
        return N(function(e, a) {
            e.randomFillSync(a);
        }, arguments);
    }
    function Je() {
        return N(function() {
            return module.require;
        }, arguments);
    }
    function Ke() {
        const e = typeof global > "u" ? null : global;
        return g(e) ? 0 : O(e);
    }
    function je() {
        const e = typeof globalThis > "u" ? null : globalThis;
        return g(e) ? 0 : O(e);
    }
    function ze() {
        const e = typeof self > "u" ? null : self;
        return g(e) ? 0 : O(e);
    }
    function qe() {
        const e = typeof window > "u" ? null : window;
        return g(e) ? 0 : O(e);
    }
    function He(e, a, r) {
        return e.subarray(a >>> 0, r >>> 0);
    }
    function Xe(e) {
        return e.versions;
    }
    function Qe(e, a) {
        return I(e, a);
    }
    function Ze(e, a) {
        return p(e, a);
    }
    function Re() {
        const e = n.__wbindgen_externrefs, a = e.grow(4);
        e.set(0, void 0), e.set(a + 0, void 0), e.set(a + 1, null), e.set(a + 2, !0), e.set(a + 3, !1);
    }
    function O(e) {
        const a = n.__externref_table_alloc();
        return n.__wbindgen_externrefs.set(a, e), a;
    }
    function I(e, a) {
        return e = e >>> 0, C().subarray(e / 1, e / 1 + a);
    }
    let A = null;
    function z() {
        return (A === null || A.buffer.detached === !0 || A.buffer.detached === void 0 && A.buffer !== n.memory.buffer) && (A = new DataView(n.memory.buffer)), A;
    }
    function p(e, a) {
        return e = e >>> 0, rt(e, a);
    }
    let D = null;
    function C() {
        return (D === null || D.byteLength === 0) && (D = new Uint8Array(n.memory.buffer)), D;
    }
    function N(e, a) {
        try {
            return e.apply(this, a);
        } catch (r) {
            const t = O(r);
            n.__wbindgen_exn_store(t);
        }
    }
    function g(e) {
        return e == null;
    }
    function et(e, a) {
        const r = a(e.length * 1, 1) >>> 0;
        return C().set(e, r / 1), l = e.length, r;
    }
    function H(e, a) {
        const r = a(e.length * 4, 4) >>> 0;
        for(let t = 0; t < e.length; t++){
            const _ = O(e[t]);
            z().setUint32(r + 4 * t, _, !0);
        }
        return l = e.length, r;
    }
    function s(e, a, r) {
        if (r === void 0) {
            const i = W.encode(e), b = a(i.length, 1) >>> 0;
            return C().subarray(b, b + i.length).set(i), l = i.length, b;
        }
        let t = e.length, _ = a(t, 1) >>> 0;
        const o = C();
        let c = 0;
        for(; c < t; c++){
            const i = e.charCodeAt(c);
            if (i > 127) break;
            o[_ + c] = i;
        }
        if (c !== t) {
            c !== 0 && (e = e.slice(c)), _ = r(_, t, t = c + e.length * 3, 1) >>> 0;
            const i = C().subarray(_ + c, _ + t), b = W.encodeInto(e, i);
            c += b.written, _ = r(_, t, c, 1) >>> 0;
        }
        return l = c, _;
    }
    function f(e) {
        const a = n.__wbindgen_externrefs.get(e);
        return n.__externref_table_dealloc(e), a;
    }
    let G = new TextDecoder("utf-8", {
        ignoreBOM: !0,
        fatal: !0
    });
    G.decode();
    const tt = 2146435072;
    let F = 0;
    function rt(e, a) {
        return F += a, F >= tt && (G = new TextDecoder("utf-8", {
            ignoreBOM: !0,
            fatal: !0
        }), G.decode(), F = a), G.decode(C().subarray(e, e + a));
    }
    const W = new TextEncoder;
    "encodeInto" in W || (W.encodeInto = function(e, a) {
        const r = W.encode(e);
        return a.set(r), {
            read: e.length,
            written: r.length
        };
    });
    let l = 0, n;
    function at(e) {
        n = e;
    }
    URL = globalThis.URL;
    const nt = await ve({
        "./vault_core_bg.js": {
            __wbg_getRandomValues_a1cf2e70b003a59d: Ie,
            __wbg_crypto_38df2bab126b63dc: We,
            __wbg_process_44c7a14e11e9f69e: Fe,
            __wbg_versions_276b2795b1c6a219: Xe,
            __wbg_node_84ea875411254db1: $e,
            __wbg_require_b4edbdcf3e2a1ef0: Je,
            __wbg_call_2d781c1f4d5c0ef8: Ue,
            __wbg_msCrypto_bd5a034af96bcba6: De,
            __wbg_randomFillSync_6c25eac9869eb53c: Ye,
            __wbg_getRandomValues_c44a50d8cfdaebeb: Ne,
            __wbg_length_ea16607d7b61445b: Me,
            __wbg_prototypesetcall_d62e5099504357e6: xe,
            __wbg_new_with_length_825018a1616e9e55: Pe,
            __wbg_subarray_a068d24e39478a8a: He,
            __wbg_new_0_1dcafdf5e786e876: Ge,
            __wbg_getTime_1dad7b5386ddd2d9: Be,
            __wbg_static_accessor_GLOBAL_THIS_ad356e0db91c7913: je,
            __wbg_static_accessor_SELF_f207c857566db248: ze,
            __wbg_static_accessor_GLOBAL_8adb955bd33fac2f: Ke,
            __wbg_static_accessor_WINDOW_bb9f1ba69d61b386: qe,
            __wbg___wbindgen_throw_6ddd609b62940d55: Oe,
            __wbg___wbindgen_is_object_781bc9f159099513: Ae,
            __wbg___wbindgen_is_string_7ef6b97b02428fae: Le,
            __wbg___wbindgen_string_get_395e606bd0ee4427: Ce,
            __wbg___wbindgen_is_function_3c846841762788c1: Ee,
            __wbg___wbindgen_is_undefined_52709e72fb9f179c: Ve,
            __wbindgen_init_externref_table: Re,
            __wbindgen_cast_0000000000000001: Qe,
            __wbindgen_cast_0000000000000002: Ze
        }
    }, me), { memory: _t, api_change_master_password: ct, api_create_entry: ot, api_create_label: it, api_create_new_vault: lt, api_delete_entry: st, api_delete_label: ut, api_generate_password: ft, api_generate_totp: dt, api_generate_totp_default: bt, api_get_entry: wt, api_get_vault_bytes: gt, api_list_entries: yt, api_list_labels: St, api_load_vault: pt, api_lock: ht, api_purge_entry: mt, api_regenerate_recovery_key: vt, api_rename_label: Tt, api_restore_entry: kt, api_rotate_dek: Et, api_set_entry_labels: At, api_set_favorite: Lt, api_unlock: Vt, api_unlock_with_recovery_key: Ct, api_update_entry: Ot, api_upgrade_argon2_params: Ut, __wbindgen_malloc: Wt, __wbindgen_realloc: It, __wbindgen_exn_store: Nt, __externref_table_alloc: Bt, __wbindgen_externrefs: Mt, __externref_table_dealloc: Dt, __wbindgen_free: Gt, __wbindgen_start: ge } = nt, Pt = Object.freeze(Object.defineProperty({
        __proto__: null,
        __externref_table_alloc: Bt,
        __externref_table_dealloc: Dt,
        __wbindgen_exn_store: Nt,
        __wbindgen_externrefs: Mt,
        __wbindgen_free: Gt,
        __wbindgen_malloc: Wt,
        __wbindgen_realloc: It,
        __wbindgen_start: ge,
        api_change_master_password: ct,
        api_create_entry: ot,
        api_create_label: it,
        api_create_new_vault: lt,
        api_delete_entry: st,
        api_delete_label: ut,
        api_generate_password: ft,
        api_generate_totp: dt,
        api_generate_totp_default: bt,
        api_get_entry: wt,
        api_get_vault_bytes: gt,
        api_list_entries: yt,
        api_list_labels: St,
        api_load_vault: pt,
        api_lock: ht,
        api_purge_entry: mt,
        api_regenerate_recovery_key: vt,
        api_rename_label: Tt,
        api_restore_entry: kt,
        api_rotate_dek: Et,
        api_set_entry_labels: At,
        api_set_favorite: Lt,
        api_unlock: Vt,
        api_unlock_with_recovery_key: Ct,
        api_update_entry: Ot,
        api_upgrade_argon2_params: Ut,
        memory: _t
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    at(Pt);
    ge();
    const $t = Object.freeze(Object.defineProperty({
        __proto__: null,
        api_change_master_password: x,
        api_create_entry: R,
        api_create_label: ee,
        api_create_new_vault: Y,
        api_delete_entry: te,
        api_delete_label: re,
        api_generate_password: ae,
        api_generate_totp: Te,
        api_generate_totp_default: ne,
        api_get_entry: _e,
        api_get_vault_bytes: V,
        api_list_entries: J,
        api_list_labels: ce,
        api_load_vault: K,
        api_lock: q,
        api_purge_entry: oe,
        api_regenerate_recovery_key: ie,
        api_rename_label: le,
        api_restore_entry: se,
        api_rotate_dek: ue,
        api_set_entry_labels: fe,
        api_set_favorite: de,
        api_unlock: j,
        api_unlock_with_recovery_key: be,
        api_update_entry: we,
        api_upgrade_argon2_params: ke
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    let Q = !1, u = !1;
    async function X() {
        if (!Q) try {
            Q = !0, console.log("[SW] WASM initialized");
        } catch (e) {
            throw console.error("[SW] WASM initialization error:", e), e;
        }
    }
    function Ft() {
        console.log("[SW] Setting up message handlers"), chrome.runtime.onMessage.addListener((e, a, r)=>(console.log("[SW] Message received:", e.type), xt(e, a, r).catch((t)=>{
                console.error("[SW] Unhandled error in message handler:", t);
                try {
                    r({
                        success: !1,
                        error: String(t)
                    });
                } catch (_) {
                    console.error("[SW] Failed to send error response:", _);
                }
            }), !0));
    }
    console.log("[SW] Registering message handlers immediately on script load");
    Ft();
    self.addEventListener("install", (e)=>{
        console.log("[SW] install event"), e.waitUntil(X());
    });
    self.addEventListener("activate", (e)=>{
        console.log("[SW] activate event"), e.waitUntil(X().then(()=>{
            console.log("[SW] Calling setupAlarms in activate"), Yt();
        }));
    });
    function ye(e) {
        return e && {
            id: e.id,
            entryType: e.entry_type,
            name: e.name,
            isFavorite: e.is_favorite ?? !1,
            updatedAt: e.updated_at ?? 0,
            deletedAt: e.deleted_at ?? null,
            notes: e.notes ?? null,
            typedValue: e.typed_value ?? {},
            labels: e.label_ids ?? [],
            customFields: (e.custom_fields ?? []).map((a)=>({
                    id: a.id,
                    name: a.name,
                    fieldType: a.field_type,
                    value: a.value
                }))
        };
    }
    function Z(e) {
        return (e ?? []).map(ye);
    }
    async function y() {
        try {
            const e = V();
            await S(d.VAULT_BYTES, Array.from(e));
            const a = await v(d.S3_CONFIG);
            if (a) try {
                await (void 0)(JSON.stringify(a)), await S(d.LAST_SYNC_TIME, new Date().toISOString()), console.log("[SW] Auto-push successful");
            } catch (r) {
                console.warn("[SW] Auto-push failed:", r);
            }
        } catch (e) {
            console.error("[SW] autoSaveAndPush failed:", e);
        }
    }
    async function L() {
        return await v(d.APP_SETTINGS) || {
            autolockMinutes: 5,
            clipboardClearSeconds: 30,
            clipboardAutoClean: !0,
            theme: "light"
        };
    }
    async function xt(e, a, r) {
        try {
            switch(await X(), e.type){
                case "IS_UNLOCKED":
                    {
                        r({
                            success: !0,
                            unlocked: u
                        });
                        break;
                    }
                case "UNLOCK":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await v(d.VAULT_BYTES), _ = await v(d.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            K(new Uint8Array(t), _ || ""), j(e.password), u = !0;
                            const o = await L();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: o.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UNLOCK_EXISTING":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await v(d.VAULT_BYTES), _ = await v(d.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            K(new Uint8Array(t), _ || ""), j(e.password), u = !0;
                            const o = await L();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: o.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LOCK":
                    {
                        try {
                            const t = q();
                            await S(d.VAULT_BYTES, Array.from(t)), u = !1, chrome.alarms.clear("autolock"), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_VAULT":
                    {
                        if (!e.masterPassword) {
                            r({
                                success: !1,
                                error: "Master password required"
                            });
                            break;
                        }
                        try {
                            console.log("[SW] CREATE_VAULT: Starting vault creation"), console.log("[SW] CREATE_VAULT: vault object type:", typeof $t), console.log("[SW] CREATE_VAULT: vault.api_create_new_vault:", typeof Y);
                            const t = Y(e.masterPassword);
                            console.log("[SW] CREATE_VAULT: Vault created, recovery key:", t);
                            const _ = V();
                            console.log("[SW] CREATE_VAULT: Got vault bytes, size:", _?.length), await S(d.VAULT_BYTES, Array.from(_)), await S(d.VAULT_ETAG, null), console.log("[SW] CREATE_VAULT: Saved vault bytes to storage"), e.s3Config && await S(d.S3_CONFIG, e.s3Config), u = !0;
                            const o = await L();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: o.autolockMinutes
                            }), console.log("[SW] CREATE_VAULT: Success, sending response");
                            const c = {
                                success: !0,
                                recoveryKey: t
                            };
                            console.log("[SW] CREATE_VAULT: Response payload:", c), r(c), console.log("[SW] CREATE_VAULT: sendResponse called");
                        } catch (t) {
                            console.error("[SW] CREATE_VAULT: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RECOVER":
                    {
                        if (!e.recoveryKey || !e.newPassword) {
                            r({
                                success: !1,
                                error: "Recovery key and password required"
                            });
                            break;
                        }
                        try {
                            be(e.recoveryKey), x(e.recoveryKey, e.newPassword);
                            const t = V();
                            await S(d.VAULT_BYTES, Array.from(t)), await S(d.VAULT_ETAG, null), await y(), u = !0;
                            const _ = await L();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: _.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_ENTRIES":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = e.filter || {}, _ = J(t.searchQuery || null, t.type || null, t.labelId || null, t.includeTrash || !1, t.onlyFavorites || !1), o = JSON.parse(_), c = Z(o);
                            r({
                                success: !0,
                                entries: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = _e(e.id), _ = JSON.parse(t);
                            _ && _.typed_value && typeof _.typed_value == "string" && (_.typed_value = JSON.parse(_.typed_value));
                            const o = ye(_);
                            r({
                                success: !0,
                                entry: o
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = R(e.entryType, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null);
                            await y(), r({
                                success: !0,
                                entryId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UPDATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            we(e.id, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            te(e.id), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RESTORE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            se(e.id), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PURGE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            oe(e.id), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_FAVORITE":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            de(e.id, e.isFavorite), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_TRASH":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = J(null, null, null, !0, !1), _ = JSON.parse(t), o = Z(_);
                            r({
                                success: !0,
                                entries: o
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ce(), _ = JSON.parse(t);
                            r({
                                success: !0,
                                labels: _
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ee(e.name);
                            await y(), r({
                                success: !0,
                                labelId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            re(e.id), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RENAME_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            le(e.id, e.newName), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_ENTRY_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            fe(e.entryId, e.labelIds || []), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_PASSWORD":
                    {
                        try {
                            const t = ae(e.length ?? 16, e.includeUppercase ?? !0, e.includeLowercase ?? !0, e.includeNumbers ?? !0, e.includeSymbols ?? !0);
                            r({
                                success: !0,
                                password: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_TOTP":
                    {
                        try {
                            const t = ne(e.secret);
                            r({
                                success: !0,
                                totp: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CHANGE_MASTER_PASSWORD":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            x(e.oldPassword, e.newPassword), await y(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "ROTATE_DEK":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ue(e.password);
                            await y(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "REGENERATE_RECOVERY_KEY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ie(e.password);
                            await y(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DOWNLOAD_VAULT":
                    {
                        try {
                            const t = await v(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            const _ = await (void 0)(JSON.stringify(t)), o = V();
                            await S(d.VAULT_BYTES, Array.from(o)), r({
                                success: !0,
                                vaultExists: _
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PUSH_VAULT":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = await v(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            await (void 0)(JSON.stringify(t)), await S(d.LAST_SYNC_TIME, new Date().toISOString()), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SYNC":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = await v(d.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !0,
                                    status: "idle",
                                    message: "S3 config not set"
                                });
                                break;
                            }
                            await (void 0)(JSON.stringify(t));
                            const _ = V();
                            await S(d.VAULT_BYTES, Array.from(_)), await S(d.LAST_SYNC_TIME, new Date().toISOString()), r({
                                success: !0,
                                status: "synced"
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_SETTINGS":
                    {
                        const t = await L();
                        r({
                            success: !0,
                            settings: t
                        });
                        break;
                    }
                case "SAVE_SETTINGS":
                    {
                        try {
                            await S(d.APP_SETTINGS, e.settings), u && chrome.alarms.create("autolock", {
                                delayInMinutes: e.settings.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CLIPBOARD_COPIED":
                    {
                        try {
                            const t = await L();
                            if (t.clipboardAutoClean) {
                                const _ = t.clipboardClearSeconds / 60;
                                chrome.alarms.create("clipboard-clear", {
                                    delayInMinutes: _
                                });
                            }
                            r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                default:
                    r({
                        success: !1,
                        error: "Unknown message type"
                    });
            }
        } catch (t) {
            console.error("[SW] Message handling error:", t), r({
                success: !1,
                error: String(t)
            });
        }
    }
    function Yt() {
        chrome.alarms.onAlarm.addListener((e)=>{
            e.name === "autolock" ? Jt() : e.name === "clipboard-clear" && Kt();
        });
    }
    async function Jt() {
        if (console.log("[SW] Autolock alarm triggered"), !!u) try {
            const e = q();
            await S(d.VAULT_BYTES, Array.from(e)), u = !1, console.log("[SW] Vault locked");
        } catch (e) {
            console.error("[SW] Autolock failed:", e);
        }
    }
    async function Kt() {
        console.log("[SW] Clipboard clear alarm triggered");
        try {
            typeof chrome.offscreen < "u" ? (await chrome.offscreen.createDocument({
                url: chrome.runtime.getURL("src/background/offscreen.html"),
                reasons: [
                    "CLIPBOARD"
                ],
                justification: "Clear clipboard after copy timeout"
            }), chrome.runtime.sendMessage({
                type: "CLEAR_CLIPBOARD"
            })) : await navigator.clipboard.writeText("");
        } catch (e) {
            console.error("[SW] Clipboard clear failed:", e);
        }
    }
})();
