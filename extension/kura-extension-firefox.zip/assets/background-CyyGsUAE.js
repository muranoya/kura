import { g as h, S as f, s as y } from "./constants-lfyc1fqw.js";
(async ()=>{
    const We = "/assets/vault_core_bg-fyB_cgOF.wasm", Le = async (e = {}, n)=>{
        let r;
        if (n.startsWith("data:")) {
            const t = n.replace(/^data:.*?base64,/, "");
            let _;
            if (typeof Buffer == "function" && typeof Buffer.from == "function") _ = Buffer.from(t, "base64");
            else if (typeof atob == "function") {
                const c = atob(t);
                _ = new Uint8Array(c.length);
                for(let o = 0; o < c.length; o++)_[o] = c.charCodeAt(o);
            } else throw new Error("Cannot decode base64-encoded data URL");
            r = await WebAssembly.instantiate(_, e);
        } else {
            const t = await fetch(n), _ = t.headers.get("Content-Type") || "";
            if ("instantiateStreaming" in WebAssembly && _.startsWith("application/wasm")) r = await WebAssembly.instantiateStreaming(t, e);
            else {
                const c = await t.arrayBuffer();
                r = await WebAssembly.instantiate(c, e);
            }
        }
        return r.instance.exports;
    };
    function z(e, n) {
        const r = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), t = l, _ = s(n, a.__wbindgen_malloc, a.__wbindgen_realloc), c = l, o = a.api_change_master_password(r, t, _, c);
        if (o[1]) throw d(o[0]);
    }
    function ae(e, n, r, t, _, c) {
        let o, i;
        try {
            const W = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), k = l, q = s(n, a.__wbindgen_malloc, a.__wbindgen_realloc), j = l;
            var g = S(r) ? 0 : s(r, a.__wbindgen_malloc, a.__wbindgen_realloc), w = l;
            const B = s(t, a.__wbindgen_malloc, a.__wbindgen_realloc), Te = l, ke = ee(_, a.__wbindgen_malloc), Ee = l;
            var m = S(c) ? 0 : s(c, a.__wbindgen_malloc, a.__wbindgen_realloc), D = l;
            const P = a.api_create_entry(W, k, q, j, g, w, B, Te, ke, Ee, m, D);
            var E = P[0], A = P[1];
            if (P[3]) throw E = 0, A = 0, d(P[2]);
            return o = E, i = A, b(E, A);
        } finally{
            a.__wbindgen_free(o, i, 1);
        }
    }
    function ce(e) {
        let n, r;
        try {
            const c = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l, i = a.api_create_label(c, o);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, d(i[2]);
            return n = t, r = _, b(t, _);
        } finally{
            a.__wbindgen_free(n, r, 1);
        }
    }
    function H(e) {
        let n, r;
        try {
            const c = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l, i = a.api_create_new_vault(c, o);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, d(i[2]);
            return n = t, r = _, b(t, _);
        } finally{
            a.__wbindgen_free(n, r, 1);
        }
    }
    function oe(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l, t = a.api_delete_entry(n, r);
        if (t[1]) throw d(t[0]);
    }
    function ie(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l, t = a.api_delete_label(n, r);
        if (t[1]) throw d(t[0]);
    }
    function Y(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l;
        return a.api_download(n, r);
    }
    function le(e, n, r, t, _) {
        let c, o;
        try {
            const w = a.api_generate_password(e, n, r, t, _);
            var i = w[0], g = w[1];
            if (w[3]) throw i = 0, g = 0, d(w[2]);
            return c = i, o = g, b(i, g);
        } finally{
            a.__wbindgen_free(c, o, 1);
        }
    }
    function Oe(e, n, r) {
        let t, _;
        try {
            const i = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), g = l, w = a.api_generate_totp(i, g, n, r);
            var c = w[0], o = w[1];
            if (w[3]) throw c = 0, o = 0, d(w[2]);
            return t = c, _ = o, b(c, o);
        } finally{
            a.__wbindgen_free(t, _, 1);
        }
    }
    function se(e) {
        let n, r;
        try {
            const c = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l, i = a.api_generate_totp_default(c, o);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, d(i[2]);
            return n = t, r = _, b(t, _);
        } finally{
            a.__wbindgen_free(n, r, 1);
        }
    }
    function ue(e) {
        let n, r;
        try {
            const c = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l, i = a.api_get_entry(c, o);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, d(i[2]);
            return n = t, r = _, b(t, _);
        } finally{
            a.__wbindgen_free(n, r, 1);
        }
    }
    function V() {
        const e = a.api_get_vault_bytes();
        if (e[3]) throw d(e[2]);
        var n = I(e[0], e[1]).slice();
        return a.__wbindgen_free(e[0], e[1] * 1, 1), n;
    }
    function J() {
        const e = a.api_get_vault_etag();
        let n;
        return e[0] !== 0 && (n = b(e[0], e[1]).slice(), a.__wbindgen_free(e[0], e[1] * 1, 1)), n;
    }
    function X(e, n, r, t, _) {
        let c, o;
        try {
            var i = S(e) ? 0 : s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), g = l, w = S(n) ? 0 : s(n, a.__wbindgen_malloc, a.__wbindgen_realloc), m = l, D = S(r) ? 0 : s(r, a.__wbindgen_malloc, a.__wbindgen_realloc), E = l;
            const k = a.api_list_entries(i, g, w, m, D, E, t, _);
            var A = k[0], W = k[1];
            if (k[3]) throw A = 0, W = 0, d(k[2]);
            return c = A, o = W, b(A, W);
        } finally{
            a.__wbindgen_free(c, o, 1);
        }
    }
    function fe() {
        let e, n;
        try {
            const _ = a.api_list_labels();
            var r = _[0], t = _[1];
            if (_[3]) throw r = 0, t = 0, d(_[2]);
            return e = r, n = t, b(r, t);
        } finally{
            a.__wbindgen_free(e, n, 1);
        }
    }
    function G(e, n) {
        const r = Mt(e, a.__wbindgen_malloc), t = l, _ = s(n, a.__wbindgen_malloc, a.__wbindgen_realloc), c = l, o = a.api_load_vault(r, t, _, c);
        if (o[1]) throw d(o[0]);
    }
    function R() {
        const e = a.api_lock();
        if (e[3]) throw d(e[2]);
        var n = I(e[0], e[1]).slice();
        return a.__wbindgen_free(e[0], e[1] * 1, 1), n;
    }
    function de(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l, t = a.api_purge_entry(n, r);
        if (t[1]) throw d(t[0]);
    }
    function T(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l;
        return a.api_push(n, r);
    }
    function be(e) {
        let n, r;
        try {
            const c = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l, i = a.api_regenerate_recovery_key(c, o);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, d(i[2]);
            return n = t, r = _, b(t, _);
        } finally{
            a.__wbindgen_free(n, r, 1);
        }
    }
    function ge(e, n) {
        const r = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), t = l, _ = s(n, a.__wbindgen_malloc, a.__wbindgen_realloc), c = l, o = a.api_rename_label(r, t, _, c);
        if (o[1]) throw d(o[0]);
    }
    function we(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l, t = a.api_restore_entry(n, r);
        if (t[1]) throw d(t[0]);
    }
    function ye(e) {
        let n, r;
        try {
            const c = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l, i = a.api_rotate_dek(c, o);
            var t = i[0], _ = i[1];
            if (i[3]) throw t = 0, _ = 0, d(i[2]);
            return n = t, r = _, b(t, _);
        } finally{
            a.__wbindgen_free(n, r, 1);
        }
    }
    function Se(e, n) {
        const r = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), t = l, _ = ee(n, a.__wbindgen_malloc), c = l, o = a.api_set_entry_labels(r, t, _, c);
        if (o[1]) throw d(o[0]);
    }
    function pe(e, n) {
        const r = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), t = l, _ = a.api_set_favorite(r, t, n);
        if (_[1]) throw d(_[0]);
    }
    function F(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l;
        return a.api_sync(n, r);
    }
    function Q(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l, t = a.api_unlock(n, r);
        if (t[1]) throw d(t[0]);
    }
    function he(e) {
        const n = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), r = l, t = a.api_unlock_with_recovery_key(n, r);
        if (t[1]) throw d(t[0]);
    }
    function me(e, n, r, t, _, c) {
        const o = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), i = l;
        var g = S(n) ? 0 : s(n, a.__wbindgen_malloc, a.__wbindgen_realloc), w = l, m = S(r) ? 0 : s(r, a.__wbindgen_malloc, a.__wbindgen_realloc), D = l, E = S(t) ? 0 : s(t, a.__wbindgen_malloc, a.__wbindgen_realloc), A = l, W = S(_) ? 0 : ee(_, a.__wbindgen_malloc), k = l, q = S(c) ? 0 : s(c, a.__wbindgen_malloc, a.__wbindgen_realloc), j = l;
        const B = a.api_update_entry(o, i, g, w, m, D, E, A, W, k, q, j);
        if (B[1]) throw d(B[0]);
    }
    function Ce(e, n, r, t) {
        let _, c;
        try {
            const g = s(e, a.__wbindgen_malloc, a.__wbindgen_realloc), w = l, m = a.api_upgrade_argon2_params(g, w, n, r, t);
            var o = m[0], i = m[1];
            if (m[3]) throw o = 0, i = 0, d(m[2]);
            return _ = o, c = i, b(o, i);
        } finally{
            a.__wbindgen_free(_, c, 1);
        }
    }
    function Ve(e, n) {
        const r = Z(n), t = s(r, a.__wbindgen_malloc, a.__wbindgen_realloc), _ = l;
        L().setInt32(e + 4 * 1, _, !0), L().setInt32(e + 4 * 0, t, !0);
    }
    function Ne(e) {
        return typeof e == "function";
    }
    function Ue(e) {
        const n = e;
        return typeof n == "object" && n !== null;
    }
    function Ie(e) {
        return typeof e == "string";
    }
    function De(e) {
        return e === void 0;
    }
    function Me(e, n) {
        const r = n, t = typeof r == "string" ? r : void 0;
        var _ = S(t) ? 0 : s(t, a.__wbindgen_malloc, a.__wbindgen_realloc), c = l;
        L().setInt32(e + 4 * 1, c, !0), L().setInt32(e + 4 * 0, _, !0);
    }
    function Be(e, n) {
        throw new Error(b(e, n));
    }
    function Pe(e) {
        e._wbg_cb_unref();
    }
    function $e() {
        return v(function(e) {
            return e.arrayBuffer();
        }, arguments);
    }
    function Ye() {
        return v(function(e, n, r) {
            return e.call(n, r);
        }, arguments);
    }
    function Ge(e) {
        return e.crypto;
    }
    function Fe(e, n) {
        return e.fetch(n);
    }
    function xe() {
        return v(function(e, n) {
            globalThis.crypto.getRandomValues(I(e, n));
        }, arguments);
    }
    function Je() {
        return v(function(e, n) {
            e.getRandomValues(n);
        }, arguments);
    }
    function qe(e) {
        return e.getTime();
    }
    function je() {
        return v(function(e, n, r, t) {
            const _ = n.get(b(r, t));
            var c = S(_) ? 0 : s(_, a.__wbindgen_malloc, a.__wbindgen_realloc), o = l;
            L().setInt32(e + 4 * 1, o, !0), L().setInt32(e + 4 * 0, c, !0);
        }, arguments);
    }
    function Ke(e) {
        return e.headers;
    }
    function ze(e) {
        let n;
        try {
            n = e instanceof Response;
        } catch  {
            n = !1;
        }
        return n;
    }
    function He(e) {
        let n;
        try {
            n = e instanceof Window;
        } catch  {
            n = !1;
        }
        return n;
    }
    function Xe(e) {
        return e.length;
    }
    function Qe(e) {
        return e.msCrypto;
    }
    function Ze() {
        return v(function() {
            return new Headers;
        }, arguments);
    }
    function Re() {
        return new Date;
    }
    function et(e) {
        return new Uint8Array(e);
    }
    function tt() {
        return new Object;
    }
    function rt(e, n) {
        return new Uint8Array(I(e, n));
    }
    function nt(e, n) {
        try {
            var r = {
                a: e,
                b: n
            }, t = (c, o)=>{
                const i = r.a;
                r.a = 0;
                try {
                    return Ut(i, r.b, c, o);
                } finally{
                    r.a = i;
                }
            };
            return new Promise(t);
        } finally{
            r.a = r.b = 0;
        }
    }
    function _t(e) {
        return new Uint8Array(e >>> 0);
    }
    function at() {
        return v(function(e, n, r) {
            return new Request(b(e, n), r);
        }, arguments);
    }
    function ct(e) {
        return e.node;
    }
    function ot(e) {
        return e.process;
    }
    function it(e, n, r) {
        Uint8Array.prototype.set.call(I(e, n), r);
    }
    function lt(e) {
        return e.queueMicrotask;
    }
    function st(e) {
        queueMicrotask(e);
    }
    function ut() {
        return v(function(e, n) {
            e.randomFillSync(n);
        }, arguments);
    }
    function ft() {
        return v(function() {
            return module.require;
        }, arguments);
    }
    function dt(e) {
        return Promise.resolve(e);
    }
    function bt(e, n) {
        e.body = n;
    }
    function gt() {
        return v(function(e, n, r, t, _) {
            e.set(b(n, r), b(t, _));
        }, arguments);
    }
    function wt(e, n) {
        e.headers = n;
    }
    function yt(e, n, r) {
        e.method = b(n, r);
    }
    function St(e, n) {
        e.mode = It[n];
    }
    function pt() {
        const e = typeof global > "u" ? null : global;
        return S(e) ? 0 : U(e);
    }
    function ht() {
        const e = typeof globalThis > "u" ? null : globalThis;
        return S(e) ? 0 : U(e);
    }
    function mt() {
        const e = typeof self > "u" ? null : self;
        return S(e) ? 0 : U(e);
    }
    function vt() {
        const e = typeof window > "u" ? null : window;
        return S(e) ? 0 : U(e);
    }
    function At(e) {
        return e.status;
    }
    function Tt(e, n, r) {
        return e.subarray(n >>> 0, r >>> 0);
    }
    function kt(e, n) {
        return e.then(n);
    }
    function Et(e, n, r) {
        return e.then(n, r);
    }
    function Wt(e) {
        return e.versions;
    }
    function Lt(e, n) {
        return Dt(e, n, a.wasm_bindgen__closure__destroy__h3f8964959a1d4cde, Nt);
    }
    function Ot(e, n) {
        return I(e, n);
    }
    function Ct(e, n) {
        return b(e, n);
    }
    function Vt() {
        const e = a.__wbindgen_externrefs, n = e.grow(4);
        e.set(0, void 0), e.set(n + 0, void 0), e.set(n + 1, null), e.set(n + 2, !0), e.set(n + 3, !1);
    }
    function Nt(e, n, r) {
        const t = a.wasm_bindgen__convert__closures_____invoke__hb920389fa6ed5e03(e, n, r);
        if (t[1]) throw d(t[0]);
    }
    function Ut(e, n, r, t) {
        a.wasm_bindgen__convert__closures_____invoke__h40d0a0a79b0a349e(e, n, r, t);
    }
    const It = [
        "same-origin",
        "no-cors",
        "cors",
        "navigate"
    ];
    function U(e) {
        const n = a.__externref_table_alloc();
        return a.__wbindgen_externrefs.set(n, e), n;
    }
    const re = typeof FinalizationRegistry > "u" ? {
        register: ()=>{},
        unregister: ()=>{}
    } : new FinalizationRegistry((e)=>e.dtor(e.a, e.b));
    function Z(e) {
        const n = typeof e;
        if (n == "number" || n == "boolean" || e == null) return `${e}`;
        if (n == "string") return `"${e}"`;
        if (n == "symbol") {
            const _ = e.description;
            return _ == null ? "Symbol" : `Symbol(${_})`;
        }
        if (n == "function") {
            const _ = e.name;
            return typeof _ == "string" && _.length > 0 ? `Function(${_})` : "Function";
        }
        if (Array.isArray(e)) {
            const _ = e.length;
            let c = "[";
            _ > 0 && (c += Z(e[0]));
            for(let o = 1; o < _; o++)c += ", " + Z(e[o]);
            return c += "]", c;
        }
        const r = /\[object ([^\]]+)\]/.exec(toString.call(e));
        let t;
        if (r && r.length > 1) t = r[1];
        else return toString.call(e);
        if (t == "Object") try {
            return "Object(" + JSON.stringify(e) + ")";
        } catch  {
            return "Object";
        }
        return e instanceof Error ? `${e.name}: ${e.message}
${e.stack}` : t;
    }
    function I(e, n) {
        return e = e >>> 0, N().subarray(e / 1, e / 1 + n);
    }
    let O = null;
    function L() {
        return (O === null || O.buffer.detached === !0 || O.buffer.detached === void 0 && O.buffer !== a.memory.buffer) && (O = new DataView(a.memory.buffer)), O;
    }
    function b(e, n) {
        return e = e >>> 0, Pt(e, n);
    }
    let $ = null;
    function N() {
        return ($ === null || $.byteLength === 0) && ($ = new Uint8Array(a.memory.buffer)), $;
    }
    function v(e, n) {
        try {
            return e.apply(this, n);
        } catch (r) {
            const t = U(r);
            a.__wbindgen_exn_store(t);
        }
    }
    function S(e) {
        return e == null;
    }
    function Dt(e, n, r, t) {
        const _ = {
            a: e,
            b: n,
            cnt: 1,
            dtor: r
        }, c = (...o)=>{
            _.cnt++;
            const i = _.a;
            _.a = 0;
            try {
                return t(i, _.b, ...o);
            } finally{
                _.a = i, c._wbg_cb_unref();
            }
        };
        return c._wbg_cb_unref = ()=>{
            --_.cnt === 0 && (_.dtor(_.a, _.b), _.a = 0, re.unregister(_));
        }, re.register(c, _, _), c;
    }
    function Mt(e, n) {
        const r = n(e.length * 1, 1) >>> 0;
        return N().set(e, r / 1), l = e.length, r;
    }
    function ee(e, n) {
        const r = n(e.length * 4, 4) >>> 0;
        for(let t = 0; t < e.length; t++){
            const _ = U(e[t]);
            L().setUint32(r + 4 * t, _, !0);
        }
        return l = e.length, r;
    }
    function s(e, n, r) {
        if (r === void 0) {
            const i = M.encode(e), g = n(i.length, 1) >>> 0;
            return N().subarray(g, g + i.length).set(i), l = i.length, g;
        }
        let t = e.length, _ = n(t, 1) >>> 0;
        const c = N();
        let o = 0;
        for(; o < t; o++){
            const i = e.charCodeAt(o);
            if (i > 127) break;
            c[_ + o] = i;
        }
        if (o !== t) {
            o !== 0 && (e = e.slice(o)), _ = r(_, t, t = o + e.length * 3, 1) >>> 0;
            const i = N().subarray(_ + o, _ + t), g = M.encodeInto(e, i);
            o += g.written, _ = r(_, t, o, 1) >>> 0;
        }
        return l = o, _;
    }
    function d(e) {
        const n = a.__wbindgen_externrefs.get(e);
        return a.__externref_table_dealloc(e), n;
    }
    let x = new TextDecoder("utf-8", {
        ignoreBOM: !0,
        fatal: !0
    });
    x.decode();
    const Bt = 2146435072;
    let K = 0;
    function Pt(e, n) {
        return K += n, K >= Bt && (x = new TextDecoder("utf-8", {
            ignoreBOM: !0,
            fatal: !0
        }), x.decode(), K = n), x.decode(N().subarray(e, e + n));
    }
    const M = new TextEncoder;
    "encodeInto" in M || (M.encodeInto = function(e, n) {
        const r = M.encode(e);
        return n.set(r), {
            read: e.length,
            written: r.length
        };
    });
    let l = 0, a;
    function $t(e) {
        a = e;
    }
    URL = globalThis.URL;
    const Yt = await Le({
        "./vault_core_bg.js": {
            __wbg_new_typed_aaaeaf29cf802876: nt,
            __wbg_then_9e335f6dd892bc11: Et,
            __wbg_call_2d781c1f4d5c0ef8: Ye,
            __wbg_then_098abe61755d12f6: kt,
            __wbg_queueMicrotask_a082d78ce798393e: st,
            __wbg_queueMicrotask_0c399741342fb10f: lt,
            __wbg_resolve_ae8d83246e5bcc12: dt,
            __wbg_instanceof_Window_23e677d2c6843922: He,
            __wbg_fetch_f8a611684c3b5fe5: Fe,
            __wbg_get_a867a94064ecd263: je,
            __wbg_new_0837727332ac86ba: Ze,
            __wbg_set_e09648bea3f1af1e: gt,
            __wbg_instanceof_Response_9b4d9fd451e051b1: ze,
            __wbg_arrayBuffer_eb8e9ca620af2a19: $e,
            __wbg_status_318629ab93a22955: At,
            __wbg_headers_eb2234545f9ff993: Ke,
            __wbg_set_method_8c015e8bcafd7be1: yt,
            __wbg_set_headers_3c8fecc693b75327: wt,
            __wbg_set_body_a3d856b097dfda04: bt,
            __wbg_set_mode_5a87f2c809cf37c2: St,
            __wbg_new_with_str_and_init_b4b54d1a819bc724: at,
            __wbg_getRandomValues_a1cf2e70b003a59d: xe,
            __wbg_crypto_38df2bab126b63dc: Ge,
            __wbg_process_44c7a14e11e9f69e: ot,
            __wbg_versions_276b2795b1c6a219: Wt,
            __wbg_node_84ea875411254db1: ct,
            __wbg_require_b4edbdcf3e2a1ef0: ft,
            __wbg_msCrypto_bd5a034af96bcba6: Qe,
            __wbg_randomFillSync_6c25eac9869eb53c: ut,
            __wbg_getRandomValues_c44a50d8cfdaebeb: Je,
            __wbg_new_ab79df5bd7c26067: tt,
            __wbg_new_5f486cdf45a04d78: et,
            __wbg_length_ea16607d7b61445b: Xe,
            __wbg_prototypesetcall_d62e5099504357e6: it,
            __wbg_new_from_slice_22da9388ac046e50: rt,
            __wbg_new_with_length_825018a1616e9e55: _t,
            __wbg_subarray_a068d24e39478a8a: Tt,
            __wbg_new_0_1dcafdf5e786e876: Re,
            __wbg_getTime_1dad7b5386ddd2d9: qe,
            __wbg_static_accessor_GLOBAL_THIS_ad356e0db91c7913: ht,
            __wbg_static_accessor_SELF_f207c857566db248: mt,
            __wbg_static_accessor_GLOBAL_8adb955bd33fac2f: pt,
            __wbg_static_accessor_WINDOW_bb9f1ba69d61b386: vt,
            __wbg___wbindgen_throw_6ddd609b62940d55: Be,
            __wbg___wbindgen_is_object_781bc9f159099513: Ue,
            __wbg___wbindgen_is_string_7ef6b97b02428fae: Ie,
            __wbg___wbindgen_string_get_395e606bd0ee4427: Me,
            __wbg___wbindgen_is_function_3c846841762788c1: Ne,
            __wbg___wbindgen_is_undefined_52709e72fb9f179c: De,
            __wbg___wbindgen_debug_string_5398f5bb970e0daa: Ve,
            __wbg__wbg_cb_unref_6b5b6b8576d35cb1: Pe,
            __wbindgen_init_externref_table: Vt,
            __wbindgen_cast_0000000000000001: Lt,
            __wbindgen_cast_0000000000000002: Ot,
            __wbindgen_cast_0000000000000003: Ct
        }
    }, We), { memory: Gt, api_change_master_password: Ft, api_create_entry: xt, api_create_label: Jt, api_create_new_vault: qt, api_delete_entry: jt, api_delete_label: Kt, api_download: zt, api_generate_password: Ht, api_generate_totp: Xt, api_generate_totp_default: Qt, api_get_entry: Zt, api_get_vault_bytes: Rt, api_get_vault_etag: er, api_list_entries: tr, api_list_labels: rr, api_load_vault: nr, api_lock: _r, api_purge_entry: ar, api_push: cr, api_regenerate_recovery_key: or, api_rename_label: ir, api_restore_entry: lr, api_rotate_dek: sr, api_set_entry_labels: ur, api_set_favorite: fr, api_sync: dr, api_unlock: br, api_unlock_with_recovery_key: gr, api_update_entry: wr, api_upgrade_argon2_params: yr, wasm_bindgen__closure__destroy__h3f8964959a1d4cde: Sr, wasm_bindgen__convert__closures_____invoke__hb920389fa6ed5e03: pr, wasm_bindgen__convert__closures_____invoke__h40d0a0a79b0a349e: hr, __wbindgen_malloc: mr, __wbindgen_realloc: vr, __wbindgen_exn_store: Ar, __externref_table_alloc: Tr, __wbindgen_externrefs: kr, __externref_table_dealloc: Er, __wbindgen_free: Wr, __wbindgen_start: ve } = Yt, Lr = Object.freeze(Object.defineProperty({
        __proto__: null,
        __externref_table_alloc: Tr,
        __externref_table_dealloc: Er,
        __wbindgen_exn_store: Ar,
        __wbindgen_externrefs: kr,
        __wbindgen_free: Wr,
        __wbindgen_malloc: mr,
        __wbindgen_realloc: vr,
        __wbindgen_start: ve,
        api_change_master_password: Ft,
        api_create_entry: xt,
        api_create_label: Jt,
        api_create_new_vault: qt,
        api_delete_entry: jt,
        api_delete_label: Kt,
        api_download: zt,
        api_generate_password: Ht,
        api_generate_totp: Xt,
        api_generate_totp_default: Qt,
        api_get_entry: Zt,
        api_get_vault_bytes: Rt,
        api_get_vault_etag: er,
        api_list_entries: tr,
        api_list_labels: rr,
        api_load_vault: nr,
        api_lock: _r,
        api_purge_entry: ar,
        api_push: cr,
        api_regenerate_recovery_key: or,
        api_rename_label: ir,
        api_restore_entry: lr,
        api_rotate_dek: sr,
        api_set_entry_labels: ur,
        api_set_favorite: fr,
        api_sync: dr,
        api_unlock: br,
        api_unlock_with_recovery_key: gr,
        api_update_entry: wr,
        api_upgrade_argon2_params: yr,
        memory: Gt,
        wasm_bindgen__closure__destroy__h3f8964959a1d4cde: Sr,
        wasm_bindgen__convert__closures_____invoke__h40d0a0a79b0a349e: hr,
        wasm_bindgen__convert__closures_____invoke__hb920389fa6ed5e03: pr
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    $t(Lr);
    ve();
    const Or = Object.freeze(Object.defineProperty({
        __proto__: null,
        api_change_master_password: z,
        api_create_entry: ae,
        api_create_label: ce,
        api_create_new_vault: H,
        api_delete_entry: oe,
        api_delete_label: ie,
        api_download: Y,
        api_generate_password: le,
        api_generate_totp: Oe,
        api_generate_totp_default: se,
        api_get_entry: ue,
        api_get_vault_bytes: V,
        api_get_vault_etag: J,
        api_list_entries: X,
        api_list_labels: fe,
        api_load_vault: G,
        api_lock: R,
        api_purge_entry: de,
        api_push: T,
        api_regenerate_recovery_key: be,
        api_rename_label: ge,
        api_restore_entry: we,
        api_rotate_dek: ye,
        api_set_entry_labels: Se,
        api_set_favorite: pe,
        api_sync: F,
        api_unlock: Q,
        api_unlock_with_recovery_key: he,
        api_update_entry: me,
        api_upgrade_argon2_params: Ce
    }, Symbol.toStringTag, {
        value: "Module"
    }));
    let ne = !1, u = !1;
    async function te() {
        if (!ne) try {
            ne = !0, console.log("[SW] WASM initialized");
        } catch (e) {
            throw console.error("[SW] WASM initialization error:", e), e;
        }
    }
    function Cr() {
        console.log("[SW] Setting up message handlers"), chrome.runtime.onMessage.addListener((e, n, r)=>(console.log("[SW] Message received:", e.type), Vr(e, n, r).catch((t)=>{
                console.error("[SW] Unhandled error in message handler:", t);
                try {
                    r({
                        success: !1,
                        error: String(t)
                    });
                } catch (_) {
                    console.error("[SW] Failed to send error response:", _);
                }
            }), !0));
    }
    console.log("[SW] Registering message handlers immediately on script load");
    Cr();
    self.addEventListener("install", (e)=>{
        console.log("[SW] install event"), e.waitUntil(te());
    });
    self.addEventListener("activate", (e)=>{
        console.log("[SW] activate event"), e.waitUntil(te().then(()=>{
            console.log("[SW] Calling setupAlarms in activate"), Nr();
        }));
    });
    function Ae(e) {
        return e && {
            id: e.id,
            entryType: e.entry_type,
            name: e.name,
            isFavorite: e.is_favorite ?? !1,
            updatedAt: e.updated_at ?? 0,
            deletedAt: e.deleted_at ?? null,
            notes: e.notes ?? null,
            typedValue: e.typed_value ?? {},
            labels: e.label_ids ?? [],
            customFields: (e.custom_fields ?? []).map((n)=>({
                    id: n.id,
                    name: n.name,
                    fieldType: n.field_type,
                    value: n.value
                }))
        };
    }
    function _e(e) {
        return (e ?? []).map(Ae);
    }
    async function p() {
        try {
            console.log("[SW] autoSaveAndPush: Starting");
            const e = V();
            console.log("[SW] autoSaveAndPush: Got vault bytes, size:", e?.length), await y(f.VAULT_BYTES, Array.from(e));
            const n = await h(f.S3_CONFIG);
            if (console.log("[SW] autoSaveAndPush: s3Config exists:", !!n), console.log("[SW] autoSaveAndPush: api_push type:", typeof T), n) try {
                if (typeof T == "function") {
                    console.log("[SW] autoSaveAndPush: Calling api_push");
                    const r = await T(JSON.stringify(n));
                    console.log("[SW] autoSaveAndPush: api_push returned:", r);
                    const t = J?.() ?? null;
                    await y(f.VAULT_ETAG, t), await y(f.LAST_SYNC_TIME, new Date().toISOString()), console.log("[SW] Auto-push successful");
                } else console.warn("[SW] autoSaveAndPush: api_push not available in WASM");
            } catch (r) {
                console.warn("[SW] Auto-push failed:", r);
            }
            else console.log("[SW] autoSaveAndPush: No S3 config, skipping push");
        } catch (e) {
            console.error("[SW] autoSaveAndPush failed:", e);
        }
    }
    async function C() {
        return await h(f.APP_SETTINGS) || {
            autolockMinutes: 5,
            clipboardClearSeconds: 30,
            clipboardAutoClean: !0,
            theme: "light"
        };
    }
    async function Vr(e, n, r) {
        try {
            if (await te(), !u) {
                const t = await h(f.VAULT_BYTES);
                if (t) try {
                    const _ = await h(f.VAULT_ETAG);
                    console.log("[SW] Auto-loading vault from storage (Service Worker recovered)"), G(new Uint8Array(t), _ || "");
                } catch (_) {
                    console.warn("[SW] Failed to auto-load vault:", _);
                }
            }
            switch(e.type){
                case "IS_UNLOCKED":
                    {
                        r({
                            success: !0,
                            unlocked: u
                        });
                        break;
                    }
                case "UNLOCK":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await h(f.VAULT_BYTES), _ = await h(f.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            G(new Uint8Array(t), _ || ""), Q(e.password), u = !0;
                            const c = await C();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UNLOCK_EXISTING":
                    {
                        if (!e.password) {
                            r({
                                success: !1,
                                error: "Password required"
                            });
                            break;
                        }
                        try {
                            const t = await h(f.VAULT_BYTES), _ = await h(f.VAULT_ETAG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "Vault not found"
                                });
                                break;
                            }
                            G(new Uint8Array(t), _ || ""), Q(e.password), u = !0;
                            const c = await C();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LOCK":
                    {
                        try {
                            const t = R();
                            await y(f.VAULT_BYTES, Array.from(t)), u = !1, chrome.alarms.clear("autolock"), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_VAULT":
                    {
                        if (!e.masterPassword) {
                            r({
                                success: !1,
                                error: "Master password required"
                            });
                            break;
                        }
                        try {
                            console.log("[SW] CREATE_VAULT: Starting vault creation"), console.log("[SW] CREATE_VAULT: vault object type:", typeof Or), console.log("[SW] CREATE_VAULT: vault.api_create_new_vault:", typeof H);
                            const t = H(e.masterPassword);
                            console.log("[SW] CREATE_VAULT: Vault created, recovery key:", t);
                            const _ = V();
                            console.log("[SW] CREATE_VAULT: Got vault bytes, size:", _?.length), await y(f.VAULT_BYTES, Array.from(_)), await y(f.VAULT_ETAG, null), console.log("[SW] CREATE_VAULT: Saved vault bytes to storage"), e.s3Config && await y(f.S3_CONFIG, e.s3Config), u = !0;
                            const c = await C();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: c.autolockMinutes
                            }), console.log("[SW] CREATE_VAULT: Success, sending response");
                            const o = {
                                success: !0,
                                recoveryKey: t
                            };
                            console.log("[SW] CREATE_VAULT: Response payload:", o), r(o), console.log("[SW] CREATE_VAULT: sendResponse called");
                        } catch (t) {
                            console.error("[SW] CREATE_VAULT: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RECOVER":
                    {
                        if (!e.recoveryKey || !e.newPassword) {
                            r({
                                success: !1,
                                error: "Recovery key and password required"
                            });
                            break;
                        }
                        try {
                            he(e.recoveryKey), z(e.recoveryKey, e.newPassword);
                            const t = V();
                            await y(f.VAULT_BYTES, Array.from(t)), await y(f.VAULT_ETAG, null), await p(), u = !0;
                            const _ = await C();
                            chrome.alarms.create("autolock", {
                                delayInMinutes: _.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_ENTRIES":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = e.filter || {}, _ = X(t.searchQuery || null, t.type || null, t.labelId || null, t.includeTrash || !1, t.onlyFavorites || !1), c = JSON.parse(_), o = _e(c);
                            r({
                                success: !0,
                                entries: o
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ue(e.id), _ = JSON.parse(t);
                            _ && _.typed_value && typeof _.typed_value == "string" && (_.typed_value = JSON.parse(_.typed_value));
                            const c = Ae(_);
                            r({
                                success: !0,
                                entry: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ae(e.entryType, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null);
                            await p(), r({
                                success: !0,
                                entryId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "UPDATE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            me(e.id, e.name, e.notes || null, JSON.stringify(e.typedValue || {}), e.labelIds || [], e.customFields ? JSON.stringify(e.customFields) : null), await p(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            oe(e.id), await p(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RESTORE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            we(e.id), await p(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PURGE_ENTRY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            de(e.id), await p(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_FAVORITE":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            pe(e.id, e.isFavorite), await p(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_TRASH":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = X(null, null, null, !0, !1), _ = JSON.parse(t), c = _e(_);
                            r({
                                success: !0,
                                entries: c
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "LIST_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = fe(), _ = JSON.parse(t);
                            r({
                                success: !0,
                                labels: _
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CREATE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ce(e.name);
                            await p(), r({
                                success: !0,
                                labelId: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DELETE_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ie(e.id), await p(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "RENAME_LABEL":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            ge(e.id, e.newName), await p(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SET_ENTRY_LABELS":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            Se(e.entryId, e.labelIds || []), await p(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_PASSWORD":
                    {
                        try {
                            const t = le(e.length ?? 16, e.includeUppercase ?? !0, e.includeLowercase ?? !0, e.includeNumbers ?? !0, e.includeSymbols ?? !0);
                            r({
                                success: !0,
                                password: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GENERATE_TOTP":
                    {
                        try {
                            const t = se(e.secret);
                            r({
                                success: !0,
                                totp: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CHANGE_MASTER_PASSWORD":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            z(e.oldPassword, e.newPassword), await p(), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "ROTATE_DEK":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = ye(e.password);
                            await p(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "REGENERATE_RECOVERY_KEY":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = be(e.password);
                            await p(), r({
                                success: !0,
                                recoveryKey: t
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DOWNLOAD_VAULT":
                    {
                        try {
                            const t = await h(f.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            if (typeof Y != "function") {
                                console.warn("[SW] DOWNLOAD_VAULT: api_download is not available in vault_core"), r({
                                    success: !1,
                                    error: "S3 download feature is not yet implemented in vault_core"
                                });
                                break;
                            }
                            console.log("[SW] DOWNLOAD_VAULT: Downloading vault from S3");
                            const _ = await Y(JSON.stringify(t));
                            if (_) {
                                const c = V();
                                await y(f.VAULT_BYTES, Array.from(c)), console.log("[SW] DOWNLOAD_VAULT: Vault downloaded and saved to storage");
                            } else console.log("[SW] DOWNLOAD_VAULT: Vault not found in S3, vaultExists=false");
                            r({
                                success: !0,
                                vaultExists: _
                            });
                        } catch (t) {
                            console.error("[SW] DOWNLOAD_VAULT: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "PUSH_VAULT":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            const t = await h(f.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            if (typeof T != "function") {
                                console.warn("[SW] PUSH_VAULT: api_push is not available in vault_core"), r({
                                    success: !1,
                                    error: "S3 push feature is not yet implemented in vault_core"
                                });
                                break;
                            }
                            console.log("[SW] PUSH_VAULT: Pushing vault to S3"), await T(JSON.stringify(t));
                            const _ = J?.() ?? null;
                            await y(f.VAULT_ETAG, _), await y(f.LAST_SYNC_TIME, new Date().toISOString()), console.log("[SW] PUSH_VAULT: Push successful"), r({
                                success: !0
                            });
                        } catch (t) {
                            console.error("[SW] PUSH_VAULT: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "DOWNLOAD":
                    {
                        try {
                            console.log("[SW] DOWNLOAD: Starting download");
                            const t = e.storageConfig ? JSON.parse(e.storageConfig) : await h(f.S3_CONFIG);
                            if (!t) {
                                r({
                                    success: !1,
                                    error: "S3 config not found"
                                });
                                break;
                            }
                            const _ = JSON.stringify(t);
                            console.log("[SW] DOWNLOAD: Calling api_download");
                            const c = await Y(_);
                            console.log("[SW] DOWNLOAD: api_download completed, result:", c), r({
                                success: !0,
                                result: c
                            });
                        } catch (t) {
                            console.error("[SW] DOWNLOAD: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "SYNC":
                    {
                        if (!u) {
                            r({
                                success: !1,
                                error: "Vault not unlocked"
                            });
                            break;
                        }
                        try {
                            console.log("[SW] SYNC: Starting sync");
                            const t = await h(f.S3_CONFIG);
                            if (console.log("[SW] SYNC: s3Config:", t), !t) {
                                console.log("[SW] SYNC: No S3 config found"), r({
                                    success: !0,
                                    status: "idle",
                                    message: "S3 config not set"
                                });
                                break;
                            }
                            console.log("[SW] SYNC: api_sync available:", typeof F == "function"), console.log("[SW] SYNC: api_push available:", typeof T == "function");
                            const _ = JSON.stringify(t);
                            if (typeof F == "function") {
                                console.log("[SW] SYNC: Calling api_sync");
                                const i = await F(_);
                                console.log("[SW] SYNC: api_sync completed successfully");
                            } else if (typeof T == "function") {
                                console.log("[SW] SYNC: api_sync not available, using api_push instead");
                                const i = await T(_);
                                console.log("[SW] SYNC: api_push completed successfully");
                            } else throw new Error("Neither api_sync nor api_push is available");
                            const c = V();
                            console.log("[SW] SYNC: Got vault bytes after sync, size:", c?.length), await y(f.VAULT_BYTES, Array.from(c));
                            const o = J?.() ?? null;
                            await y(f.VAULT_ETAG, o), await y(f.LAST_SYNC_TIME, new Date().toISOString()), console.log("[SW] SYNC: Sync completed successfully"), r({
                                success: !0,
                                status: "synced"
                            });
                        } catch (t) {
                            console.error("[SW] SYNC: Error:", t), r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "GET_SETTINGS":
                    {
                        const t = await C();
                        r({
                            success: !0,
                            settings: t
                        });
                        break;
                    }
                case "SAVE_SETTINGS":
                    {
                        try {
                            await y(f.APP_SETTINGS, e.settings), u && chrome.alarms.create("autolock", {
                                delayInMinutes: e.settings.autolockMinutes
                            }), r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                case "CLIPBOARD_COPIED":
                    {
                        try {
                            const t = await C();
                            if (t.clipboardAutoClean) {
                                const _ = t.clipboardClearSeconds / 60;
                                chrome.alarms.create("clipboard-clear", {
                                    delayInMinutes: _
                                });
                            }
                            r({
                                success: !0
                            });
                        } catch (t) {
                            r({
                                success: !1,
                                error: String(t)
                            });
                        }
                        break;
                    }
                default:
                    r({
                        success: !1,
                        error: "Unknown message type"
                    });
            }
        } catch (t) {
            console.error("[SW] Message handling error:", t), r({
                success: !1,
                error: String(t)
            });
        }
    }
    function Nr() {
        chrome.alarms.onAlarm.addListener((e)=>{
            e.name === "autolock" ? Ur() : e.name === "clipboard-clear" && Ir();
        });
    }
    async function Ur() {
        if (console.log("[SW] Autolock alarm triggered"), !!u) try {
            const e = R();
            await y(f.VAULT_BYTES, Array.from(e)), u = !1, console.log("[SW] Vault locked");
        } catch (e) {
            console.error("[SW] Autolock failed:", e);
        }
    }
    async function Ir() {
        console.log("[SW] Clipboard clear alarm triggered");
        try {
            typeof chrome.offscreen < "u" ? (await chrome.offscreen.createDocument({
                url: chrome.runtime.getURL("src/background/offscreen.html"),
                reasons: [
                    "CLIPBOARD"
                ],
                justification: "Clear clipboard after copy timeout"
            }), chrome.runtime.sendMessage({
                type: "CLEAR_CLIPBOARD"
            })) : await navigator.clipboard.writeText("");
        } catch (e) {
            console.error("[SW] Clipboard clear failed:", e);
        }
    }
})();
